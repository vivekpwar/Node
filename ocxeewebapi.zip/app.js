require('dotenv').config();
// var createError = require('http-errors');
var express = require('express');
var path = require('path');
var logger = require('morgan');
var bodyParser = require("body-parser");
var cors = require('cors')

var app = express();

//json allow
app.use(bodyParser.json({limit: '50mb'})); 

// Body Parser Middleware
app.use(bodyParser.urlencoded({limit: '50mb', extended: true, parameterLimit: 1000000}));
// app.use(busboyBodyParser());

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
// app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use(function (req, res, next) {
    //Enabling CORS
    process.env.Version = req.url.split('/')[2];
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, contentType,Content-Type, Accept, Authorization");
    next();
});

app.use(cors({ origin: true }));

app.use('/api', require('./api'));

let PORT = (process.env.PORT || '8000');
app.listen(PORT, function() {
    console.log('Server started port : '+this.address().port);
});

module.exports = app;