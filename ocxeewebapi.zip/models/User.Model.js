require('dotenv').config();
const moment = require('moment');
const md5 = require('md5');
const _ = require('lodash');
const sqlhelper = require("../helpers/sqlhelper");
const Common = require("../libraries/User.Common");
const { v4: uuidv4, stringify } = require('uuid');
const { includes, keysIn } = require('lodash');
var path = require('path');
const { exit } = require('process');
const textService = require("../controllers/TexiController")

const User = {};
const image_location = process.env.S3_LOCATION;
const imgsize = "277x177/";
const ImageLink = process.env.CloudFrontLink + imgsize;
const s3link = process.env.S3_LOCATION;
// let FieldReplace = 'IF(ag.MediaUrl!="", ag.MediaUrl, ag.MediaFile) AS ImageUrl'
let FieldReplace = 'IF(ag.MediaUrl!="", replace(ag.MediaUrl,"' + s3link + '","' + ImageLink + '"), replace(ag.MediaFile,"' + s3link + '","' + ImageLink + '")) AS ImageUrl,';

User.UserLogin = async (request, callback) => {
    let user_query = 'SELECT CAST(sm.StudentID AS CHAR) AS UserId, sm.ChannelPartnerID, sm.FirstName, sm.MiddleName, sm.LastName, sm.Email, sm.PhoneNo_CountryCode,sm.File,sm.PhoneNo, IF(sm.Photo!="", sm.Photo, "' + process.env.NotImageFound + '") AS Photo, IF(sm.DateOfBirth!="0000-00-00", DATE_FORMAT(sm.DateOfBirth, "%Y-%m-%d"), "") AS DateOfBirth, sm.Gender, CAST(sm.CountryID AS CHAR) AS CountryID, IFNULL(cn.CountryName, "") AS CountryName, CAST(sm.StateID AS CHAR) AS StateID, IFNULL(st.StateName, "") AS StateName, CAST(sm.CityID AS CHAR) AS CityID, IFNULL(ct.CityName, "") AS CityName, sm.Location,sm.IsStudentVerify, CAST(sm.Active AS CHAR) AS Active, \
    sm.StudentCode,sm.Nationality,CurrentUniversity,DestinationUniversity,YearofStudy,Course,GI_FirstName,GI_LastName,GI_Relationship,GI_DateofBirth,GI_EmailAddress,GI_Postalcode,GI_PhoneNumber,GI_Address,GI_City,GI_State,Mail_Address,Mail_City,Mail_State,Mail_Postalcode,Mail_Country,GI_Country,FormProgress FROM Student AS sm \
        LEFT JOIN Mst_Country AS cn ON cn.CountryID=sm.CountryID \
        LEFT JOIN Mst_State AS st ON st.StateID=sm.StateID \
        LEFT JOIN Mst_City AS ct ON ct.CityID=sm.CityID \
        WHERE sm.Email=? AND sm.Password=? LIMIT 1';

    let user_data = await sqlhelper.select(user_query, [request.UserName, md5(request.UserPassword)], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (_.isEmpty(res)) {
            callback(null, json_response({
                'status': '0',
                'message': 'The username and password you have entered are invalid. Please, check your details.'
            }));
            return 0;
        } else {
            return json_response(res[0]);
        }
    });

    if (user_data == 0) {
        return;
    }

    if (user_data['Active'] == '0') {
        var response = {};
        response['message'] = 'Dear user, your account has been deactivated; please contact customer support for assistance.';
        response['status'] = '0';
        callback(null, json_response(response));
        return;
    }

    request.UserId = user_data['UserId'];
    var Token = await Common.GenerateNewToken(request);

    let cp_query = 'SELECT CAST(cp.ChannelPartnerID AS CHAR) AS ChannelPartnerID, CONCAT(cp.FirstName, " ", cp.LastName) AS Name, cp.PersonalEmail AS Email, IF(cp.PersonalPhoto!="", cp.PersonalPhoto, "' + process.env.NotImageFound + '") AS Photo, cn.PhoneCode AS PhoneNoCode, cp.ContactPhoneNo AS PhoneNo FROM ChannelPartner AS cp \
        LEFT JOIN Mst_Country AS cn ON cn.CountryID=cp.ContactPhoneNo_CountyCode \
        WHERE cp.ChannelPartnerID=? LIMIT 1';

    let cp_data = await sqlhelper.select(cp_query, [user_data.ChannelPartnerID], (err, res) => {
        if (err || res.length <= 0) {
            return {
                "ChannelPartnerID": "0",
                "Name": "Ocxee Ltd.",
                "Email": process.env.GMAIL_ACCOUNT,
                "Photo": "https://ocxeeadmin.s3.eu-west-2.amazonaws.com/ocxee-text-img.png",
                "PhoneNoCode": "+44",
                "PhoneNo": "2079 751 681"
            };
        } else {
            return json_response(res[0]);
        }
    });
    delete user_data['ChannelPartnerID'];
    user_data['consultant_info'] = cp_data;

    var response = {
        'data': user_data,
        'message': 'Congratulations! Your login process has been succeeded.',
        'status': '1',
        'token': Token,
    };
    callback(null, json_response(response));
}

User.UserRegistration = async (request, callback) => {
    let emailid_query = "SELECT Email FROM Student WHERE Email=? LIMIT 1";
    let emailid_exits = await sqlhelper.select(emailid_query, [request.Email], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (res.length > 0) {
            callback(null, json_response({
                'status': '0',
                'message': 'This Email Id already exists on the platform; try a different one.'
            }));
            return 0;
        } else {
            return 1;
        }
    });

    if (emailid_exits == 0) {
        return;
    }

    let mobile_query = "SELECT PhoneNo FROM Student WHERE PhoneNo=? LIMIT 1";
    let mobile_exits = await sqlhelper.select(mobile_query, [request.PhoneNo], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (res.length > 0) {
            callback(null, json_response({
                'status': '0',
                'message': 'This number has already been used;  get yourself another one.'
            }));
            return 0;
        } else {
            return 1;
        }
    });

    if (mobile_exits == 0) {
        return;
    }

    let CountryName = (request.CountryName != undefined ? request.CountryName.trim() : '');
    let StateName = (request.StateName != undefined ? request.StateName.trim() : '');
    let CityName = (request.CityName != undefined ? request.CityName.trim() : '');

    let csc_where_array = [StateName, CityName, CountryName];
    let csc_query = 'SELECT cn.CountryID, IFNULL(st.StateID, 0) AS StateID, IFNULL(ct.CityID, 0) AS CityID FROM Mst_Country AS cn LEFT JOIN Mst_State AS st ON st.CountryID=cn.CountryID AND st.StateName=? LEFT JOIN Mst_City AS ct ON ct.StateID=st.StateID AND ct.CityName=? WHERE cn.CountryName=? LIMIT 1';
    if (CityName != '' && StateName == '') {
        csc_where_array = [CityName, CountryName];
        csc_query = 'SELECT cn.CountryID, IFNULL(st.StateID, 0) AS StateID, IFNULL(ct.CityID, 0) AS CityID FROM Mst_Country AS cn LEFT JOIN Mst_State AS st ON st.CountryID=cn.CountryID LEFT JOIN Mst_City AS ct ON ct.StateID=st.StateID AND ct.CityName=? WHERE cn.CountryName=? AND ct.CityID!="0" LIMIT 1';
    }

    let csc_data = await sqlhelper.select(csc_query, csc_where_array, (err, res) => {
        if (err || res.length <= 0) {
            return {
                'CountryID': '0',
                'StateID': '0',
                'CityID': '0'
            };
        } else {
            return res[0];
        }
    });

    var insert_data = {
        'FirstName': request.FirstName,
        'MiddleName': (request.MiddleName != undefined ? request.MiddleName : ''),
        'LastName': request.LastName,
        'Email': request.Email,
        'Password': md5(request.Password),
        'PhoneNo_CountryCode': (request.PhoneNo_CountryCode != undefined ? request.PhoneNo_CountryCode : ''),
        'PhoneNo': request.PhoneNo,
        'DateOfBirth': (request.DateOfBirth != undefined ? request.DateOfBirth : ''),
        'Gender': (request.Gender != undefined ? request.Gender : ''),
        'CountryID': csc_data.CountryID,
        'StateID': csc_data.StateID,
        'CityID': csc_data.CityID,
        'Location': (request.Location != undefined ? request.Location : ''),
        'EntryDate': moment().format('YYYY-MM-DD HH:mm:ss'),
        'EntryIP': request.IpAddress,
        'FormProgress': 25,
        'Active': '0',
    };

    let user_data = await sqlhelper.insert('Student', insert_data, async (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else {
            res = json_response(res);

            // let user_query = 'SELECT CAST(sm.StudentID AS CHAR) AS UserId, sm.ChannelPartnerID, sm.FirstName, sm.MiddleName, sm.LastName, sm.Email, sm.PhoneNo_CountryCode, sm.PhoneNo, IF(sm.Photo!="", sm.Photo, "'+process.env.NotImageFound+'") AS Photo, IF(sm.DateOfBirth!="0000-00-00", DATE_FORMAT(sm.DateOfBirth, "%Y-%m-%d"), "") AS DateOfBirth, sm.Gender, CAST(sm.CountryID AS CHAR) AS CountryID, IFNULL(cn.CountryName, "") AS CountryName, CAST(sm.StateID AS CHAR) AS StateID, IFNULL(st.StateName, "") AS StateName, CAST(sm.CityID AS CHAR) AS CityID, IFNULL(ct.CityName, "") AS CityName, sm.Location, CAST(sm.Active AS CHAR) AS Active FROM Student AS sm \
            //     LEFT JOIN Mst_Country AS cn ON cn.CountryID=sm.CountryID \
            //     LEFT JOIN Mst_State AS st ON st.StateID=sm.StateID \
            //     LEFT JOIN Mst_City AS ct ON ct.CityID=sm.CityID \
            //     WHERE sm.StudentID=? LIMIT 1';
            // return sqlhelper.select(user_query, [res.insertId], (err, res) => {
            //     if (err) {
            //         console.log(err);
            //         callback(json_response(err), null);
            // 		return 0;
            //     } else {
            //     	return json_response(res[0]);
            //     }
            // });
            return res.insertId
        }
    });

    if (user_data == 0) {
        return;
    }

    let Session = {
        // 'UserId': user_data['UserId'],
        'UserId': user_data,
        'ExpiredTime': moment().add(24, 'hours').format('YYYYMMDDHHmmss'),
    }

    Session = encodeURIComponent(Common.TokenEncrypt(JSON.stringify(Session)));
    let reset_pass_link = process.env.STUDENT_PANEL_LINK + 'email-verification?Session=' + Session;

    let user_name = request.FirstName + ' ' + request.LastName;
    let EmailData = await Common.GetEmailTemplate('FrontEnd.verification');
    if (_.size(EmailData) > 0) {
        let body = EmailData['Body']
            .replace('{First Name}', user_name)
            .replace('{link}', reset_pass_link);

        let MailData = {
            'mail_to': request.Email,
            'subject': EmailData['Subject'],
            'body': body,
            //'cc_mail': EmailData['CCEmail'],
        };
        await Common.SendEmailSMTP(MailData);
    }

    // request.UserId = user_data['UserId'],;
    // var Token = await Common.GenerateNewToken(request);

    // delete user_data['ChannelPartnerID'];
    // user_data['consultant_info'] = {
    //     "ChannelPartnerID": "0",
    //     "Name": "Ocxee Ltd.",
    //     "Email": process.env.GMAIL_ACCOUNT,
    //     "Photo": "https://ocxeeadmin.s3.eu-west-2.amazonaws.com/ocxee-text-img.png",
    //     "PhoneNoCode": "+44",
    //     "PhoneNo": "2079 751 681"
    // };

    await User.SubscribeUs(request, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            // console.log(error);
        } else {
            // console.log(data);
        }
    });

    var response = {
        // 'data' : user_data['UserId'],
        'data': [],
        'message': 'Dear, user your registration process has been succeeded and please check Email ID',
        'status': '1',
        // 'token': Token,
        'token': request.Token,
    };
    response["StudentID"] = user_data
    console.log(response)
    return callback(null, json_response(response));
}

User.UserForgetPassword = async (request, callback) => {
    let user_query = 'SELECT CAST(StudentID AS CHAR) AS UserId, CONCAT(FirstName, " ", LastName) AS FullName, Email, CAST(Active AS CHAR) AS Active FROM Student WHERE Email=? LIMIT 1';
    let user_data = await sqlhelper.select(user_query, [request.UserName], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (_.isEmpty(res)) {
            callback(null, json_response({
                'status': '0',
                'message': 'The account does not exist, please check your username.'
            }));
            return 0;
        } else {
            return json_response(res[0]);
        }
    });

    if (user_data == 0) {
        return;
    }

    if (user_data['Active'] == '0') {
        var response = {};
        response['message'] = 'Dear user, your account has been deactivated; please contact customer support for assistance.';
        response['status'] = '0';
        callback(null, json_response(response));
        return;
    }

    let Session = {
        'UserId': user_data['UserId'],
        'ExpiredTime': moment().add(24, 'hours').format('YYYYMMDDHHmmss'),
    }
    Session = encodeURIComponent(Common.TokenEncrypt(JSON.stringify(Session)));
    let reset_pass_link = process.env.STUDENT_PANEL_LINK + 'Forgotpassword?Session=' + Session;
    // console.log(reset_pass_link);

    let EmailData = await Common.GetEmailTemplate('FrontEnd.ForgotPassword');
    if (_.size(EmailData) > 0) {
        let body = EmailData['Body']
            .replace('%_FullName_%', user_data['FullName'])
            .replace('%_ForgetUrl_%', reset_pass_link)
            .replace('{{STUDENT_PANEL_LINK}}', process.env.STUDENT_PANEL_LINK);

        let MailData = {
            'mail_to': user_data['Email'],
            'subject': EmailData['Subject'],
            'body': body,
            'cc_mail': EmailData['CCEmail'],
        };
        await Common.SendEmailSMTP(MailData);
    }

    var response = {
        'message': 'Dear user, the link for resetting your password is sent to your registered email id. Do check your mail.',
        'status': '1',
    };

    callback(null, json_response(response));
    return;
}

User.UserResetPassword = async (request, callback) => {
    let user_query = 'SELECT CAST(StudentID AS CHAR) AS UserId, Email, CAST(Active AS CHAR) AS Active FROM Student WHERE StudentID=? LIMIT 1';
    let user_data = await sqlhelper.select(user_query, [request.UserId], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (_.isEmpty(res)) {
            callback(null, json_response({
                'status': '0',
                'message': 'Dear, user your account is not found. Check your details and try again.'
            }));
            return 0;
        } else {
            return json_response(res[0]);
        }
    });

    if (user_data == 0) {
        return;
    }

    if (user_data['Active'] == '0') {
        var response = {};
        response['message'] = 'Dear user, your account has been deactivated; please contact customer support for assistance.';
        response['status'] = '0';
        callback(null, json_response(response));
        return;
    }

    let update_data = {
        'Password': md5(request.Password),
        'UpdateDate': moment().format('YYYY-MM-DD HH:mm:ss'),
        'UpdateIP': request.IpAddress,
    }

    let where = {
        'StudentID': request.UserId
    }
    await sqlhelper.update('Student', update_data, where, (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (res.affectedRows == 0) {
            callback(null, json_response({
                'status': '0',
                'message': 'Sorry, something went wrong; please check your internet connection or try again later.'
            }));
            return 0;
        } else {
            callback(null, json_response({
                'status': '1',
                'message': 'User account reset password successfully.'
            }));
        }
    });
}

User.UserChangePassword = async (request, callback) => {
    let user_query = 'SELECT CAST(StudentID AS CHAR) AS UserId, Password, CAST(Active AS CHAR) AS Active FROM Student WHERE StudentID=? LIMIT 1';
    let user_data = await sqlhelper.select(user_query, [request.UserId], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (_.isEmpty(res)) {
            callback(null, json_response({
                'status': '0',
                'message': 'The account does not exist, please check your username.'
            }));
            return 0;
        } else {
            return json_response(res[0]);
        }
    });

    if (user_data == 0) {
        return;
    }

    if (user_data['Password'] != md5(request.OldPassword)) {
        callback(null, {
            'status': '0',
            'message': 'Dear user, the old password you have entered is not matching; please check the alphabets and cases.'
        });
        return;
    }

    if (user_data['Active'] == '0') {
        callback(null, {
            'status': '0',
            'message': 'Dear user, your account has been deactivated; please contact customer support for assistance.'
        });
        return;
    }

    let update_data = {
        'Password': md5(request.NewPassword),
        'UpdateDate': moment().format('YYYY-MM-DD HH:mm:ss'),
        'UpdateIP': request.IpAddress,
    }

    let where = {
        'StudentID': request.UserId
    }
    await sqlhelper.update('Student', update_data, where, (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (res.affectedRows <= 0) {
            callback(null, json_response({
                'status': '0',
                'message': 'Sorry, something went wrong; please check your internet connection or try again later.'
            }));
            return 0;
        } else {
            callback(null, json_response({
                'status': '1',
                'message': 'Dear user, your password has been reset successfully. Please note down it at a safe place.'
            }));
        }
    });
}

User.UserProfileUpdate = async (request, callback) => {
    console.log("object");
    let emailid_query = "SELECT Email FROM Student WHERE Email=? AND StudentID!=? AND Email!='' LIMIT 1";
    let emailid_exits = await sqlhelper.select(emailid_query, [request.Email, request.UserId], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (res.length > 0) {
            callback(null, json_response({
                'status': '0',
                'message': 'This Email Id already exists on the platform; try a different one.'
            }));
            return 0;
        } else {
            return 1;
        }
    });

    if (emailid_exits == 0) {
        return;
    }

    let mobile_query = "SELECT PhoneNo FROM Student WHERE Active='1' AND PhoneNo=? AND StudentID!=? && PhoneNo!='' LIMIT 1";
    let mobile_exits = await sqlhelper.select(mobile_query, [request.PhoneNo, request.UserId], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (res.length > 0) {
            callback(null, json_response({
                'status': '0',
                'message': 'This number has already been used;  get yourself another one.'
            }));
            return 0;
        } else {
            return 1;
        }
    });

    if (mobile_exits == 0) {
        return;
    }

    let CountryName = (request.CountryName != undefined ? request.CountryName.trim() : '');
    let StateName = (request.StateName != undefined ? request.StateName.trim() : '');
    let CityName = (request.CityName != undefined ? request.CityName.trim() : '');

    let csc_where_array = [StateName, CityName, CountryName];
    let csc_query = 'SELECT cn.CountryID, IFNULL(st.StateID, 0) AS StateID, IFNULL(ct.CityID, 0) AS CityID FROM Mst_Country AS cn LEFT JOIN Mst_State AS st ON st.CountryID=cn.CountryID AND st.StateName=? LEFT JOIN Mst_City AS ct ON ct.StateID=st.StateID AND ct.CityName=? WHERE cn.CountryName=? LIMIT 1';
    if (CityName != '' && StateName == '') {
        csc_where_array = [CityName, CountryName];
        csc_query = 'SELECT cn.CountryID, IFNULL(st.StateID, 0) AS StateID, IFNULL(ct.CityID, 0) AS CityID FROM Mst_Country AS cn LEFT JOIN Mst_State AS st ON st.CountryID=cn.CountryID LEFT JOIN Mst_City AS ct ON ct.StateID=st.StateID AND ct.CityName=? WHERE cn.CountryName=? AND ct.CityID!="0" LIMIT 1';
    }

    let csc_data = await sqlhelper.select(csc_query, csc_where_array, (err, res) => {
        if (err || res.length <= 0) {
            return {
                'CountryID': '0',
                'StateID': '0',
                'CityID': '0'
            };
        } else {
            return res[0];
        }
    });

    var update_data = {
        'FirstName': request.FirstName,
        'MiddleName': (request.MiddleName != undefined ? request.MiddleName : ''),
        'LastName': request.LastName,
        // 'Email': request.Email,
        'PhoneNo_CountryCode': (request.PhoneNo_CountryCode != undefined ? request.PhoneNo_CountryCode : ''),
        'PhoneNo': request.PhoneNo,
        'DateOfBirth': (request.DateOfBirth != undefined ? request.DateOfBirth : ''),
        'Gender': (request.Gender != undefined ? request.Gender : ''),
        'CountryID': csc_data.CountryID,
        'StateID': csc_data.StateID,
        'CityID': csc_data.CityID,
        'Location': (request.Location != undefined ? request.Location : ''),
        'Nationality': request.Nationality,
        'CurrentUniversity': request.CurrentUniversity,
        'DestinationUniversity': request.DestinationUniversity,
        'YearofStudy': request.YearofStudy,
        'Course': request.Course,
        'GI_FirstName': request.GI_FirstName,
        'GI_LastName': request.GI_LastName,
        'GI_Relationship': request.GI_Relationship,
        'GI_DateofBirth': request.GI_DateofBirth,
        'GI_EmailAddress': request.GI_EmailAddress,
        'GI_Postalcode': request.GI_Postalcode,
        'GI_PhoneNumber': request.GI_PhoneNumber,
        'GI_Address': request.GI_Address,
        'GI_City': request.GI_City,
        'GI_State': request.GI_State,
        'GI_Country': request.GI_Country,
        'Mail_Address': request.Mail_Address,
        'Mail_City': request.Mail_City,
        'Mail_State': request.Mail_State,
        'Mail_Postalcode': request.Mail_Postalcode,
        'Mail_Country': request.Mail_Country,
        'FormProgress': request.FormProgress,
        'UpdateDate': moment().format('YYYY-MM-DD HH:mm:ss'),
        'UpdateIP': request.IpAddress,
    };

    if (request.Photo != undefined && request.Photo.trim() != '') {
        let file_array = {
            'base64_data': request.Photo,
            'file_name': 'StudentDocument/' + uuidv4() + '.jpeg',
            'content_type': 'Image/jpeg',
        }
        let file_data = await Common.S3FileUpload(file_array);
        if (file_data['Location'] != undefined) {
            // console.log(file_data['Location']);
            update_data['Photo'] = file_data['Location'];
        }
    }
    var File = ["Address", "IdentiVerification", "Additional"]
    if (request.File != undefined) {
        var jsonFileArray = {}
        jsonFileArray = JSON.parse(request.File)
        jsonFileArray[File[0]].length > 0 && jsonFileArray[File[0]][1] != 1 ? delete jsonFileArray[File[0]][1] : ''
        jsonFileArray[File[1]].length > 0 && jsonFileArray[File[1]][1] != 1 ? delete jsonFileArray[File[1]][1] : ''
        if (jsonFileArray[File[2]].length > 0 && jsonFileArray[File[2]][jsonFileArray[File[2]].length - 1] == 0)
            delete jsonFileArray[File[2]][jsonFileArray[File[2]].length - 1]
        var ext = request;
        try {
            for (var i = 0; i < File.length; i++) {
                if (jsonFileArray[File[i]] != undefined) {
                    for (var j = 0; j < jsonFileArray[File[i]].length; j++) {
                        // console.log(jsonFileArray[File[i]])
                        if (jsonFileArray[File[i]][j] != 0 && jsonFileArray[File[i]][j]) {

                            let filetype = jsonFileArray[File[i]][j].substring(jsonFileArray[File[i]][j].indexOf(":") + 1, jsonFileArray[File[i]][j].lastIndexOf(";"))
                            console.log(filetype)
                            let file_array = {
                                'base64_data': jsonFileArray[File[i]][j],
                                'file_name': 'Mst_Services/' + uuidv4() + '.' + ext,
                                'content_type': filetype || "",
                            }
                            let file_data = await Common.S3FileUpload(file_array);
                            if (file_data['Location'] != undefined) {
                                jsonFileArray[File[i]][j] = file_data['Location'];
                            }
                        }
                    }
                }
            }
        } catch (error) {
            console.log(error);
        }
        if (request.OldFile != undefined) {
            var jsonFileArray2 = []
            jsonFileArray2 = JSON.parse(request.OldFile);

            var total = 0
            for (var i = 0; i < File.length; i++) {
                if (jsonFileArray2[File[i]] != undefined && jsonFileArray[File[i]] != undefined) {
                    total = jsonFileArray[File[i]].length + jsonFileArray2[File[i]].length - 1
                    console.log(jsonFileArray2[File[i]])

                    for (var j = jsonFileArray[File[i]].length; j < total; j++) {
                        jsonFileArray[File[i]][j] = jsonFileArray2[File[i]][j - jsonFileArray[File[i]].length]

                    }
                }
            }
        }
        else {
        }
        jsonFileArray[File[0]].length > 0 ? jsonFileArray[File[0]][1] = 0 : ''
        jsonFileArray[File[1]].length > 0 ? jsonFileArray[File[1]][1] = 0 : ''
        jsonFileArray[File[2]].length > 0 ? jsonFileArray[File[2]][jsonFileArray[File[2]].length] = 0 : ''
        update_data['File'] = JSON.stringify(jsonFileArray)
    } else {
        if (request.OldFile != undefined) {
            // update_data['File'] = ''
            var jsonFileArray = JSON.parse(request.OldFile);
            update_data['File'] = JSON.stringify(jsonFileArray)
        }
    }
    let update_where = {
        'StudentID': request.UserId,
    }

    let user_data = await sqlhelper.update('Student', update_data, update_where, (err, res) => {
        if (err) {
            console.log(err);
            callback(json_response(err), null);
            return 0;
        } else if (res.affectedRows <= 0) {
            callback(null, json_response({
                'status': '0',
                'message': 'Dear, user your account is not found. Check your details and try again.'
            }));
            return 0;
        } else {
            res = json_response(res);

            let user_query = 'SELECT CAST(sm.StudentID AS CHAR) AS UserId, sm.ChannelPartnerID, sm.FirstName, sm.MiddleName, sm.LastName, sm.Email, sm.PhoneNo_CountryCode, sm.PhoneNo, IF(sm.Photo!="", sm.Photo, "' + process.env.NotImageFound + '") AS Photo, IF(sm.DateOfBirth!="0000-00-00", DATE_FORMAT(sm.DateOfBirth, "%Y-%m-%d"), "") AS DateOfBirth, sm.Gender, CAST(sm.CountryID AS CHAR) AS CountryID, IFNULL(cn.CountryName, "") AS CountryName, CAST(sm.StateID AS CHAR) AS StateID, IFNULL(st.StateName, "") AS StateName, CAST(sm.CityID AS CHAR) AS CityID, IFNULL(ct.CityName, "") AS CityName, sm.Location,sm.File,sm.IsStudentVerify, CAST(sm.Active AS CHAR) AS Active,\
            StudentCode,Nationality,CurrentUniversity,DestinationUniversity,YearofStudy,Course,GI_FirstName,GI_LastName,GI_Relationship,GI_DateofBirth,GI_EmailAddress,GI_Postalcode,GI_PhoneNumber,GI_Address,GI_City,GI_State,Mail_Address,Mail_City,Mail_State,Mail_Postalcode,Mail_Country,GI_Country,FormProgress\
            FROM Student AS sm \
            LEFT JOIN Mst_Country AS cn ON cn.CountryID=sm.CountryID \
                LEFT JOIN Mst_State AS st ON st.StateID=sm.StateID \
                LEFT JOIN Mst_City AS ct ON ct.CityID=sm.CityID \
                WHERE sm.StudentID=? LIMIT 1';
            return sqlhelper.select(user_query, [request.UserId], (err, res) => {
                if (err) {
                    console.log(err);
                    callback(json_response(err), null);
                    return 0;
                } else {
                    return json_response(res[0]);
                }
            });
        }
    });

    if (user_data == 0) {
        return;
    }

    let cp_query = 'SELECT CAST(cp.ChannelPartnerID AS CHAR) AS ChannelPartnerID, CONCAT(cp.FirstName, " ", cp.LastName) AS Name, cp.PersonalEmail AS Email, IF(cp.PersonalPhoto!="", cp.PersonalPhoto, "' + process.env.NotImageFound + '") AS Photo, cn.PhoneCode AS PhoneNoCode, cp.ContactPhoneNo AS PhoneNo FROM ChannelPartner AS cp \
        LEFT JOIN Mst_Country AS cn ON cn.CountryID=cp.ContactPhoneNo_CountyCode \
        WHERE cp.ChannelPartnerID=? LIMIT 1';

    let cp_data = await sqlhelper.select(cp_query, [user_data.ChannelPartnerID], (err, res) => {
        if (err || res.length <= 0) {
            return {
                "ChannelPartnerID": "0",
                "Name": "Ocxee Ltd.",
                "Email": process.env.GMAIL_ACCOUNT,
                "Photo": "https://ocxeeadmin.s3.eu-west-2.amazonaws.com/ocxee-text-img.png",
                "PhoneNoCode": "+44",
                "PhoneNo": "2079 751 681"
            };
        } else {
            return json_response(res[0]);
        }
    });
    delete user_data['ChannelPartnerID'];
    user_data['consultant_info'] = cp_data;

    var response = {
        'data': user_data,
        'message': 'User profile updated successfully.',
        'status': '1',
    };
    return callback(null, json_response(response));
}

User.GetAccommodationList = async (request, callback) => {
    let where_having = '';
    let where = '';
    let where_array = [];

    /*if (request.Search!=undefined && request.Search!='') {
        where += ' AND acc.AccommodationName LIKE ? ';
        where_array.push('%'+request.Search+'%');
    }
 
    if (request.CountryID!=undefined && request.CountryID>0) {
        where += ' AND acc.CountryID=? ';
        where_array.push(request.CountryID);
    }
    
    if (request.StateID!=undefined && request.StateID>0) {
        where += ' AND acc.StateID=? ';
        where_array.push(request.StateID);
    }
    
    if (request.CityID!=undefined && request.CityID>0) {
        where += ' AND acc.CityID=? ';
        where_array.push(request.CityID);
    }
    
    if (request.PropertyTypeId!=undefined && request.PropertyTypeId>0) {
        where += ' AND FIND_IN_SET(?, acc.PropertyType) ';
        where_array.push(request.PropertyTypeId);
    }*/

    // this developed for border issue by Parth Devani 23-05-2021
    if (request.CountryName != undefined && request.CountryName != '') {
        where += ' AND cm.CountryName=? ';
        where_array.push(request.CountryName);
    }
    // end of border

    if (request.PropertyTypeId != undefined && _.size(request.PropertyTypeId) > 0 && _.isArray(request.PropertyTypeId)) {
        where += '';
        let where_or = '';
        _.each(request.PropertyTypeId, (pData, pIndex) => {
            where_or += (pIndex > 0 ? ' OR' : '') + ' FIND_IN_SET(?, acc.PropertyType) ';
            where_array.push(pData);
        });
        where += (where_or != '' ? ' AND (' + where_or + ')' : '');
    }

    if (request.IsFeature != undefined && request.IsFeature != '' && request.IsFeature != '0') {
        where += ' AND FIND_IN_SET(?, acc.IsFeatures) ';
        where_array.push(request.IsFeature);
    }

    if (request.MinBed != undefined && request.MinBed > 0) {
        where_having += ' AND TotalBeds >= ' + request.MinBed;
    }

    if (request.MaxBed != undefined && request.MaxBed > 0) {
        where_having += ' AND TotalBeds <= ' + request.MaxBed;
    }

    if (request.MinPrice != undefined && request.MinPrice > 0) {
        where += ' AND acc.WeeklyRate >= ? ';
        where_array.push(request.MinPrice);
    }

    if (request.MaxPrice != undefined && request.MaxPrice > 0) {
        where += ' AND acc.WeeklyRate <= ? ';
        where_array.push(request.MaxPrice);
    }

    let order_by = ' ORDER BY acc.IsFeatures, Distance ASC ';
    if (request.SortBy != undefined && request.SortBy != null && request.SortBy.trim() == 'PriceLowHigh') {
        order_by = ' ORDER BY acc.WeeklyRate ASC, Distance ASC ';
    } else if (request.SortBy != undefined && request.SortBy != null && request.SortBy.trim() == 'PriceHighLow') {
        order_by = ' ORDER BY acc.WeeklyRate DESC, Distance ASC ';
    } else if (request.SortBy != undefined && request.SortBy != null && request.SortBy.trim() == 'Distance') {
        order_by = ' ORDER BY acc.IsFeatures, Distance ASC ';
    }

    request.PageNo = (request.PageNo > 0 ? request.PageNo : '1');
    request.Limit = ((request.Limit > 0 && request.Limit <= 50) ? request.Limit : '20');

    let total_query = 'SELECT COUNT(tb.AccommodationID) AS total FROM (SELECT acc.AccommodationID, \
        TRUNCATE((3959 * acos(cos(radians(' + request.Latitude + ')) * cos(radians(acc.Latitude)) * cos(radians(acc.Longitude) - radians(' + request.Longitude + ')) + sin(radians(' + request.Latitude + ')) * sin(radians(acc.Latitude)))), 2) AS Distance, \
        (SELECT CAST(IFNULL(sum(arc.TotalBeds), 0) AS CHAR) FROM Accommodation_RoomCategory AS arc WHERE Active="1" AND arc.AccommodationID=acc.AccommodationID) AS TotalBeds \
        FROM Accommodation AS acc \
        LEFT JOIN Accommodation_Provider AS acc_pro ON acc_pro.ProviderID=acc.ProviderID \
        INNER JOIN Mst_Country AS cm ON cm.CountryID=acc.CountryID \
        INNER JOIN Mst_Country AS cm2 ON cm2.CountryID=acc.CurrencyID \
        INNER JOIN Mst_State AS sm ON sm.StateID=acc.StateID \
        LEFT JOIN Mst_City AS ct ON ct.CityID=acc.CityID \
        WHERE acc.Active="1" ' + where + ' HAVING Distance<=' + request.DistanceRadius + ' ' + where_having + ') AS tb';
    let total_record = await sqlhelper.select(total_query, where_array, (err, res) => {
        if (err || _.size(res) <= 0) {
            console.log(err);
            return 0;
        } else {
            return res[0]['total'];
        }
    });

    let offset = (request.PageNo * request.Limit - request.Limit);
    let acc_query = 'SELECT CAST(acc.AccommodationID AS CHAR) AS AccommodationID, acc.UniqueID, acc.AltAccommodationName as AccommodationName, acc.AddressLine1, acc.AddressLine2, acc.Latitude, acc.Longitude, IF(acc.AccRating!="",acc.AccRating,0) AS AccRating, acc.IsFeatures,acc.ProviderID, \
        IFNULL((SELECT IF(ag.MediaUrl!="", ag.MediaUrl, ag.MediaFile) FROM Accommodation_Gallery AS ag WHERE ag.MediaType="1" AND ag.AccommodationID=acc.AccommodationID ORDER BY ag.DisplayOrder ASC LIMIT 1), "' + process.env.NotImageFound + '") AS ImageUrl, \
        IFNULL(acc_pro.Name, "Ocxee Accommodation") AS ProviderName, IFNULL(acc_pro.ImageUrl, "https://ocxeeadmin.s3.eu-west-2.amazonaws.com/ApiProviderImage/oxcee-logo.svg") AS ProviderImageUrl, \
        CAST(TRUNCATE((3959 * acos(cos(radians(' + request.Latitude + ')) * cos(radians(acc.Latitude)) * cos(radians(acc.Longitude) - radians(' + request.Longitude + ')) + sin(radians(' + request.Latitude + ')) * sin(radians(acc.Latitude)))), 2) AS CHAR) AS Distance, \
        IF(acc_pro.RentyType="" || ISNULL(acc_pro.RentyType),"pw",acc_pro.RentyType) AS RentType, CAST(acc.NightlyRate AS CHAR) AS NightlyRate, CAST(acc.WeeklyRate AS CHAR) WeeklyRate, CAST(acc.MonthlyRate AS CHAR) AS MonthlyRate, \
        IFNULL(cm2.CurrencySymbol, "") AS CurrencySymbol, \
        (SELECT CAST(IF(sum(arc.TotalBeds)>0,sum(arc.TotalBeds) ,1) AS CHAR) FROM Accommodation_RoomCategory AS arc WHERE Active="1" AND arc.AccommodationID=acc.AccommodationID) AS TotalBeds, \
        (SELECT IF(COUNT(wl.WishlistID)>0,"1","0") FROM Accommodation_Wishlist AS wl WHERE wl.AccommodationID=acc.AccommodationID AND wl.StudentID="' + request.UserId + '") AS IsWishlist, \
        IFNULL(cm.CountryName,"") AS CountryName, IFNULL(sm.StateName,"") AS StateName, IFNULL(ct.CityName,"") AS CityName \
        FROM Accommodation AS acc \
        LEFT JOIN Accommodation_Provider AS acc_pro ON acc_pro.ProviderID=acc.ProviderID \
        INNER JOIN Mst_Country AS cm ON cm.CountryID=acc.CountryID \
        INNER JOIN Mst_Country AS cm2 ON cm2.CountryID=acc.CurrencyID \
        INNER JOIN Mst_State AS sm ON sm.StateID=acc.StateID \
        LEFT JOIN Mst_City AS ct ON ct.CityID=acc.CityID \
        WHERE acc.Active="1" ' + where + ' HAVING Distance<=' + request.DistanceRadius + ' ' + where_having + ' ' + order_by + ' LIMIT ' + offset + ', ' + request.Limit;
    var acc_data = await sqlhelper.select(acc_query, where_array, (err, res) => {
        if (err) {
            callback(err, null);
            return 0;
        } else if (_.isEmpty(res)) {
            callback(null, {
                'status': '0',
                'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
                'data': {}
            });
            return 0;
        } else {
            return json_response(res);
        }
    });

    if (acc_data == 0) {
        return;
    }

    var response = {
        'status': '0',
        'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
        'data': {},
    };

    if (acc_data.length > 0) {
        let AccomIdList = _.map(acc_data, 'AccommodationID');
        let ProviderIdList = _.uniq(_.map(acc_data, 'ProviderID'));

        query = "SELECT af.FeaturesName, pv.Image AS ImageUrl, CAST(af.AccommodationID AS CHAR) AS AccommodationID FROM Accommodation_Features AS af INNER JOIN Mst_ParameterValue AS pv ON pv.ParameterValueID=af.FeaturesID WHERE af.FeaturesID IN(1,2,11,13,14) AND af.AccommodationID IN(" + AccomIdList.join(',') + ") ORDER BY pv.DisplayOrder ASC";
        var feature_tmp = await sqlhelper.select(query, [], (err, res) => {
            if (err) {
                console.log(err);
                return [];
            } else {
                return json_response(res);
            }
        });

        var feature_data = {};
        _.each(feature_tmp, (fData, fIndex) => {
            if (feature_data[fData.AccommodationID] == undefined) {
                feature_data[fData.AccommodationID] = [];
            }
            feature_data[fData.AccommodationID].push({
                'Text': fData.FeaturesName,
                'ImageUrl': fData.ImageUrl,
            });
        });

        let offer_query = "SELECT AccommodationID,Offer FROM `Accommodation_Offer` where `AccommodationID` IN(" + AccomIdList.join(',') + ") and Active='1' order by DisplayOrder ASC";
        var offer_tmp = await sqlhelper.select(offer_query, [], (err, res) => {
            if (err) {
                console.log(err);
                return [];
            } else {
                return json_response(res);
            }
        });

        var offer_data = {};
        _.each(offer_tmp, (oData, fIndex) => {
            if (offer_data[oData.AccommodationID] == undefined) {
                offer_data[oData.AccommodationID] = [];
            }
            offer_data[oData.AccommodationID].push(oData.Offer);
        });

        let common_offer_query = "SELECT ProviderID,Offer FROM `Accommodation_Offer_Common` where `ProviderID` IN(" + ProviderIdList.join(',') + ") and Active='1' order by DisplayOrder ASC";
        var common_offer_tmp = await sqlhelper.select(common_offer_query, [], (err, res) => {
            if (err) {
                console.log(err);
                return [];
            } else {
                return json_response(res);
            }
        });

        var common_offer_data = {};
        _.each(common_offer_tmp, (coData, fIndex) => {
            if (common_offer_data[coData.AccommodationID] == undefined) {
                common_offer_data[coData.AccommodationID] = [];
            }
            common_offer_data[coData.AccommodationID].push(coData.Offer);
        });

        let gellery_query = 'SELECT ag.AccommodationID, ' + FieldReplace + ' ag.Caption FROM Accommodation_Gallery AS ag WHERE ag.MediaType="1" AND ag.AccommodationID IN(' + AccomIdList.join(',') + ') ORDER BY ag.DisplayOrder ASC';
        var gellery_data = await sqlhelper.select(gellery_query, [], (err, res) => {
            if (err) {
                console.log(err);
                return {};
            } else {
                return _.groupBy(res, 'AccommodationID');
            }
        });

        for (let i = 0; i < acc_data.length; i++) {
            if (process.env.IsShowProviderIcon == 0) {
                acc_data[i]['ProviderImageUrl'] = ''; // Add by Dhiraj 07-04-21
            }

            if (acc_data[i]['AddressLine1'] == '' && acc_data[i]['AddressLine2'] == '') {
                acc_data[i]['AddressLine1'] = acc_data[i]['CityName'] + ', ' + acc_data[i]['StateName'] + ', ' + acc_data[i]['CountryName'];
            }

            if (feature_data[acc_data[i]['AccommodationID']] != undefined) {
                acc_data[i]['feature_list'] = feature_data[acc_data[i]['AccommodationID']];
            } else {
                acc_data[i]['feature_list'] = [];
            }

            if (offer_data[acc_data[i]['AccommodationID']] != undefined) {
                acc_data[i]['offer_list'] = offer_data[acc_data[i]['AccommodationID']];
            } else {
                acc_data[i]['offer_list'] = [];
            }

            acc_data[i]['ImageUrlList'] = [{
                'ImageUrl': process.env.NotImageFound,
                'Caption': ''
            }];
            if (gellery_data[acc_data[i]['AccommodationID']] != undefined) {
                let tmp_gellery = _.map(gellery_data[acc_data[i]['AccommodationID']], gData => _.omit(gData, ['AccommodationID'])).splice(0, 5);
                acc_data[i]['ImageUrlList'] = tmp_gellery;
            }

            acc_data[i]['IsFeature'] = '0';
            if (acc_data[i]['IsFeatures'] != '' && acc_data[i]['IsFeatures'].split(',').includes('160')) {
                acc_data[i]['IsFeature'] = '1';
            }
            acc_data[i]['IsOffer'] = '0';
            if (acc_data[i]['IsFeatures'] != '' && acc_data[i]['IsFeatures'].split(',').includes('161')) {
                acc_data[i]['IsOffer'] = '1';
            }
            delete acc_data[i]['IsFeatures'];

            // start generate acc slug
            let AccSlug = await Common.GenerateAccSlug(acc_data[i]['AccommodationName'], acc_data[i]['CountryName'], acc_data[i]['StateName'], acc_data[i]['CityName'], acc_data[i]['UniqueID']);
            acc_data[i]['AccommodationSlug'] = AccSlug;
            delete acc_data[i]['CountryName'];
            delete acc_data[i]['StateName'];
            delete acc_data[i]['CityName'];
            // end generate acc slug
        }
        console.log(acc_data)
        response.status = '1';
        response.message = 'The Data Fetching process is completed successfully.';
        response.data = {
            'CurrentPage': request.PageNo,
            'TotalPage': Math.ceil(total_record / request.Limit).toString(),
            'TotalRecord': total_record.toString(),
            'List': acc_data,
        };
    }
    callback(null, json_response(response));
}

User.GetAccommodationData = async (request, callback) => {
    let where = ' AND acc.AccommodationID=? ';
    let where_array = [request.AccommodationID];
    if (request.Source == '1') {
        // where = '  ';
        where = ' AND (acc.UniqueID=? OR md5(acc.AccommodationID)=?) ';
        where_array = [request.AccommodationID, request.AccommodationID];
    }

    let query = `SELECT CAST(acc.AccommodationID AS CHAR) AS AccommodationID,acc.PropertyLink,acc_pro.ProviderType, acc.UniqueID, acc.AltAccommodationName as AccommodationName, acc.AddressLine1, acc.AddressLine2, acc.PropertyLink, acc.Latitude, acc.Longitude, IFNULL(cm.CountryName, "") AS CountryName, IFNULL(st.StateName, "") AS StateName, IFNULL(ct.CityName, "") AS CityName, acc.PostCode, acc.Area, acc.PropertyType, acc.PropertyDescription, acc.IsFeatures AS FeaturesKey, CAST(acc.NightlyRate AS CHAR) AS NightlyRate, CAST(acc.WeeklyRate AS CHAR) AS WeeklyRate, CAST(acc.MonthlyRate AS CHAR) AS MonthlyRate, IFNULL(cm2.CurrencySymbol, "") AS CurrencySymbol, 
    CAST(acc.ProviderID AS CHAR) AS ProviderID, IFNULL(acc_pro.ParentName, "Ocxee Accommodation") AS ProviderName, IFNULL(acc_pro.ImageUrl, "https://ocxeeadmin.s3.eu-west-2.amazonaws.com/ApiProviderImage/oxcee-logo.svg") AS ProviderImageUrl, 
    acc.MetaTitle, acc.MetaDescription, acc.MetaKeyword, IF(acc.AccRating!="",acc.AccRating,0) AS AccRating, acc.AccSize, IF(acc_pro.RentyType="" || ISNULL(acc_pro.RentyType),"pw",acc_pro.RentyType) AS RentType, DATE_FORMAT(acc.EntryDate, "%Y-%m-%d") AS EntryDate, DATE_FORMAT(acc.UpdateDate, "%Y-%m-%d") AS UpdateDate, 
    (SELECT IF(COUNT(wl.WishlistID)>0,"1","0") FROM Accommodation_Wishlist AS wl WHERE wl.AccommodationID=acc.AccommodationID AND wl.StudentID="' + request.UserId + '") AS IsWishlist, 
    (SELECT IF(COUNT(ar.RatingID)>0,"0","1") FROM Accommodation_Rating AS ar WHERE ar.AccommodationID=acc.AccommodationID AND ar.StudentID="' + request.UserId + '") AS IsReview,acc.Gender,acc.Age,CAST(acc.Active as CHAR) as AccStatus 
    FROM Accommodation AS acc 
    LEFT JOIN Accommodation_Provider AS acc_pro ON acc_pro.ProviderID=acc.ProviderID 
    INNER JOIN Mst_Country AS cm ON cm.CountryID=acc.CountryID 
    INNER JOIN Mst_Country AS cm2 ON cm2.CountryID=acc.CurrencyID 
    INNER JOIN Mst_State AS st ON st.StateID=acc.StateID 
    LEFT JOIN Mst_City AS ct ON ct.CityID=acc.CityID 
    WHERE 1 ` + where + ` LIMIT 1`;
    let acc_data = await sqlhelper.select(query, where_array, (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (res.length <= 0) {
            callback(null, {});
            return 0;
        } else {
            return json_response(res)[0];
        }
    });

    if (acc_data == 0) {
        return;
    }

    let para_value = '';
    if (acc_data['PropertyType'].trim() != '') {
        para_value += acc_data['PropertyType'].trim() + ',';
    }
    if (acc_data['FeaturesKey'] != '') {
        para_value += acc_data['FeaturesKey'].trim() + ',';
    }

    let para_query = 'SELECT ParameterTypeID, ParameterValue AS Name FROM Mst_ParameterValue \
        WHERE ParameterValueID IN ("' + (para_value != '' ? para_value.replace(/(^,)|(,$)/g, "") : 0) + '")';
    let para_data = await sqlhelper.select(para_query, [request.AccommodationID], (err, res) => {
        if (err || _.size(res) <= 0) {
            if (err) console.log(err);
            return {};
        } else {
            return _.groupBy(res, 'ParameterTypeID');
        }
    });
    // console.log(para_data)

    if (process.env.IsShowProviderIcon == 0) {
        acc_data['ProviderImageUrl'] = ''; // Add by Dhiraj 07-04-21
    }

    acc_data['PropertyType'] = [];
    if (para_data['5'] != undefined) {
        acc_data['PropertyType'] = _.map(para_data['5'], 'Name');
    }
    acc_data['FeaturesKey'] = [];
    if (para_data['6'] != undefined) {
        acc_data['FeaturesKey'] = _.map(para_data['6'], 'Name');
    }

    // start generate acc slug
    let AccSlug = await Common.GenerateAccSlug(acc_data['AccommodationName'], acc_data['CountryName'], acc_data['StateName'], acc_data['CityName'], acc_data['UniqueID'], acc_data['AccommodationID']);
    acc_data['AccommodationSlug'] = AccSlug;
    acc_data['AccommodationOutSlug'] = ''

    // let query = `select Acc.*,Acp.ProviderType from Accommodation as Acc left join Accommodation_Provider as Acp on Acp.ProviderID=Acc.ProviderID where AccommodationID=` + AccId
    // let acc_data = await sqlhelper.select(query, [], (err, res) => {
    //     if (err) {
    //         console.log(err)
    //         return 0
    //     } else if (res.length <= 0) {
    //         return 0

    //     } else {
    //         return json_response(res[0]);
    //     }
    // });
    let Idarray = ['549', '3']
    // console.log("549=>" + acc_data['ProviderID'] + " " + Idarray.includes(acc_data['ProviderID']))
    // console.log("1149=>" + acc_data['ProviderType'] + " ")
    //Provider type for live is 1741
    //Provider type for local is 1149
    let AccSlugOut = ''
    let nourl = true
    if (acc_data != 0 && Idarray.includes(acc_data['ProviderID']) && acc_data['ProviderType'] == 1741) {
        AccSlugOut = acc_data['PropertyLink']
        nourl = false
    } else {
        nourl = true
    }

    AccSlugOut = AccSlugOut.split("?")[0];
    acc_data['AccommodationOutSlug'] = AccSlugOut + "?utm_source=ocxee_partners_prospecting_demand&utm_medium=ocxee_xx_xx&utm_campaign=ocxee_dynamic"
    acc_data['IsOurSlug'] = nourl ? false : true
    // console.log(acc_data)
    // end generate acc slug

    let pro_update_info = '';
    if (acc_data['UpdateDate'] != '0000-00-00') {
        pro_update_info = 'Updated on ' + moment(acc_data['UpdateDate'], "YYYY-MM-DD").format('DD/MM/YYYY');
    } else if (acc_data['EntryDate'] != '0000-00-00') {
        pro_update_info = 'Added on ' + moment(acc_data['EntryDate'], "YYYY-MM-DD").format('DD/MM/YYYY');
    }
    acc_data['AccUpdateInfo'] = pro_update_info;

    acc_data['ShareMessage'] = 'Best student accommodation in ' + acc_data['CityName'] + ' ' + acc_data['CountryName'] + ' with affordable prices, world largest marketplace for student services – Accommodation %AccommodationSlug%';
    callback(null, acc_data);
}

User.GetGalleryData = async (AccommodationID, callback) => {
    let query = 'SELECT IF(MediaUrl!="", MediaUrl, MediaFile) AS ImageUrl, CAST(MediaType AS CHAR) AS MediaType, Caption, Description FROM Accommodation_Gallery WHERE Active="1" AND AccommodationID=? ORDER BY DisplayOrder ASC';
    await sqlhelper.select(query, [AccommodationID], (err, res) => {
        if (err) {
            console.log(err);
            callback(null, []);
        } else {
            callback(null, json_response(res));
        }
    });
}

User.GetFeatureData = async (ProviderID, AccommodationID, callback) => {
    let query = `SELECT af.FeaturesName, pv.Image AS ImageUrl, pt.ParameterTypeID, pt.ParameterType 
    FROM Accommodation_Features AS af 
    INNER JOIN Mst_ParameterValue AS pv ON pv.ParameterValueID=af.FeaturesID 
    INNER JOIN Mst_ParameterType pt ON pt.ParameterTypeID=pv.ParameterTypeID AND pv.Active = '1'
    WHERE af.AccommodationID=? ORDER BY pv.DisplayOrder ASC`;
    let feature_tmp = await sqlhelper.select(query, [AccommodationID], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (_.isEmpty(res)) {
            // callback(null, []);
            return [];
        } else {
            return json_response(res);
        }
    });
    if (feature_tmp === 0) {
        return;
    }
    let common_query = `SELECT afc.FeaturesName, pv.Image AS ImageUrl, pt.ParameterTypeID, pt.ParameterType 
    FROM Accommodation_Features_commn AS afc 
    INNER JOIN Mst_ParameterValue AS pv ON pv.ParameterValueID=afc.FeaturesID AND pv.Active = '1'
    INNER JOIN Mst_ParameterType pt ON pt.ParameterTypeID=pv.ParameterTypeID
    WHERE afc.ProviderID=? ORDER BY pv.DisplayOrder ASC`;
    let common_feature_tmp = await sqlhelper.select(common_query, [ProviderID], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (_.isEmpty(res)) {
            return [];
        } else {
            return json_response(res);
        }
    });
    if (common_feature_tmp === 0) {
        return;
    }
    let final_feature_tmp = _.concat(feature_tmp, common_feature_tmp);
    var tmpfeature_data = {};
    var feature_data = [];
    if (final_feature_tmp.length > 0) {
        for (let i = 0; i < final_feature_tmp.length; i++) {
            let tmp_data = final_feature_tmp[i];
            if (tmpfeature_data[tmp_data['ParameterTypeID']] == undefined) {
                tmpfeature_data[tmp_data['ParameterTypeID']] = {
                    'title': tmp_data['ParameterType'],
                    'data': [],
                };
            }
            tmpfeature_data[tmp_data['ParameterTypeID']]['data'].push({
                'Text': tmp_data['FeaturesName'].replace('_', ' '),
                'ImageUrl': tmp_data['ImageUrl'],
            });
        }
        feature_data = Object.values(tmpfeature_data);
    }
    callback(null, feature_data);
}

User.GetRuleData = async (AccommodationID, ProviderID, callback) => {
    let query = '(SELECT Rules, "0" AS IsCommon FROM Accommodation_Rules WHERE Active="1" AND AccommodationID=? ORDER BY DisplayOrder ASC) UNION (SELECT Rules, "1" AS IsCommon FROM Accommodation_Rules_Common WHERE Active="1" AND ProviderID=? ORDER BY DisplayOrder ASC)';
    let rules_data = await sqlhelper.select(query, [AccommodationID, ProviderID], (err, res) => {
        if (err || _.size(res) <= 0) {
            if (err) console.log(err);
            return [];
        } else {
            return json_response(res);
        }
    });
    callback(null, rules_data);
}

User.GetOfferData = async (AccommodationID, ProviderID, callback) => {
    let query = '(SELECT Offer AS Title, Description FROM Accommodation_Offer WHERE Active="1" AND AccommodationID=? ORDER BY DisplayOrder ASC) UNION (SELECT Offer AS Title, Description FROM Accommodation_Offer_Common WHERE Active="1" AND ProviderID=? ORDER BY DisplayOrder ASC)';
    let offer_data = await sqlhelper.select(query, [AccommodationID, ProviderID], (err, res) => {
        if (err || _.size(res) <= 0) {
            if (err) console.log(err);
            return [];
        } else {
            return json_response(res);
        }
    });
    callback(null, offer_data);
}

User.GetContactData = async (AccommodationID, ProviderID, callback) => {
    let query = '(SELECT CONCAT(Prefix," ",Name) AS Name, Designation, PhoneNo, Email, Description FROM Accommodation_Contacts WHERE Active="1" AND AccommodationID=?) UNION (SELECT CONCAT(Prefix," ",Name) AS Name, Designation, PhoneNo, Email, Description FROM Accommodation_Contacts_Common WHERE Active="1" AND ProviderID=?)';
    let contact_data = await sqlhelper.select(query, [AccommodationID, ProviderID], (err, res) => {
        if (err || _.size(res) <= 0) {
            if (err) console.log(err);
            return [];
        } else {
            return json_response(res);
        }
    });
    callback(null, contact_data);
}

User.GetUtilityData = async (AccommodationID, callback) => {
    let query = 'SELECT UtilityName AS Title, Description, Distance, Image AS ImageUrl FROM Accommodation_NearUtility WHERE Active="1" AND AccommodationID=?';
    await sqlhelper.select(query, [AccommodationID], (err, res) => {
        if (err) {
            console.log(err);
            callback(null, []);
        } else {
            callback(null, json_response(res));
        }
    });
}

User.GetFAQData = async (AccommodationID, ProviderID, callback) => {
    let query = '(SELECT Question, Answer FROM Accommodation_FAQ WHERE Active="1" AND AccommodationID=? ORDER BY DisplayOrder ASC) UNION (SELECT Question, Answer FROM Accommodation_FAQ_Common WHERE Active="1" AND ProviderID=? ORDER BY DisplayOrder ASC)';
    let faq_data = await sqlhelper.select(query, [AccommodationID, ProviderID], (err, res) => {
        if (err) {
            console.log(err);
            return [];
        } else {
            return json_response(res);
        }
    });
    callback(null, faq_data);
}

User.GetRoomData = async (AccommodationID, ProviderID, callback) => {
    // let query = 'SELECT CAST(arc.AccRoomCategoryID AS CHAR) AS AccRoomCategoryID, arc.RoomCategory, pv.ParameterValue AS RentTypeName, pv.ParameterValueCode AS RentType, arc.ShortDescription, IFNULL(cm.CurrencySymbol, "") AS CurrencySymbol, CAST(arc.TotalRooms AS CHAR) AS TotalRooms, arc.CarpetArea, CAST(arc.TotalBeds AS CHAR) AS TotalBeds, CAST(arc.DeposoitAmount AS CHAR) AS DeposoitAmount FROM Accommodation_RoomCategory AS arc LEFT JOIN Mst_ParameterValue AS pv ON pv.ParameterValueID=arc.RentTypeID LEFT JOIN Mst_Country AS cm ON cm.CountryID=arc.CurrencyID WHERE arc.AccommodationID=? AND arc.Active="1" ORDER BY arc.DisplayOrder ASC';
    let query = 'SELECT CAST(arc.AccRoomCategoryID AS CHAR) AS AccRoomCategoryID, arc.RoomCategory, pv.ParameterValue AS RentTypeName, "pw" AS RentType, arc.ShortDescription, IFNULL(cm.CurrencySymbol, "") AS CurrencySymbol, CAST(arc.TotalRooms AS CHAR) AS TotalRooms, arc.CarpetArea, CAST(arc.TotalBeds AS CHAR) AS TotalBeds, CAST(arc.DeposoitAmount AS CHAR) AS DeposoitAmount,CAST(arc.MaxOccupancy AS CHAR) AS TotalGuests,CAST(arc.TotalBathRooms AS CHAR) AS TotalBathRooms,CAST(arc.TotalKitchen AS CHAR) AS TotalKitchen FROM Accommodation_RoomCategory AS arc LEFT JOIN Mst_ParameterValue AS pv ON pv.ParameterValueID=arc.RentTypeID LEFT JOIN Mst_Country AS cm ON cm.CountryID=arc.CurrencyID WHERE arc.AccommodationID=? AND arc.Active="1" ORDER BY arc.DisplayOrder ASC';
    let room_temp = await sqlhelper.select(query, [AccommodationID], (err, res) => {
        if (err) {
            console.log(err);
            return [];
        } else {
            return json_response(res);
        }
    });
    let acc_gallery_query = 'SELECT "0" AS AccRoomCategoryID, IF(MediaUrl!="", MediaUrl, MediaFile) AS ImageUrl, CAST(MediaType AS CHAR) AS MediaType, Caption, Description FROM Accommodation_Gallery WHERE Active="1" AND MediaType="1" AND AccommodationID=? ORDER BY DisplayOrder ASC LIMIT 1';
    let acc_gallery_data = await sqlhelper.select(acc_gallery_query, [AccommodationID], (err, res) => {
        if (err) {
            console.log(err);
            return [];
        } else {
            return json_response(res);
        }
    });

    var room_data = [];
    if (room_temp.length > 0) {
        let roomCatIdList = [];
        _.map(room_temp, val => roomCatIdList.push(val.AccRoomCategoryID));

        // let rent_query = 'SELECT CAST(AccRoomCategoryRentID AS CHAR) AS AccRoomCategoryRentID, CAST(rr.AccRoomCategoryID AS CHAR) AS AccRoomCategoryID, IFNULL(pv.ParameterValue, "") AS IntakeType, CAST(rr.MinTenture AS CHAR) AS MinTenture, CAST(rr.MaxTenture AS CHAR) AS MaxTenture, CAST(rr.MinIntakYearID AS CHAR) AS MinIntakYearID, CAST(rr.MaxIntakYearID AS CHAR) AS MaxIntakYearID, CAST(rr.DeposoitAmount AS CHAR) AS DeposoitAmount, CAST(rr.NightlyRate AS CHAR) AS NightlyRate, CAST(rr.WeeklyRate AS CHAR) AS WeeklyRate, CAST(rr.MonthlyRate AS CHAR) AS MonthlyRate, CAST(rr.Status AS CHAR) AS Status, CAST(rr.IsCustom AS CHAR) AS IsCustom, DATE_FORMAT(StartDate, "%Y-%m-%d") AS StartDate, DATE_FORMAT(EndDate, "%Y-%m-%d") AS EndDate FROM Accommodation_RoomCategoryRent AS rr LEFT JOIN Mst_ParameterValue AS pv ON pv.ParameterValueID=rr.IntakeTypeID WHERE rr.Active="1" AND rr.AccRoomCategoryID IN ('+roomCatIdList.join(',')+') ORDER BY rr.AccRoomCategoryRentID ASC';
        let rent_query = 'SELECT CAST(AccRoomCategoryRentID AS CHAR) AS AccRoomCategoryRentID, CAST(rr.AccRoomCategoryID AS CHAR) AS AccRoomCategoryID, IFNULL(IF(IsCustom="1", CONCAT(DATE_FORMAT(StartDate,"%d %b %y")," to ",DATE_FORMAT(EndDate,"%d %b %y")), pv.ParameterValue),"") AS IntakeName, CAST(rr.MinTenture AS CHAR) AS MinTenture, CAST(rr.MaxTenture AS CHAR) AS MaxTenture, CAST(rr.IsDepositType AS CHAR) AS IsDepositType, CAST(rr.DeposoitAmount AS CHAR) AS DeposoitAmount, CAST(rr.NightlyRate AS CHAR) AS NightlyRate, CAST(rr.WeeklyRate AS CHAR) AS WeeklyRate, CAST(rr.MonthlyRate AS CHAR) AS MonthlyRate, CAST(rr.Status AS CHAR) AS Status, IF(StartDate!="0000-00-00" AND IsCustom="1", DATE_FORMAT(StartDate, "%Y-%m-%d"), "") AS StartDate, IF(EndDate!="0000-00-00" AND IsCustom="1", DATE_FORMAT(EndDate, "%Y-%m-%d"), "") AS EndDate,MinIntakYearID,MaxIntakYearID FROM Accommodation_RoomCategoryRent AS rr LEFT JOIN Mst_ParameterValue AS pv ON pv.ParameterValueID=rr.IntakeTypeID WHERE rr.Active="1" AND rr.AccRoomCategoryID IN (' + roomCatIdList.join(',') + ') ORDER BY rr.RentAmount ASC';
        let rent_data_temp = await sqlhelper.select(rent_query, [], (err, res) => {
            if (err || _.size(res) <= 0) {
                if (err) console.log(err);
                return 0;
            } else {
                // return _.groupBy(res, 'AccRoomCategoryID');
                return json_response(res);
            }
        });


        let rent_data;
        if (rent_data_temp != 0) {
            const FirstRoom = rent_data_temp[0]['AccRoomCategoryID'];
            rent_data = await _.groupBy(rent_data_temp, 'AccRoomCategoryID');
            delete rent_data_temp;
            room_temp = await _.sortBy(room_temp, ({
                AccRoomCategoryID
            }) => AccRoomCategoryID == FirstRoom ? 0 : 1);
            delete FirstRoom;
        } else {
            rent_data = {};
        }


        let gallery_query = 'SELECT CAST(AccRoomCategoryID AS CHAR) AS AccRoomCategoryID, MediaFile AS ImageUrl, CAST(MediaType AS CHAR) AS MediaType, Caption, Description FROM Accommodation_RoomCategoryGallery WHERE Active="1" AND AccRoomCategoryID IN (' + roomCatIdList.join(',') + ') ORDER BY MediaType, DisplayOrder ASC';
        let gallery_data = await sqlhelper.select(gallery_query, [], (err, res) => {
            if (err || _.size(res) <= 0) {
                if (err) console.log(err);
                return {};
            } else {
                return _.groupBy(res, 'AccRoomCategoryID');
            }
        });

        let feature_query = 'SELECT af.AccRoomCategoryID, af.FeaturesID, af.FeaturesName, pv.DisplayOrder, pv.Image AS ImageUrl, pt.ParameterTypeID, pt.ParameterType FROM Accommodation_RoomCategoryFeatures AS af INNER JOIN Mst_ParameterValue AS pv ON pv.ParameterValueID=af.FeaturesID AND pv.Active = "1" INNER JOIN Mst_ParameterType pt ON pt.ParameterTypeID=pv.ParameterTypeID WHERE af.AccRoomCategoryID IN (' + roomCatIdList.join(',') + ') ORDER BY pv.DisplayOrder ASC';
        let feature_data = await sqlhelper.select(feature_query, [], (err, res) => {
            if (err || _.size(res) <= 0) {
                if (err) console.log(err);
                return {};
            } else {
                return _.groupBy(res, 'AccRoomCategoryID');
            }
        });

        let common_query = `SELECT arfc.FeaturesName, pv.Image AS ImageUrl, pt.ParameterTypeID, pt.ParameterType 
        FROM Accommodation_RoomCategoryFeatures_Common AS arfc 
        INNER JOIN Mst_ParameterValue AS pv ON pv.ParameterValueID=arfc.FeaturesID AND pv.Active = '1'
        INNER JOIN Mst_ParameterType pt ON pt.ParameterTypeID=pv.ParameterTypeID
        WHERE arfc.ProviderID=? ORDER BY pv.DisplayOrder ASC`;
        let common_feature_tmp = await sqlhelper.select(common_query, [ProviderID], (err, res) => {
            if (err) {
                callback(json_response(err), null);
                return 0;
            } else if (_.isEmpty(res)) {
                return [];
            } else {
                return json_response(res);
            }
        });
        if (common_feature_tmp === 0) {
            return;
        }
        let new_feature_array = [];
        // for (const [key,value] of Object.entries(Object.keys(feature_data))) {}
        _.each(room_temp, (rData, rIndex) => {
            if (feature_data[rData['AccRoomCategoryID']]) {
                new_feature_array[rData['AccRoomCategoryID']] = _.uniqBy(_.concat(feature_data[rData['AccRoomCategoryID']], common_feature_tmp), 'FeaturesName');
            } else {
                new_feature_array[rData['AccRoomCategoryID']] = _.uniqBy(common_feature_tmp, 'FeaturesName');
            }
            if (rent_data[rData['AccRoomCategoryID']] != undefined) {
                rData['rent_list'] = rent_data[rData['AccRoomCategoryID']];

                _.each(rData['rent_list'], (rlData, rlIndex) => {
                    if (parseFloat(rData['rent_list'][rlIndex]['DeposoitAmount']) <= 0) {
                        rData['rent_list'][rlIndex]['DeposoitAmount'] = rData['DeposoitAmount'];
                    }

                    if (rData['rent_list'][rlIndex]['StartDate'] == '' && rData['rent_list'][rlIndex]['EndDate'] == '' && rData['rent_list'][rlIndex]['IntakeName'] != '') {
                        // console.log(rData['rent_list'][rlIndex]['IntakeName']);
                        let newIntakeName = ''
                        if (rData['rent_list'][rlIndex]['IntakeName'].includes(' to ')) {
                            let newIntakeArray = rData['rent_list'][rlIndex]['IntakeName'].split(' to ');
                            newIntakeName = newIntakeArray[0] + ' ' + rData['rent_list'][rlIndex]['MinIntakYearID'] + ' to ' + newIntakeArray[1] + ' ' + rData['rent_list'][rlIndex]['MaxIntakYearID']
                            // console.log(newIntakeName);
                        } else if (rData['rent_list'][rlIndex]['IntakeName'] != 'All Intake') {
                            if (rData['rent_list'][rlIndex]['MinIntakYearID'] == rData['rent_list'][rlIndex]['MaxIntakYearID']) {
                                newIntakeName = rData['rent_list'][rlIndex]['IntakeName'] + ' ' + rData['rent_list'][rlIndex]['MinIntakYearID'];
                            } else {
                                newIntakeName = rData['rent_list'][rlIndex]['IntakeName'] + ' ' + rData['rent_list'][rlIndex]['MinIntakYearID'] + ' to ' + rData['rent_list'][rlIndex]['IntakeName'] + ' ' + rData['rent_list'][rlIndex]['MaxIntakYearID'];
                            }
                        } else {
                            newIntakeName = rData['rent_list'][rlIndex]['IntakeName'];
                        }
                        rData['rent_list'][rlIndex]['IntakeName'] = newIntakeName;
                    }
                    delete rData['rent_list'][rlIndex]['MinIntakYearID'];
                    delete rData['rent_list'][rlIndex]['MaxIntakYearID'];

                    if (rData['rent_list'][rlIndex]['IsDepositType'] == '1' && parseFloat(rData['rent_list'][rlIndex]['DeposoitAmount']) > 0) {
                        rData['rent_list'][rlIndex]['DeposoitAmount'] = rData['rent_list'][rlIndex]['DeposoitAmount'] + '%';
                    }
                });
            } else {
                rData['rent_list'] = [];
            }

            if (gallery_data[rData['AccRoomCategoryID']] != undefined) {
                rData['gallery_list'] = gallery_data[rData['AccRoomCategoryID']];
            } else if (acc_gallery_data.length > 0) {
                rData['gallery_list'] = acc_gallery_data;
            } else {
                rData['gallery_list'] = [{
                    'AccRoomCategoryID': '0',
                    'ImageUrl': process.env.NotImageFound,
                    'MediaType': '1',
                    'Caption': '',
                    'Description': '',
                }];
            }
            if (new_feature_array[rData['AccRoomCategoryID']] != undefined) {
                let feature_tmp = {};
                _.each(new_feature_array[rData['AccRoomCategoryID']], (ft_data) => {
                    if (feature_tmp[ft_data['ParameterTypeID']] == undefined) {
                        feature_tmp[ft_data['ParameterTypeID']] = {
                            'title': ft_data['ParameterType'],
                            'data': [],
                        };
                    }
                    feature_tmp[ft_data['ParameterTypeID']]['data'].push({
                        'Text': ft_data['FeaturesName'],
                        'ImageUrl': ft_data['ImageUrl'],
                    });
                });
                rData['feature_list'] = Object.values(feature_tmp);
                // console.log(rData['feature_list']);
            } else {
                rData['feature_list'] = [];
            }
            room_data.push(rData);
        });
    }
    callback(null, room_data);
}

User.GetPaymentData = async (AccommodationID, ProviderID, callback) => {
    // let query = 'SELECT AccContentID,ContentType as Type, Title, Description FROM Accommodation_Content_Common WHERE ProviderID=?';
    let query = 'SELECT "Payment" as Title, PaymentDescription as Description FROM Accommodation_Provider WHERE ProviderID=?';
    let extra_data = await sqlhelper.select(query, [ProviderID], (err, res) => {
        if (err) {
            console.log(err);
            return {};
        } else {
            if (res.length > 0) return res[0];
            else
                return { Description: '' };
        }
    });
    callback(null, extra_data);
}

User.GetExtraData = async (AccommodationID, ProviderID, callback) => {
    let query = '(SELECT Title, Description FROM Accommodation_Extra WHERE AccommodationID=?) UNION (SELECT Title, Description FROM Accommodation_Extra_Common WHERE ProviderID=?)';
    let extra_data = await sqlhelper.select(query, [AccommodationID, ProviderID], (err, res) => {
        if (err) {
            console.log(err);
            return [];
        } else {
            return res;
        }
    });
    callback(null, extra_data);
}

User.GetReviewData = async (AccommodationID, callback) => {
    let review_query = 'SELECT CONCAT(sm.FirstName, " ", sm.LastName) AS UserName, CAST(ar.AverageRating AS CHAR) AS AverageRating, ar.Review, DATE_FORMAT(ar.ReviewDate, "%d %b %Y") AS ReviewDate FROM Accommodation_Rating AS ar INNER JOIN Student AS sm ON sm.StudentID=ar.StudentID WHERE ar.IsApprove="1" AND ar.AccommodationID=? ORDER BY ar.AverageRating DESC, ar.ReviewDate DESC';
    let review_data_list = await sqlhelper.select(review_query, [AccommodationID], (err, res) => {
        if (err) {
            console.log(err);
            return [];
        } else {
            return res;
        }
    });

    let review_data = {};
    if (review_data_list.length > 0) {
        let avg_review_query = 'SELECT COUNT(ar.RatingID) AS TotalReview, SUM(ar.AverageRating) AS AVGR, SUM(ar.FacilitiesRating) AS FR, SUM(ar.LocationRating) AS LR, SUM(ar.TransportationRating) AS TR, SUM(ar.SafetyRating) AS SR, SUM(ar.StaffRating) AS SFR, SUM(ar.ValueRating) AS VR FROM Accommodation_Rating AS ar WHERE ar.IsApprove="1" AND ar.AccommodationID=?';
        let avg_review_data = await sqlhelper.select(avg_review_query, [AccommodationID], (err, res) => {
            if (err) {
                console.log(err);
                return {};
            } else {
                return res[0];
            }
        });

        review_data.Review = review_data_list[0]['Review'];
        review_data.TotalReview = avg_review_data.TotalReview.toString();
        review_data.AverageRating = (avg_review_data.AVGR > 0 ? (avg_review_data.AVGR / avg_review_data.TotalReview).toFixed(2) : '0');
        review_data.FacilitiesRating = (avg_review_data.FR > 0 ? (avg_review_data.FR / avg_review_data.TotalReview).toFixed(2) : '0');
        review_data.LocationRating = (avg_review_data.LR > 0 ? (avg_review_data.LR / avg_review_data.TotalReview).toFixed(2) : '0');
        review_data.TransportationRating = (avg_review_data.TR > 0 ? (avg_review_data.TR / avg_review_data.TotalReview).toFixed(2) : '0');
        review_data.SafetyRating = (avg_review_data.SR > 0 ? (avg_review_data.SR / avg_review_data.TotalReview).toFixed(2) : '0');
        review_data.StaffRating = (avg_review_data.SFR > 0 ? (avg_review_data.SFR / avg_review_data.TotalReview).toFixed(2) : '0');
        review_data.ValueRating = (avg_review_data.VR > 0 ? (avg_review_data.VR / avg_review_data.TotalReview).toFixed(2) : '0');

        review_data['List'] = review_data_list;
    }
    callback(null, review_data);
}

User.GetPropertiesAroundData = async (request, callback) => {
    let where = ' AND acc.AccommodationID!=? ';
    let where_array = [request.AccommodationID];
    var acc_data = [];
    if (request.Latitude != '' && request.Longitude != '') {
        let acc_query = 'SELECT CAST(acc.AccommodationID AS CHAR) AS AccommodationID, acc.UniqueID, acc.AltAccommodationName as AccommodationName, acc.AddressLine1, acc.AddressLine2, acc.Latitude, acc.Longitude, IF(acc.AccRating!="",acc.AccRating,0) AS AccRating, acc.IsFeatures, \
            IFNULL((SELECT IF(ag.MediaUrl!="", ag.MediaUrl, ag.MediaFile) FROM Accommodation_Gallery AS ag WHERE ag.MediaType="1" AND ag.AccommodationID=acc.AccommodationID ORDER BY ag.DisplayOrder ASC LIMIT 1), "' + process.env.NotImageFound + '") AS ImageUrl, \
            IFNULL(acc_pro.Name, "Ocxee Accommodation") AS ProviderName, IFNULL(acc_pro.ImageUrl, "https://ocxeeadmin.s3.eu-west-2.amazonaws.com/ApiProviderImage/oxcee-logo.svg") AS ProviderImageUrl, \
            CAST(TRUNCATE((3959 * acos(cos(radians(' + request.Latitude + ')) * cos(radians(acc.Latitude)) * cos(radians(acc.Longitude) - radians(' + request.Longitude + ')) + sin(radians(' + request.Latitude + ')) * sin(radians(acc.Latitude)))), 2) AS CHAR) AS Distance, \
            IF(acc_pro.RentyType="" || ISNULL(acc_pro.RentyType),"pw",acc_pro.RentyType) AS RentType, CAST(acc.NightlyRate AS CHAR) AS NightlyRate, CAST(acc.WeeklyRate AS CHAR) WeeklyRate, CAST(acc.MonthlyRate AS CHAR) AS MonthlyRate, \
            IFNULL(cm2.CurrencySymbol, "") AS CurrencySymbol, \
            (SELECT CAST(IFNULL(sum(arc.TotalBeds), 0) AS CHAR) FROM Accommodation_RoomCategory AS arc WHERE Active="1" AND arc.AccommodationID=acc.AccommodationID) AS TotalBeds, \
            (SELECT IF(COUNT(wl.WishlistID)>0,"1","0") FROM Accommodation_Wishlist AS wl WHERE wl.AccommodationID=acc.AccommodationID AND wl.StudentID="' + request.UserId + '") AS IsWishlist, \
            IFNULL(cm.CountryName,"") AS CountryName, IFNULL(sm.StateName,"") AS StateName, IFNULL(ct.CityName,"") AS CityName \
            FROM Accommodation AS acc \
            LEFT JOIN Accommodation_Provider AS acc_pro ON acc_pro.ProviderID=acc.ProviderID \
            INNER JOIN Mst_Country AS cm ON cm.CountryID=acc.CountryID \
            INNER JOIN Mst_Country AS cm2 ON cm2.CountryID=acc.CurrencyID \
            INNER JOIN Mst_State AS sm ON sm.StateID=acc.StateID \
            LEFT JOIN Mst_City AS ct ON ct.CityID=acc.CityID \
            WHERE acc.Active="1" ' + where + ' HAVING Distance<=5 ORDER BY Distance ASC LIMIT 10';
        acc_data = await sqlhelper.select(acc_query, where_array, (err, res) => {
            if (err) {
                console.log(err);
                return [];
            } else {
                return json_response(res);
            }
        });
    }

    if (acc_data.length > 0) {
        let AccomIdList = _.map(acc_data, 'AccommodationID');

        let query = "SELECT af.FeaturesName, pv.Image AS ImageUrl, CAST(af.AccommodationID AS CHAR) AS AccommodationID FROM Accommodation_Features AS af INNER JOIN Mst_ParameterValue AS pv ON pv.ParameterValueID=af.FeaturesID WHERE af.FeaturesID IN(1,2,11,13,14) AND af.AccommodationID IN(" + AccomIdList.join(',') + ") ORDER BY pv.DisplayOrder ASC";
        var feature_tmp = await sqlhelper.select(query, [], (err, res) => {
            if (err) {
                console.log(err);
                return [];
            } else {
                return json_response(res);
            }
        });

        var feature_data = {};
        _.each(feature_tmp, (fData, fIndex) => {
            if (feature_data[fData.AccommodationID] == undefined) {
                feature_data[fData.AccommodationID] = [];
            }
            feature_data[fData.AccommodationID].push({
                'Text': fData.FeaturesName,
                'ImageUrl': fData.ImageUrl,
            });
        });

        let gellery_query = 'SELECT ag.AccommodationID, ' + FieldReplace + ' ag.Caption FROM Accommodation_Gallery AS ag WHERE ag.MediaType="1" AND ag.AccommodationID IN(' + AccomIdList.join(',') + ') ORDER BY ag.DisplayOrder ASC';
        var gellery_data = await sqlhelper.select(gellery_query, [], (err, res) => {
            if (err) {
                console.log(err);
                return {};
            } else {
                return _.groupBy(res, 'AccommodationID');
            }
        });

        for (let i = 0; i < acc_data.length; i++) {
            if (process.env.IsShowProviderIcon == 0) {
                acc_data[i]['ProviderImageUrl'] = ''; // Add by Dhiraj 07-04-21
            }

            if (acc_data[i]['AddressLine1'] == '' && acc_data[i]['AddressLine2'] == '') {
                acc_data[i]['AddressLine1'] = acc_data[i]['CityName'] + ', ' + acc_data[i]['StateName'] + ', ' + acc_data[i]['CountryName'];
            }

            if (feature_data[acc_data[i]['AccommodationID']] != undefined) {
                acc_data[i]['feature_list'] = feature_data[acc_data[i]['AccommodationID']];
            } else {
                acc_data[i]['feature_list'] = [];
            }

            acc_data[i]['ImageUrlList'] = [{
                'ImageUrl': process.env.NotImageFound,
                'Caption': ''
            }];
            if (gellery_data[acc_data[i]['AccommodationID']] != undefined) {
                let tmp_gellery = _.map(gellery_data[acc_data[i]['AccommodationID']], gData => _.omit(gData, ['AccommodationID'])).splice(0, 5);
                acc_data[i]['ImageUrlList'] = tmp_gellery;
            }

            acc_data[i]['IsFeature'] = '0';
            if (acc_data[i]['IsFeatures'] != '' && acc_data[i]['IsFeatures'].split(',').includes('160')) {
                acc_data[i]['IsFeature'] = '1';
            }

            acc_data[i]['IsOffer'] = '0';
            if (acc_data[i]['IsFeatures'] != '' && acc_data[i]['IsFeatures'].split(',').includes('161')) {
                acc_data[i]['IsOffer'] = '1';
            }
            delete acc_data[i]['IsFeatures'];

            // start generate acc slug
            let AccSlug = await Common.GenerateAccSlug(acc_data[i]['AccommodationName'], acc_data[i]['CountryName'], acc_data[i]['StateName'], acc_data[i]['CityName'], acc_data[i]['UniqueID']);
            acc_data[i]['AccommodationSlug'] = AccSlug;
            delete acc_data[i]['CountryName'];
            delete acc_data[i]['StateName'];
            delete acc_data[i]['CityName'];
            // end generate acc slug
        }
    }
    callback(null, json_response(acc_data));
}

User.AccommodationViewEntry = async (request, callback) => {
    let current_date = moment().format('YYYY-MM-DD');
    let view_query = 'SELECT ViewID FROM Accommodation_View WHERE AccommodationID=? AND StudentID=? AND DATE(ViewDate)=? LIMIT 1';
    let ViewID = await sqlhelper.select(view_query, [request.AccommodationID, request.UserId, current_date], (err, res) => {
        if (err || _.isEmpty(res)) {
            return 0;
        } else {
            return res[0]['ViewID'];
        }
    });

    if (ViewID > 0) {
        let update_query = 'UPDATE Accommodation_View SET ViewCount=ViewCount+1 WHERE ViewID=?';
        await sqlhelper.select(update_query, [ViewID], (err, res) => {
            if (err) console.log(err);
        });
    } else {
        var insert_data = {
            'AccommodationID': request.AccommodationID,
            'StudentID': request.UserId,
            'ViewCount': '1',
            'ViewDate': moment().format('YYYY-MM-DD HH:mm:ss'),
        };

        ViewID = await sqlhelper.insert('Accommodation_View', insert_data, (err, res) => {
            if (err) {
                return 0;
            } else {
                return res.insertId;
            }
        });
    }
    callback(null, {
        'status': '1',
        'message': 'Dear user your entry for accommodation has been viewed; we will update you soon.',
        'data': {
            'ViewID': ViewID
        }
    });
}
User.AccommodationViewEntry2 = async (request, callback) => {
    let current_date = moment().format('YYYY-MM-DD');
    // let view_query = 'SELECT ViewID FROM Accommodation_View WHERE AccommodationID=? AND StudentID=? AND DATE(ViewDate)=? LIMIT 1';
    // let ViewID = await sqlhelper.select(view_query, [request.AccommodationID, request.UserId, current_date], (err, res) => {
    //     if (err || _.isEmpty(res)) {
    //         return 0;
    //     } else {
    //         return res[0]['ViewID'];
    //     }
    // });

    // if (ViewID > 0) {
    //     let update_query = 'UPDATE Accommodation_View SET ViewCount=ViewCount+1 WHERE ViewID=?';
    //     await sqlhelper.select(update_query, [ViewID], (err, res) => {
    //         if (err) console.log(err);
    //     });
    // } else {
    var insert_data = {
        'AccommodationID': request.AccommodationID,
        'StudentID': request.UserId,
        'ViewCount': '1',
        'ViewDate': moment().format('YYYY-MM-DD HH:mm:ss'),
    };

    ViewID = await sqlhelper.insert('Acc_MarketPlaceView', insert_data, (err, res) => {
        if (err) {
            return 0;
        } else {
            return res.insertId;
        }
    });
    // }
    callback(null, {
        'status': '1',
        'message': 'Dear user your entry for accommodation has been viewed; we will update you soon.',
        'data': {
            'ViewID': ViewID
        }
    });
}

User.CalculateRoomRent = async (request, callback) => {
    let rent_query = '';
    let rent_where = [];
    if (request.AccRoomCategoryID > 0 && request.AccRoomCategoryRentID > 0) {
        rent_query = 'SELECT CAST(rcr.NightlyRate AS CHAR) AS NightlyRate, CAST(rcr.WeeklyRate AS CHAR) AS WeeklyRate, CAST(rcr.MonthlyRate AS CHAR) AS MonthlyRate, rcr.IsDepositType, CAST(IF(rcr.DeposoitAmount>0,rcr.DeposoitAmount,arc.DeposoitAmount) AS CHAR) AS DeposoitAmount, CAST(rcr.CleaningCharge AS CHAR) AS CleaningCharge, CAST(rcr.EstimatedBills AS CHAR) AS EstimatedBills, CAST(rcr.AgencyFee AS CHAR) AS AdministratorFees FROM Accommodation_RoomCategory AS arc INNER JOIN Accommodation_RoomCategoryRent AS rcr ON rcr.AccRoomCategoryID=arc.AccRoomCategoryID WHERE arc.Active="1" AND rcr.Active="1" AND rcr.AccommodationID=? AND rcr.AccRoomCategoryID=? AND rcr.AccRoomCategoryRentID=? LIMIT 1';
        rent_where = [request.AccommodationID, request.AccRoomCategoryID, request.AccRoomCategoryRentID];
    } else {
        rent_query = 'SELECT CAST(acc.NightlyRate AS CHAR) AS NightlyRate, CAST(acc.WeeklyRate AS CHAR) AS WeeklyRate, CAST(acc.MonthlyRate AS CHAR) AS MonthlyRate, "0" AS IsDepositType, "0.00" AS DeposoitAmount, "0.00" AS CleaningCharge, "0.00" AS EstimatedBills, "0.00" as AdministratorFees FROM Accommodation AS acc WHERE acc.Active="1" AND acc.AccommodationID=? LIMIT 1';
        rent_where = [request.AccommodationID];
    }

    let rent_data = await sqlhelper.select(rent_query, rent_where, (err, res) => {
        if (err) {
            console.log(err);
            return [];
        } else {
            return json_response(res);
        }
    });

    var response = {
        'status': '0',
        'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
    };

    if (rent_data.length > 0) {
        let TotalDays = moment(request.EndDate).diff(moment(request.StartDate), 'days');

        let data = {};
        data['PerNightRate'] = rent_data[0]['NightlyRate'];
        data['TotalDays'] = TotalDays.toString();
        // data['RentComment'] = '[' + TotalDays + '(day\'s) * ' + data['PerNightRate'] + '(pn price)]';
        data['RentComment'] = TotalDays + '(day\'s) * ' + data['PerNightRate'] + '(pn price)';
        data['RentAmount'] = (data['PerNightRate'] * TotalDays).toFixed(2);

        data['DepositComment'] = '';
        data['DepositAmount'] = rent_data[0]['DeposoitAmount'];
        if (rent_data[0]['IsDepositType'] == '1' && parseFloat(data['DepositAmount']) > 0) {
            data['DepositComment'] = data['DepositAmount'] + '% of total amount';
            data['DepositAmount'] = ((data['RentAmount'] * data['DepositAmount']) / 100).toFixed(2);
        }


        data['CleaningCharge'] = rent_data[0]['CleaningCharge'];
        data['EstimatedBills'] = rent_data[0]['EstimatedBills'];
        data['AdministratorFees'] = rent_data[0]['AdministratorFees'];
        data['TotalAmount'] = (parseFloat(data['RentAmount']) + parseFloat(data['DepositAmount']) + parseFloat(data['CleaningCharge']) + parseFloat(data['EstimatedBills']) + parseFloat(data['AdministratorFees'])).toFixed(2);

        let PriceList = [
            { 'label': 'Rent Amount', 'cost': data['RentAmount'] },
            { 'label': 'Deposit Amount', 'cost': data['DepositAmount'] },
            { 'label': 'Cleaning Charge', 'cost': data['CleaningCharge'] },
            { 'label': 'Estimated Bills', 'cost': data['EstimatedBills'] },
            { 'label': 'Administrator Fees', 'cost': data['AdministratorFees'] }
        ];

        data['PriceList'] = PriceList;

        response = {
            'status': '1',
            'message': 'Hello user, your request for room-pricing has been fetched. Please check and download the price-lists.',
            'data': data
        }
    }

    return callback(null, json_response(response));
}

User.GetServiceData = async (request, callback) => {
    // let query = 'SELECT CAST(sm.ServiceID AS CHAR) AS ServiceID, sm.Name AS ServiceName, sm.MediaImage AS ImageUrl, sm.PageTitle, sm.BannerTitle, sm.BannerDescription, sm.BannerImage, sm.SeoTitle, sm.SeoDescription, sm.SeoKeyword FROM Mst_Services AS sm WHERE sm.Active="1" AND sm.ServiceID=? LIMIT 1';
    let query = 'SELECT CAST(sm.ServiceID AS CHAR) AS ServiceID, sm.Name AS ServiceName, sm.MediaImage AS ImageUrl,sm.Alt, sm.PageTitle, sm.SeoTitle, sm.SeoDescription, sm.SeoKeyword FROM Mst_Services AS sm WHERE sm.Active="1" AND sm.ServiceID=? LIMIT 1';
    let service_data = await sqlhelper.select(query, [request.ServiceID], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (res.length <= 0) {
            // callback(null, {});
            return {};
        } else {
            return json_response(res)[0];
        }
    });
    if (service_data == 0) {
        return false;
    }

    let banner_query = 'SELECT si.Text AS Title, si.Description, si.Image AS ImageUrl,si.Url FROM Service_Images AS si WHERE si.ServiceID=? ORDER BY si.DisplayOrder ASC';
    let banner_data = await sqlhelper.select(banner_query, [request.ServiceID], (err, res) => {
        if (err) {
            return [];
        } else {
            return json_response(res);
        }
    });

    service_data['banner_data'] = banner_data;
    callback(null, service_data);
}

User.GetServiceProviderData = async (request, callback) => {
    console.log(request)
    let where_having = '';
    let where_array = [request.ServiceID];
    // if (request.Search!=undefined && request.Search.trim()!='') {
    //     where_having += ' HAVING (ProviderName LIKE ? OR FIND_IN_SET(?, CountryNameList)) ';
    //     where_array.push('%'+request.Search+'%');
    //     where_array.push(request.Search);
    // }

    if (request.Search != undefined && request.Search.trim() != '') {
        where_having += ' HAVING (ProviderName LIKE ? OR CountryNameList LIKE ?) ';
        where_array.push('%' + request.Search + '%');
        where_array.push('%' + request.Search + '%');
    }
    if (request.pname != undefined && request.pname != '') {
        where_having += ' AND sp.Name=?';
        request.pname=request.pname.replace(/_/g," ")
        where_array.push(request.pname);
        where_array.push(request.pname);
    }
    let pro_query = 'SELECT IF(sp.Type="", "0", sp.Type) AS ServiceTypeID, CAST(sp.ServiceProviderID AS CHAR) AS ProviderID, sp.Name AS ProviderName, sp.ProviderURL AS ProviderUrl, sp.LinkName AS BtnName, sp.ShortDescription, sp.DetailDescription AS LongDescription, sp.MediaImage AS ImageUrl,sp.IsApi, \
    (SELECT GROUP_CONCAT(cmm1.CountryName) FROM Mst_Country as cmm1 WHERE FIND_IN_SET(cmm1.CountryID, spm.CountryID)) AS CountryNameList,sp.Alt \
    FROM Mst_ServicesProviderMapping AS spm INNER JOIN Mst_ServicesProvider AS sp ON sp.ServiceProviderID=spm.ServiceProviderID WHERE spm.Active="1" AND sp.Active="1" AND spm.ServiceID=? ' + where_having + ' ORDER BY spm.DisplayOrder ASC';

    let pro_tmp_data = await sqlhelper.select(pro_query, where_array, (err, res) => {
        if (err) {
            console.log(err);
            return [];
        } else {
            return res;
        }
    });
    let pro_data = {};
    _.each(pro_tmp_data, (pData, pIndex) => {
        if (pro_data[pData['ServiceTypeID']] == undefined) {
            pro_data[pData['ServiceTypeID']] = [];
        }
        pro_data[pData['ServiceTypeID']].push({
            'ProviderID': pData['ProviderID'],
            'ProviderName': pData['ProviderName'],
            'ProviderUrl': pData['ProviderUrl'],
            'BtnName': pData['BtnName'],
            'ShortDescription': pData['ShortDescription'],
            'LongDescription': pData['LongDescription'],
            'ImageUrl': (pData['ImageUrl'] != '' ? pData['ImageUrl'] : process.env.NotImageFound),
            'IsApi': pData['IsApi'],
        });
    });

    let stype_query = 'SELECT CAST(st.ServiceTypeID AS CHAR) AS Id, st.Type AS Title FROM Mst_ServicesType AS st WHERE st.Active="1" AND st.ServiceID=' + request.ServiceID + ' ORDER BY st.ServiceTypeID ASC';
    let stype_data = await sqlhelper.select(stype_query, [], (err, res) => {
        if (err) {
            console.log(err);
            return [];
        } else {
            return json_response(res);
        }
    });

    if (stype_data.length > 0) {
        _.each(stype_data, (sData, sIndex) => {

            stype_data[sIndex]['List'] = [];
            if (pro_data[sData['Id']] != undefined) {
                stype_data[sIndex]['List'] = pro_data[sData['Id']];
            }
        });
    }

    if (pro_data['0'] != undefined && pro_data['0'].length > 0) {
        stype_data.push({
            'Id': '',
            'Title': '',
            'List': pro_data['0'],
        });
    }
    callback(null, stype_data);
}

User.GetServiceSectionData = async (request, callback) => {
    let query = 'SELECT ss.SectionID, ss.SectionType, ss.SectionTitle, ss.SectionDes, ssi.ItemTitle, ssi.ItemDes, ssi.ItemImage FROM Mst_Services_Section AS ss INNER JOIN Mst_Services_Section_Item AS ssi ON ssi.SectionID=ss.SectionID WHERE ss.ServiceID=? ORDER BY ss.DisplayOrder ASC, ssi.DisplayOrder ASC';
    let ss_data = await sqlhelper.select(query, [request.ServiceID], (err, res) => {
        if (err) {
            console.log(err);
            return [];
        } else {
            return json_response(res);
        }
    });

    var ss_final_data = {};
    _.each(ss_data, (sData, sIndex) => {
        if (ss_final_data[sData['SectionID'] + '-' + sData['SectionType']] == undefined) {
            ss_final_data[sData['SectionID'] + '-' + sData['SectionType']] = {
                'Type': sData['SectionType'].toString(),
                'Title': sData['SectionTitle'],
                'Description': sData['SectionDes'],
                'List': [],
            }
        }
        ss_final_data[sData['SectionID'] + '-' + sData['SectionType']]['List'].push({
            'Title': sData['ItemTitle'],
            'Description': sData['ItemDes'],
            'ImageUrl': sData['ItemImage'],
        });
    });
    ss_final_data = Object.values(ss_final_data);

    callback(null, ss_final_data);
}

User.GetTestimonialData = async (request, callback) => {
    // let where = ' AND wt.ServiceID="0" ';
    let where = '';
    let where_array = [];
    /*if (['2','3','4','5','8','9'].includes(request.ServiceID)) {
        where = ' AND wt.ServiceID=? ';
        where_array.push(request.ServiceID);
    }*/

    if (parseInt(request.ServiceID) > 0) {
        where = ' AND wt.ServiceID=? ';
        where_array = [request.ServiceID];
    }


    let test_query = 'SELECT wt.Name, wt.Gender, wt.Designation, wt.CompanyName, cn.CountryName, sm.Name AS ServiceName, wt.ImageURL AS ImageUrl, IFNULL(wt.VideoURL, "") AS VideoUrl, wt.Description, wt.Rating AS Rating FROM Mst_WebTestimonial AS wt INNER JOIN Mst_Services AS sm ON sm.ServiceID=wt.ServiceID INNER JOIN Mst_Country AS cn ON cn.CountryID=wt.CountryID WHERE wt.Active="1" AND wt.Rating>2 ' + where + ' ORDER BY wt.DisplayOrder ASC, wt.Rating DESC LIMIT 10';
    let test_data = await sqlhelper.select(test_query, where_array, (err, res) => {
        if (err) {
            callback(err, null);
            return 0;
        } else if (res.length <= 0) {
            callback(null, res);
            return 0;
        } else {
            return json_response(res);
        }
    });

    if (test_data == 0) {
        return false;
    }

    _.each(test_data, (tData, tIndex) => {
        if (tData['ImageUrl'] == '' && tData['Gender'] == '0') {
            tData['ImageUrl'] = process.env.DefaultWomanImage;
        } else if (tData['ImageUrl'] == '' && tData['Gender'] == '1') {
            tData['ImageUrl'] = process.env.DefaultManImage;
        }
        tData['Gender'] = (tData['Gender'] == '0' ? 'Female' : 'Male');
        test_data[tIndex] = tData;
    });

    callback(null, test_data);
}

User.GetServiceAutoCompleteList = async (request, callback) => {
    let search_query = 'SELECT UUID() as Id, mn.Text FROM ( \
        (SELECT sp.Name AS Text FROM Mst_ServicesProviderMapping AS spm INNER JOIN Mst_ServicesProvider AS sp ON sp.ServiceProviderID=spm.ServiceProviderID WHERE spm.ServiceID=? AND sp.Name LIKE ?) \
        UNION (SELECT cn.CountryName AS Text FROM Mst_Country AS cn WHERE cn.CountryName LIKE ?) \
        ) AS mn ORDER BY LENGTH(mn.Text) ASC LIMIT 10';
    await sqlhelper.select(search_query, [request.ServiceID, '%' + request.Search + '%', '%' + request.Search + '%'], (err, res) => {
        if (err) {
            callback(json_response(err), null);
        } else {
            callback(null, json_response(res));
        }
    });
}

User.SubmitServiceEnquiry = async (request, callback) => {
    let Source = 'WEB';
    // console.log(request)
    if (request.Source == '2') {
        Source = 'Android';
        request.PhoneNo_CountryCode = (request.PhoneCode != undefined ? '+' + request.PhoneCode : request.PhoneNo_CountryCode);
    } else if (request.Source == '3') {
        Source = 'IOS';
        request.PhoneNo_CountryCode = (request.PhoneCode != undefined ? '+' + request.PhoneCode : request.PhoneNo_CountryCode);
    }
    let AccLocation = '';
    if (request.AccLocation != undefined && _.size(request.AccLocation) > 0 && _.isArray(request.AccLocation)) {
        AccLocation = JSON.stringify(request.AccLocation);
    }

    let IsNew = 0;
    if (request.UserId == '0') {
        let new_user = {
            'FirstName': request.FirstName,
            'LastName': request.LastName,
            'Email': request.Email,
            'PhoneNo_CountryCode': request.PhoneNo_CountryCode,
            'PhoneNo': request.PhoneNo,
            'EntryIP': request.IpAddress,
            'ChannelPartnerID': request.ChannelPartnerID,
            'EntryDate': moment().format('YYYY-MM-DD HH:mm:ss'),
        }
        request.UserId = await Common.AddGenralStudent(new_user, request.CpName);
        // console.log(request)
    }
    let OrderID = 0
    if (request.ChannelPartnerID != '' && request.ChannelPartnerID != undefined && request.ChannelPartnerID != 0) {
        console.log("Source Is Channel Partner")
        // let Amount = await Common.GetSettingValue('Student_OtherService_Commission');
        let StudentCount = await Common.ReferralStudentCalculation(request.ChannelPartnerID);
        let CommissionData = await Common.GetCommissionCategory(StudentCount);
        let Amount = CommissionData.Commission_Per_services;
        let totalInquiryOrder = await Common.getTotalInquiryOrder(request.UserId, request.ChannelPartnerID);
        var ServiceOrderID = 0;
        let OrderTypeID = '3';
        if (totalInquiryOrder < process.env.CPORDERLIMIT || request.ServiceID == '8') {
            if (request.ServiceID == '8') {
                // let week = 0;
                // week = parseInt((parseInt(request.DurationInMonth) * 30) / 7);
                // if (week > 0) { Amount = await Commom.GetAccCommissionAmount(week); }
                // OrderTypeID = '2';
                OrderTypeID = '2';
                Amount = await Common.GetAccCommissionAmount({ Country: request.CurrentCountry, City: request.CurrentCity });
            }
            let OrderEntry = {
                'UserID': request.ChannelPartnerID,
                'UserType': 'Channel Partner',
                'ReferID': request.UserId,
                'OrderAmount': Amount,
                'Subtotal': Amount,
                'OrderTypeID': OrderTypeID,
                'Status': '1',
                'OrderDate': moment().format('YYYY-MM-DD HH:mm:ss'),
                'OrderNote': "Student Inquiry Order",
            }
            ServiceOrderID = await sqlhelper.insert('User_Order', OrderEntry, (err, res) => {
                if (err) {
                    console.log(err);
                } else {
                    console.log("Order Entry Successfully " + res.insertId);
                    return res.insertId;
                }
            });
        }
        var query = `select * from Student where StudentID=` + request.UserId
        var studveri = await sqlhelper.select(query, [], (err, res) => {
            if (err) {
                console.log(err);
                callback(err, null);
            } else {
                return res[0]
            }
        });
        if (studveri.OrderID == '' || studveri.OfferID == '0') {
            // Amount = await Common.GetSettingValue('Student_Varification_Commission');
            let StudentCount = await Common.ReferralStudentCalculation(request.UserId);
            let CommissionData = await Common.GetCommissionCategory(StudentCount);
            Amount = CommissionData.Commission_Per_Student;
            OrderEntry = {
                'UserID': request.ChannelPartnerID,
                'UserType': 'Channel Partner',
                'ReferID': request.UserId,
                'OrderAmount': Amount,
                'Subtotal': Amount,
                'OrderTypeID': '1',
                'Status': '1',
                'OrderDate': moment().format('YYYY-MM-DD HH:mm:ss'),
                'OrderNote': "New Student Verification No " + request.UserId,
            }
            let studentOrderID = await sqlhelper.insert('User_Order', OrderEntry, (err, res) => {
                if (err) {
                    console.log(err);
                } else {
                    console.log("Order Entry Successfully " + res.insertId);
                    return res.insertId;
                }
            });
            await sqlhelper.update('Student', { 'OrderID': studentOrderID }, { 'StudentID': request.UserId }, (err, res) => {
                if (err) console.log(err);
                else console.log("Stundent Update For Commission");
            });
        }
    }
    let InquiryNo = await generateInquiryNo('0', request.ServiceID);
    let insert_data = {
        'InquiryNo': InquiryNo,
        'StudentID': request.UserId,
        'ChannelPartnerID': (request.ChannelPartnerID != undefined ? request.ChannelPartnerID : '0'),
        'ServiceID': request.ServiceID,
        'InquiryType': (request.InquiryType != undefined ? request.InquiryType : ''),
        'ServiceTypeID': (request.ServiceTypeID != undefined ? request.ServiceTypeID : '0'),
        'ServiceProviderID': (request.ServiceProviderID != undefined ? request.ServiceProviderID : '0'),
        'Source': Source,
        'Type': (request.ChannelPartnerID != '' && request.ChannelPartnerID != undefined && request.ChannelPartnerID != 0) ? '1' : '2', // Student
        'FirstName': request.FirstName,
        'LastName': request.LastName,
        'Email': request.Email,
        'PhoneNo': request.PhoneNo,
        'PhoneNo_CountryCode': (request.PhoneNo_CountryCode != undefined ? request.PhoneNo_CountryCode : ''),

        'CurrentCity': (request.CurrentCity != undefined ? request.CurrentCity : ''),
        'CurrentState': (request.CurrentState != undefined ? request.CurrentState : ''),
        'CurrentCountry': (request.CurrentCountry != undefined ? request.CurrentCountry : ''),
        'CurrentLocation': (request.CurrentLocation != undefined ? request.CurrentLocation : ''),
        'DestinationCity': (request.DestinationCity != undefined ? request.DestinationCity : ''),
        'DestinationState': (request.DestinationState != undefined ? request.DestinationState : ''),
        'DestinationCountry': (request.DestinationCountry != undefined ? request.DestinationCountry : ''),
        'DestinationLocation': (request.DestinationLocation != undefined ? request.DestinationLocation : ''),
        'Remark': request.Remark,
        'CurrencyCode': (request.CurrencyCode != undefined ? request.CurrencyCode : ''),
        'CurrencySymbol': (request.CurrencySymbol != undefined ? request.CurrencySymbol : ''),
        'PropertyType': (request.PropertyType != undefined ? request.PropertyType : ''),
        'MinPrice': (request.MinPrice != undefined ? request.MinPrice : ''),
        'MaxPrice': (request.MaxPrice != undefined ? request.MaxPrice : ''),
        'MinNoOfRooms': (request.MinNoOfRooms != undefined ? request.MinNoOfRooms : ''),
        'MaxNoOfRooms': (request.MaxNoOfRooms != undefined ? request.MaxNoOfRooms : ''),
        'UniversityName': (request.UniversityName != undefined ? request.UniversityName : ''),
        'MoveInDate': (request.MoveInDate != undefined ? request.MoveInDate : ''),
        'DurationInMonth': (request.DurationInMonth != undefined ? request.DurationInMonth : ''),
        'AccLocation': AccLocation,

        'NoOfPerson': (request.NoOfPerson != undefined ? request.NoOfPerson : ''),
        'LoanAmount': (request.LoanAmount != undefined ? request.LoanAmount : ''),
        'TravelDate': (request.TravelDate != undefined ? request.TravelDate : ''),
        'DepatureDate': (request.DepatureDate != undefined ? request.DepatureDate : ''),
        'JourneyDate': (request.JourneyDate != undefined ? request.JourneyDate : ''),

        'Status': '1', // New Inquiry
        'EntryBy': '0',
        'EntryDate': moment().format('YYYY-MM-DD HH:mm:ss'),
        'EntryIP': request.IpAddress,
        'OrderID': request.ChannelPartnerID != undefined && request.ChannelPartnerID != 0 ? ServiceOrderID : 0,
        "IsRefer": request.ChannelPartnerID != undefined && request.ChannelPartnerID != 0 ? 1 : ""
    };

    await sqlhelper.insert('Student_Inquiry', insert_data, async (err, res) => {
        if (err) {
            console.log(err)
            callback(err, null);
        } else if (res.insertId > 0) {
            let HtmlContent =
                '<h3>Thank You!</h3>\
                <h3 class="thankyoumsg">' + request.FirstName + ' ' + request.LastName + ', Your request for ' + request.InquiryType + ' has been successfully submitted.</h3>';

            var data = {
                'HtmlContent': HtmlContent,
            }
            if (request.ChannelPartnerID != undefined && request.ChannelPartnerID != 0) {
                let query = "select CompanyName from ChannelPartner where ChannelPartnerID=?"
                insert_data["PartnerName"] = await sqlhelper.select(query, [request.ChannelPartnerID], (err, res) => {
                    if (err) {
                        // callback(json_response(err), null);
                        return '';
                    } else if (_.isEmpty(res)) {
                        // callback(null, {
                        //     'status': '0',
                        //     'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
                        //     'data': {}
                        // });
                        return '';
                    } else {
                        return res[0].CompanyName
                        // return json_response(res);
                    }
                });
            }
            else
                insert_data["PartnerName"]=''
            // if (insert_data.ServiceID == '14') insert_data.ServiceID = '9';
            await Common.BtrixCRMRequest(insert_data, insert_data.ServiceID);

            let EmailData = await Common.GetEmailTemplate('FrontEnd.Inquiry');
            if (_.size(EmailData) > 0) {
                let fullName = request.FirstName + ' ' + request.LastName;
                let body = EmailData['Body']
                    .replace('{First Name}', fullName)
                    .replace('{Service_Type}', request.InquiryType)
                    .replace('{{RefNo}}', InquiryNo)

                let MailData = {
                    'mail_to': request.Email,
                    'subject': request.InquiryType + " " + EmailData['Subject'],
                    'body': body,
                    'cc_mail': EmailData['CCEmail'],
                };
                await Common.SendEmailSMTP(MailData);
            }

            var tabledata = _.pickBy(insert_data, v => v !== '' && v !== '0');
            tabledata = _.omit(tabledata, ['ServiceID', 'ServiceTypeID', 'Source', 'Type', 'Status', 'EntryIP']);

            var htmltable = '';
            _.each(tabledata, function (index, value) {
                const str = value;
                // adding space between strings
                const result = str.replace(/([A-Z])/g, ' $1');
                // converting first character to uppercase and join it to the final string
                const final = result.charAt(0).toUpperCase() + result.slice(1);

                htmltable += '<tr>';
                if (value == 'AccLocation') {
                    htmltable += '<td align="left" ><p>' + final + '</p></td>';
                    var accData = JSON.parse(index);
                    htmltable += '<td align="left">';
                    _.forEach(accData, function (List) {
                        htmltable += '<div class="alocbox">';
                        htmltable += '<p><strong>' + List['Location'] + '</strong></p><p>Distance:' + List['Distance'] + '</p>';
                        htmltable += '</div>';
                    });
                    htmltable += '</td>';
                } else {
                    htmltable += '<td align="left" ><p>' + final + '</p></td>';
                    htmltable += '<td align="left" ><p><strong>' + index + '</strong></p></td>';
                }
                htmltable += '</tr>';
            });

            let EmailData1 = await Common.GetEmailTemplate('FrontEnd.CustomerSupport');
            if (_.size(EmailData1) > 0) {
                let body1 = EmailData1['Body']
                    .replace('{{TableData}}', htmltable)

                let MailData1 = {
                    'mail_to': process.env.GMAIL_ACCOUNT,
                    'subject': EmailData1['Subject'],
                    'body': body1,
                    'cc_mail': EmailData1['CCEmail'],
                };
                await Common.SendEmailSMTP(MailData1);
            }
            data["IsNew"] = IsNew
            callback(null, {
                'status': '1',
                // 'message': 'Data Submission completed. Your data has been submitted successfully.',
                'message': 'Thank you! Your enquiry has been successfully received.',
                'data': data
            });
        } else {
            callback(null, {
                'status': '0',
                'message': 'Somthing is wrong.',
                'data': {}
            });
        }
    });
}

User.SubmitPartnerRequestEnquiry = async (request, callback) => {
    let Source = 'WEB';
    if (request.Source == '2') {
        Source = 'Android';
    } else if (request.Source == '3') {
        Source = 'IOS';
    }

    let insert_data = {
        'Source': Source,
        'OrganizationName': request.OrganizationName,
        'OrganizationType': request.OrganizationType,
        'PersonName': request.Name,
        'PersonDesignation': request.Designation,
        'PersonEmail': request.Email,
        'PersonPhoneNoCode': (request.PhoneNoCode != undefined ? request.PhoneNoCode : ''),
        'PersonPhoneNo': request.PhoneNo,
        'ServeCountries': request.ServeCountries,
        'Description': request.Description,
        'EntryDate': moment().format('YYYY-MM-DD HH:mm:ss'),
        'EntryIP': request.IpAddress,
    };

    await sqlhelper.insert('PartnerWithUs_Inquiry', insert_data, (err, res) => {
        if (err) {
            callback(err, null);
        } else if (res.insertId > 0) {
            callback(null, {
                'status': '1',
                'message': 'Data Submission completed. Your data has been submitted successfully.',
                'data': {}
            });
        } else {
            callback(null, {
                'status': '0',
                'message': 'Somthing is wrong.',
                'data': {}
            });
        }
    });
}

User.AddToWishlist = async (request, callback) => {
    let check_query = 'SELECT acc.AccommodationID, (SELECT IF(COUNT(wl.WishlistID)>0,1,0) FROM Accommodation_Wishlist AS wl WHERE wl.AccommodationID=acc.AccommodationID AND wl.StudentID=?) AS IsWishlist FROM Accommodation AS acc WHERE acc.AccommodationID=? AND acc.Active="1" LIMIT 1';
    let check_data = await sqlhelper.select(check_query, [request.UserId, request.AccommodationID], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (_.isEmpty(res)) {
            callback(null, {
                'status': '0',
                'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
                'data': {}
            });
            return 0;
        } else {
            return json_response(res);
        }
    });

    if (check_data == 0) {
        return;
    }

    var response = {
        'status': '0',
        'message': 'Sorry, something went wrong; please check your internet connection or try again later.',
        'data': {}
    };
    if (check_data[0]['IsWishlist'] > 0) {
        let delete_query = 'DELETE FROM Accommodation_Wishlist WHERE StudentID=? AND AccommodationID=?';
        let delete_data = await sqlhelper.select(delete_query, [request.UserId, request.AccommodationID], (err, res) => {
            if (err) {
                callback(null, json_response(err));
                return 0;
            } else {
                return res['affectedRows'];
            }
        });

        if (delete_data == 0) {
            return;
        }

        if (delete_data > 0) {
            response.status = '1';
            response.message = 'Dear user, the accommodation has been removed from the wish-list successfully.';
            response.data.IsWishlist = '0';
        }
    } else {
        let insert_data = {
            'StudentID': request.UserId,
            'AccommodationID': request.AccommodationID,
            'EntryDate': moment().format('YYYY-MM-DD HH:mm:ss'),
        };

        let insert_id = await sqlhelper.insert('Accommodation_Wishlist', insert_data, (err, res) => {
            if (err) {
                callback(null, json_response(err));
                return 0;
            } else {
                return res['insertId'];
            }
        });

        if (insert_id == 0) {
            return;
        }

        if (insert_id > 0) {
            response.status = '1';
            response.message = 'Dear user, the accommodation has been added to your wish-lists.';
            response.data.IsWishlist = '1';


            // added by Parth
            let user_data = await Common.GetStudentDeatils(Number(request.UserId));
            let acc_data = await Common.GetAccDeatils(Number(request.AccommodationID));
            let EmailData = await Common.GetEmailTemplate('FrontEnd.Wishlist');
            if (_.size(EmailData) > 0) {
                let body = EmailData['Body']
                    .replace('{First Name}', user_data['FullName'])
                    .replace('{link}', acc_data['AccSlug'])
                    .replace('{{STUDENT_PANEL_LINK}}', process.env.STUDENT_PANEL_LINK);

                let MailData = {
                    'mail_to': user_data['Email'],
                    'subject': EmailData['Subject'],
                    'body': body,
                    'cc_mail': EmailData['CCEmail'],
                };
                await Common.SendEmailSMTP(MailData);
            }
        }
    }
    return callback(null, json_response(response));
}

User.GetWishlist = async (request, callback) => {
    request.PageNo = (request.PageNo > 0 ? request.PageNo : '1');
    request.Limit = ((request.Limit > 0 && request.Limit <= 50) ? request.Limit : '20');

    let total_query = 'SELECT COUNT(tb.AccommodationID) AS total FROM (SELECT acc.AccommodationID, \
        (SELECT CAST(IFNULL(sum(arc.TotalBeds), 0) AS CHAR) FROM Accommodation_RoomCategory AS arc WHERE Active="1" AND arc.AccommodationID=acc.AccommodationID) AS TotalBeds \
        FROM Accommodation_Wishlist AS wl \
        INNER JOIN Accommodation AS acc ON acc.AccommodationID=wl.AccommodationID \
        LEFT JOIN Accommodation_Provider AS acc_pro ON acc_pro.ProviderID=acc.ProviderID \
        INNER JOIN Mst_Country AS cm ON cm.CountryID=acc.CountryID \
        INNER JOIN Mst_Country AS cm2 ON cm2.CountryID=acc.CurrencyID \
        INNER JOIN Mst_State AS sm ON sm.StateID=acc.StateID \
        LEFT JOIN Mst_City AS ct ON ct.CityID=acc.CityID \
        WHERE acc.Active="1" AND wl.StudentID=?) AS tb';
    let total_record = await sqlhelper.select(total_query, [request.UserId], (err, res) => {
        if (err || _.size(res) <= 0) {
            console.log(err);
            return 0;
        } else {
            return res[0]['total'];
        }
    });

    let offset = (request.PageNo * request.Limit - request.Limit);
    let acc_query = 'SELECT CAST(acc.AccommodationID AS CHAR) AS AccommodationID, acc.UniqueID, acc.AltAccommodationName as AccommodationName, acc.AddressLine1, acc.AddressLine2, acc.Latitude, acc.Longitude, IF(acc.AccRating!="",acc.AccRating,0) AS AccRating, acc.IsFeatures,wl.EntryDate as WishDate,\
        IFNULL((SELECT IF(ag.MediaUrl!="", ag.MediaUrl, ag.MediaFile) FROM Accommodation_Gallery AS ag WHERE ag.MediaType="1" AND ag.AccommodationID=acc.AccommodationID ORDER BY ag.DisplayOrder ASC LIMIT 1), "' + process.env.NotImageFound + '") AS ImageUrl, \
        IFNULL(acc_pro.Name, "Ocxee Accommodation") AS ProviderName, IFNULL(acc_pro.ImageUrl, "https://ocxeeadmin.s3.eu-west-2.amazonaws.com/ApiProviderImage/oxcee-logo.svg") AS ProviderImageUrl, \
        "" AS Distance,IF(acc_pro.RentyType="" || ISNULL(acc_pro.RentyType),"pw",acc_pro.RentyType) AS RentType, CAST(acc.NightlyRate AS CHAR) AS NightlyRate, CAST(acc.WeeklyRate AS CHAR) WeeklyRate, CAST(acc.MonthlyRate AS CHAR) AS MonthlyRate, \
        IFNULL(cm2.CurrencySymbol, "") AS CurrencySymbol, \
        (SELECT CAST(IFNULL(sum(arc.TotalBeds), 1) AS CHAR) FROM Accommodation_RoomCategory AS arc WHERE Active="1" AND arc.AccommodationID=acc.AccommodationID) AS TotalBeds, \
        "1" AS IsWishlist, IFNULL(cm.CountryName,"") AS CountryName, IFNULL(sm.StateName,"") AS StateName, IFNULL(ct.CityName,"") AS CityName \
        FROM Accommodation_Wishlist AS wl \
        INNER JOIN Accommodation AS acc ON acc.AccommodationID=wl.AccommodationID \
        LEFT JOIN Accommodation_Provider AS acc_pro ON acc_pro.ProviderID=acc.ProviderID \
        INNER JOIN Mst_Country AS cm ON cm.CountryID=acc.CountryID \
        INNER JOIN Mst_Country AS cm2 ON cm2.CountryID=acc.CurrencyID \
        INNER JOIN Mst_State AS sm ON sm.StateID=acc.StateID \
        LEFT JOIN Mst_City AS ct ON ct.CityID=acc.CityID \
        WHERE acc.Active="1" AND wl.StudentID=? ORDER BY wl.EntryDate DESC LIMIT ' + offset + ', ' + request.Limit;
    var acc_data = await sqlhelper.select(acc_query, [request.UserId], (err, res) => {
        if (err) {
            callback(err, null);
            return 0;
        } else if (_.isEmpty(res)) {
            callback(null, {
                'status': '0',
                'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
                'data': {}
            });
            return 0;
        } else {
            return json_response(res);
        }
    });

    if (acc_data == 0) {
        return;
    }

    var response = {
        'status': '0',
        'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
        'data': {},
    };

    if (acc_data.length > 0) {
        let AccomIdList = _.map(acc_data, 'AccommodationID');

        query = "SELECT af.FeaturesName, pv.Image AS ImageUrl, CAST(af.AccommodationID AS CHAR) AS AccommodationID FROM Accommodation_Features AS af INNER JOIN Mst_ParameterValue AS pv ON pv.ParameterValueID=af.FeaturesID WHERE af.FeaturesID IN(1,2,11,13,14) AND af.AccommodationID IN(" + AccomIdList.join(',') + ") ORDER BY pv.DisplayOrder ASC";
        var feature_tmp = await sqlhelper.select(query, [], (err, res) => {
            if (err) {
                console.log(err);
                return [];
            } else {
                return json_response(res);
            }
        });

        var feature_data = {};
        _.each(feature_tmp, (fData, fIndex) => {
            if (feature_data[fData.AccommodationID] == undefined) {
                feature_data[fData.AccommodationID] = [];
            }
            feature_data[fData.AccommodationID].push({
                'Text': fData.FeaturesName,
                'ImageUrl': fData.ImageUrl,
            });
        });

        let gellery_query = 'SELECT ag.AccommodationID, ' + FieldReplace + ' ag.Caption FROM Accommodation_Gallery AS ag WHERE ag.MediaType="1" AND ag.AccommodationID IN(' + AccomIdList.join(',') + ') ORDER BY ag.DisplayOrder ASC';
        var gellery_data = await sqlhelper.select(gellery_query, [], (err, res) => {
            if (err) {
                console.log(err);
                return {};
            } else {
                return _.groupBy(res, 'AccommodationID');
            }
        });

        for (let i = 0; i < acc_data.length; i++) {
            if (process.env.IsShowProviderIcon == 0) {
                acc_data[i]['ProviderImageUrl'] = ''; // Add by Dhiraj 07-04-21
            }

            if (acc_data[i]['AddressLine1'] == '' && acc_data[i]['AddressLine2'] == '') {
                acc_data[i]['AddressLine1'] = acc_data[i]['CityName'] + ', ' + acc_data[i]['StateName'] + ', ' + acc_data[i]['CountryName'];
            }

            if (feature_data[acc_data[i]['AccommodationID']] != undefined) {
                acc_data[i]['feature_list'] = feature_data[acc_data[i]['AccommodationID']];
            } else {
                acc_data[i]['feature_list'] = [];
            }

            acc_data[i]['ImageUrlList'] = [{
                'ImageUrl': process.env.NotImageFound,
                'Caption': ''
            }];
            if (gellery_data[acc_data[i]['AccommodationID']] != undefined) {
                let tmp_gellery = _.map(gellery_data[acc_data[i]['AccommodationID']], gData => _.omit(gData, ['AccommodationID'])).splice(0, 5);
                acc_data[i]['ImageUrlList'] = tmp_gellery;
            }

            acc_data[i]['IsFeature'] = '0';
            if (acc_data[i]['IsFeatures'] != '' && acc_data[i]['IsFeatures'].split(',').includes('160')) {
                acc_data[i]['IsFeature'] = '1';
            }

            acc_data[i]['IsOffer'] = '0';
            if (acc_data[i]['IsFeatures'] != '' && acc_data[i]['IsFeatures'].split(',').includes('161')) {
                acc_data[i]['IsOffer'] = '1';
            }
            delete acc_data[i]['IsFeatures'];

            // start generate acc slug
            let AccSlug = await Common.GenerateAccSlug(acc_data[i]['AccommodationName'], acc_data[i]['CountryName'], acc_data[i]['StateName'], acc_data[i]['CityName'], acc_data[i]['UniqueID']);
            acc_data[i]['AccommodationSlug'] = AccSlug;
            delete acc_data[i]['CountryName'];
            delete acc_data[i]['StateName'];
            delete acc_data[i]['CityName'];
            // end generate acc slug
        }

        response.status = '1';
        response.message = 'The Data Fetching process is completed successfully.';
        response.data = {
            'CurrentPage': request.PageNo,
            'TotalPage': Math.ceil(total_record / request.Limit).toString(),
            'TotalRecord': total_record.toString(),
            'List': acc_data,
        };
    }
    callback(null, json_response(response));
}

User.BookingRequest = async (request, callback) => {
    let Source = 'WEB';
    if (request.Source == '2') {
        Source = 'Android';
    } else if (request.Source == '3') {
        Source = 'IOS';
    }

    let rent_query = '';
    let rent_where = [];
    if (request.AccRoomCategoryID > 0 && request.AccRoomCategoryRentID > 0) {
        // rent_query = 'SELECT CAST(rcr.NightlyRate AS CHAR) AS NightlyRate, CAST(rcr.WeeklyRate AS CHAR) AS WeeklyRate, CAST(rcr.MonthlyRate AS CHAR) AS MonthlyRate, CAST(rcr.DeposoitAmount AS CHAR) AS DeposoitAmount FROM Accommodation_RoomCategoryRent AS rcr WHERE rcr.Active="1" AND rcr.AccommodationID=? AND rcr.AccRoomCategoryID=? AND rcr.AccRoomCategoryRentID=?';
        // rent_query = 'SELECT CAST(rcr.NightlyRate AS CHAR) AS NightlyRate, CAST(rcr.WeeklyRate AS CHAR) AS WeeklyRate, CAST(rcr.MonthlyRate AS CHAR) AS MonthlyRate, rcr.IsDepositType, CAST(IF(rcr.DeposoitAmount>0,rcr.DeposoitAmount,arc.DeposoitAmount) AS CHAR) AS DeposoitAmount, CAST(rcr.CleaningCharge AS CHAR) AS CleaningCharge FROM Accommodation_RoomCategory AS arc INNER JOIN Accommodation_RoomCategoryRent AS rcr ON rcr.AccRoomCategoryID=arc.AccRoomCategoryID WHERE arc.Active="1" AND rcr.Active="1" AND rcr.AccommodationID=? AND rcr.AccRoomCategoryID=? AND rcr.AccRoomCategoryRentID=? LIMIT 1';
        rent_query = 'SELECT CAST(rcr.NightlyRate AS CHAR) AS NightlyRate, CAST(rcr.WeeklyRate AS CHAR) AS WeeklyRate, CAST(rcr.MonthlyRate AS CHAR) AS MonthlyRate, rcr.IsDepositType, CAST(IF(rcr.DeposoitAmount>0,rcr.DeposoitAmount,arc.DeposoitAmount) AS CHAR) AS DeposoitAmount, CAST(rcr.CleaningCharge AS CHAR) AS CleaningCharge, CAST(rcr.EstimatedBills AS CHAR) AS EstimatedBills, CAST(rcr.AgencyFee AS CHAR) AS AdministratorFees,arc.RoomCategory AS RoomName,IF(rcr.IsCustom="0",(SELECT ParameterValue FROM Mst_ParameterValue where ParameterValueID = rcr.IntakeTypeID and ParameterTypeID="9"),"") as IntakName,IF(arc.RentTypeID != "0", ( SELECT ParameterValue FROM Mst_ParameterValue where ParameterValueID =arc.RentTypeID and ParameterTypeID = "8" ) , "") as RentType,rcr.RentAmount as Price, mc.CurrencySymbol AS CurrencySymbol,CAST(rcr.Status AS CHAR) as BookingStatus FROM Accommodation_RoomCategory AS arc INNER JOIN Accommodation_RoomCategoryRent AS rcr ON rcr.AccRoomCategoryID=arc.AccRoomCategoryID LEFT JOIN Mst_Country as mc on mc.CountryID=arc.CurrencyID WHERE arc.Active="1" AND rcr.Active="1" AND rcr.AccommodationID=? AND rcr.AccRoomCategoryID=? AND rcr.AccRoomCategoryRentID=? LIMIT 1';
        rent_where = [request.AccommodationID, request.AccRoomCategoryID, request.AccRoomCategoryRentID];
    }
    else if (request.AccRoomCategoryID > 0) {
        rent_query = 'SELECT CAST(acc.NightlyRate AS CHAR) AS NightlyRate, CAST(acc.WeeklyRate AS CHAR) AS WeeklyRate, CAST(acc.MonthlyRate AS CHAR) AS MonthlyRate, "0" AS IsDepositType, "0.00" AS DeposoitAmount, "0.00" AS CleaningCharge, "0.00" AS EstimatedBills,"0.00" AS AdministratorFees, arc.RoomCategory AS RoomName, "" as IntakName, "Week" AS RentType, CAST(acc.WeeklyRate AS CHAR) AS Price, mc.CurrencySymbol AS CurrencySymbol,"" as BookingStatus FROM Accommodation AS acc INNER JOIN Accommodation_RoomCategory AS arc on arc.AccommodationID=acc.AccommodationID LEFT JOIN Mst_Country as mc on mc.CountryID = arc.CurrencyID WHERE arc.Active = "1" AND acc.AccommodationID=? AND arc.AccRoomCategoryID=? LIMIT 1';
        rent_where = [request.AccommodationID, request.AccRoomCategoryID];
    } else {
        // rent_query = 'SELECT CAST(acc.NightlyRate AS CHAR) AS NightlyRate, CAST(acc.WeeklyRate AS CHAR) AS WeeklyRate, CAST(acc.MonthlyRate AS CHAR) AS MonthlyRate, "0" AS IsDepositType, "0.00" AS DeposoitAmount, "0.00" AS CleaningCharge FROM Accommodation AS acc WHERE acc.Active="1" AND acc.AccommodationID=? LIMIT 1';
        rent_query = 'SELECT CAST(acc.NightlyRate AS CHAR) AS NightlyRate, CAST(acc.WeeklyRate AS CHAR) AS WeeklyRate, CAST(acc.MonthlyRate AS CHAR) AS MonthlyRate, "0" AS IsDepositType, "0.00" AS DeposoitAmount, "0.00" AS CleaningCharge, "0.00" AS EstimatedBills,"0.00" AS AdministratorFees,"" AS RoomName,"" AS IntakName,"Week" AS RentType,CAST(acc.WeeklyRate AS CHAR) AS Price,mc.CurrencySymbol AS CurrencySymbol,"" as BookingStatus FROM Accommodation AS acc INNER JOIN Mst_Country as mc on mc.CountryID=acc.CurrencyID WHERE acc.Active="1" AND acc.AccommodationID=? LIMIT 1'; // changed for Currency symbol
        rent_where = [request.AccommodationID];
    }

    let rent_data = await sqlhelper.select(rent_query, rent_where, (err, res) => {
        if (err) {
            console.log(err);
            return [];
        } else {
            return json_response(res);
        }
    });

    var response = {
        'status': '0',
        'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
    };

    if (rent_data.length > 0) {
        let BookingNo = await generateInquiryNo('1', '0');

        let TotalDays = moment(request.EndDate).diff(moment(request.StartDate), 'days');
        let RentAmount = (rent_data[0]['NightlyRate'] * TotalDays).toFixed(2);

        let DepositAmount = rent_data[0]['DeposoitAmount'];
        if (rent_data[0]['IsDepositType'] == '1' && parseFloat(DepositAmount) > 0) {
            DepositAmount = ((RentAmount * DepositAmount) / 100).toFixed(2);
        }

        let CleaningCharge = rent_data[0]['CleaningCharge'];
        let EstimatedBills = rent_data[0]['EstimatedBills'];
        let AdministratorFees = rent_data[0]['AdministratorFees'];
        let CurrencySymbol = rent_data[0]['CurrencySymbol'];
        let Price = CurrencySymbol + rent_data[0]['Price'] + ' per ' + rent_data[0]['RentType'];

        let insert_data = {
            'BookingNo': BookingNo,
            'Source': Source,
            'AccommodationID': request.AccommodationID,
            'AccRoomCategoryID': request.AccRoomCategoryID,
            'StudentID': request.UserId,
            'StudentRemark': (request.Remark != undefined ? request.Remark : ''),
            'StartDate': request.StartDate,
            'EndDate': request.EndDate,
            'CurrencySymbol': CurrencySymbol,
            'Price': Price,
            'RentAmount': RentAmount,
            'DepositAmount': DepositAmount,
            'CleaningCharge': CleaningCharge,
            'EstimatedBills': EstimatedBills,
            'AgencyFee': AdministratorFees,
            'TotalAmount': (parseFloat(RentAmount) + parseFloat(DepositAmount) + parseFloat(CleaningCharge) + parseFloat(EstimatedBills) + parseFloat(AdministratorFees)).toFixed(2),
            'NoOfDays': TotalDays.toString(),
            'BookingDate': moment().format('YYYY-MM-DD'),
            'Status': '1',
            'EntryDate': moment().format('YYYY-MM-DD HH:mm:ss'),
            'EntryIP': request.IpAddress,
        }

        let already_exists = `SELECT * FROM Accommodation_BookingRequest WHERE AccommodationID=${insert_data.AccommodationID} and AccRoomCategoryID=${insert_data.AccRoomCategoryID} and StudentID=${insert_data.StudentID} and StartDate='${insert_data.StartDate}' and EndDate='${insert_data.EndDate}' LIMIT 1`;
        let Is_exists = await sqlhelper.select(already_exists, [], (err, res) => {
            if (err || res.length == 0) {
                console.log(err);
                return false;
            } else if (res.length > 0) {
                return true;
            }
        });

        if (Is_exists) {
            response['status'] = '0';
            response['message'] = 'Your booking request is already existing.';
        } else {
            let BookingID = await sqlhelper.insert('Accommodation_BookingRequest', insert_data, (err, res) => {
                if (err) {
                    console.log(err);
                    return 0;
                } else {
                    return res.insertId;
                }
            });

            response['status'] = '0';
            response['message'] = 'Sorry, something went wrong; please check your internet connection or try again later.';

            if (BookingID > 0) {

                let user_data = await Common.GetStudentDeatils(Number(insert_data.StudentID));
                let acc_data = await Common.GetAccDeatils(Number(insert_data.AccommodationID));
                let EnqTypeField = "";
                request.IsExpired = (request.IsExpired != undefined) ? request.IsExpired : false;
                if (insert_data.RentAmount != '0.00') {
                    EnqTypeField = (rent_data[0]['RoomName'] != "" && rent_data[0]['BookingStatus'] != "3" && !request.IsExpired) ? "Booking" : "Inquiry";
                } else {
                    EnqTypeField = (rent_data[0]['BookingStatus'] != "3" && !request.IsExpired) ? "Price on Request" : "Inquiry";
                }

                let DurationFind = '';
                if (rent_data[0]['RentType'] == 'Week') {
                    let Count = moment(insert_data.EndDate).diff(insert_data.StartDate, 'weeks');
                    DurationFind = Count > 1 ? (Count + ' weeks') : (Count + ' week');
                } else if (rent_data[0]['RentType'] == 'Month') {
                    let Count = moment(insert_data.EndDate).diff(insert_data.StartDate, 'months');
                    DurationFind = Count > 1 ? (Count + ' months') : (Count + ' month');
                } else if (rent_data[0]['RentType'] == 'Year') {
                    let Count = moment(insert_data.EndDate).diff(insert_data.StartDate, 'years');
                    DurationFind = Count > 1 ? (Count + ' years') : (Count + ' year');
                } else {
                    let Count = moment(insert_data.EndDate).diff(insert_data.StartDate, 'days');
                    DurationFind = Count > 1 ? (Count + ' days') : (Count + ' day');
                }


                let BtrixData = {
                    "Name": user_data['FullName'],
                    "Email": user_data['Email'],
                    "Phone": user_data['MobilNumber'],
                    "EnqDate": moment().format('DD-MM-YYYY'),
                    "EnqRefNo": insert_data.BookingNo,
                    "EnqType": EnqTypeField,
                    "AccName": acc_data['AccommodationName'],
                    "AccLoc": acc_data['Location'],
                    "AccCity": acc_data['CityName'],
                    "AccCountry": acc_data['CountryName'],
                    "AccLink": acc_data['AccSlug'],
                    "RoomCategory": rent_data[0]['RoomName'],
                    "Intake": rent_data[0]['IntakName'],
                    "MoveInDate": moment(insert_data.StartDate, "YYYY-MM-DD").format('DD-MM-YYYY'),
                    "MoveOutDate": moment(insert_data.EndDate, "YYYY-MM-DD").format('DD-MM-YYYY'),
                    "Duration": DurationFind,
                    "Price": insert_data.Price,
                    "RentAmt": (insert_data.CurrencySymbol + insert_data.RentAmount),
                    "DepositAmt": (insert_data.CurrencySymbol + insert_data.DepositAmount),
                    "TotalAmt": (insert_data.CurrencySymbol + insert_data.TotalAmount),
                    "Comment": insert_data.StudentRemark
                };
                console.log(BtrixData);
                await Common.BtrixCRMRequest1(BtrixData);

                let HtmlContent =
                    '<div class="thankyoutext">\
                        <svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 365.25 365.25" style="width: 120px; fill: green">\
                            <path d="M539.62,723.25C438.92,723.25,357,641.32,357,540.62S438.92,358,539.62,358a182.23,182.23,0,0,1,96.23,27.38,10.74,10.74,0,1,1-11.33,18.25,160.75,160.75,0,0,0-84.9-24.15c-88.85,0-161.14,72.29-161.14,161.15s72.29,161.13,161.14,161.13,161.14-72.29,161.14-161.14a160.72,160.72,0,0,0-8.62-52.12,10.75,10.75,0,1,1,20.34-6.94,182.27,182.27,0,0,1,9.77,59.07c0,100.69-81.93,182.62-182.63,182.62Zm0,0" transform="translate(-357 -358)"></path>\
                            <path d="M539.62,602.58a10.71,10.71,0,0,1-7.35-2.91l-85.94-80.73A10.74,10.74,0,1,1,461,503.28l77.67,73L679.85,408.7a10.74,10.74,0,1,1,16.43,13.84L547.84,598.76a10.77,10.77,0,0,1-7.59,3.81Zm0,0" transform="translate(-357 -358)"></path>\
                        </svg><br><br>\
                        <h1 style="stext-align:center">Thank you for submitting booking request  with us.</h1>\
                        <br> <br>Your booking request has been sent to our booking department.\
                        <p> One of our Accommodation executive will get back to you Shortly.<br></p>';

                if (user_data['FormProgress'] != 100)
                    HtmlContent += '<p><a href="myaccount#profile">Since your profile is incomplete, we suggest you to complete it. <b class="text-primary"><u>Click here</u></b></a></p>'

                HtmlContent += '<p>Your booking reference number is <b>' + BookingNo + '</b>.</p>\
                    </div>';

                var data = {
                    'HtmlContent': HtmlContent,
                }

                response['status'] = '1';
                response['message'] = 'Dear user, we have received your booking inquiry; our support executive will contact you soon.';
                response['data'] = data;
            }
        }
    }
    return callback(null, json_response(response));
}

User.GetBookingRequestList = async (request, callback) => {
    request.PageNo = (request.PageNo > 0 ? request.PageNo : '1');
    request.Limit = ((request.Limit > 0 && request.Limit <= 50) ? request.Limit : '20');

    let where = '';
    let where_array = [request.UserId];
    if (request.Search != undefined && request.Search.trim() != '') {
        where += ' AND acc.AltAccommodationName LIKE ? ';
        where_array.push('%' + request.Search + '%');
    }

    if (request.PropertyTypeId != undefined && request.PropertyTypeId > 0) {
        where += ' AND FIND_IN_SET(?, acc.PropertyType) ';
        where_array.push(request.PropertyTypeId);
    }
    if (request.StatusID != undefined && request.StatusID.trim() != '') {
        where += ' AND abr.Status=? ';
        where_array.push(request.StatusID);
    }
    if (request.FromDate != undefined && request.FromDate.trim() != '') {
        where += ' AND abr.BookingDate >= ? ';
        where_array.push(request.FromDate);
    }
    if (request.ToDate != undefined && request.ToDate.trim() != '') {
        where += ' AND abr.BookingDate <= ? ';
        where_array.push(request.ToDate);
    }

    let total_query = 'SELECT COUNT(abr.BookingID) AS total \
        FROM Accommodation_BookingRequest AS abr \
        INNER JOIN Accommodation AS acc ON acc.AccommodationID=abr.AccommodationID \
        LEFT JOIN Accommodation_Provider AS acc_pro ON acc_pro.ProviderID=acc.ProviderID \
        LEFT JOIN Mst_Country AS cm ON cm.CountryID=acc.CountryID \
        LEFT JOIN Mst_Country AS cm2 ON cm2.CountryID=acc.CurrencyID \
        WHERE abr.StudentID=? ' + where;
    let total_record = await sqlhelper.select(total_query, where_array, (err, res) => {
        if (err || _.size(res) <= 0) {
            console.log(err);
            return 0;
        } else {
            return res[0]['total'];
        }
    });

    let offset = (request.PageNo * request.Limit - request.Limit);
    let book_query = 'SELECT CAST(abr.BookingID AS CHAR) AS BookingID, CAST(acc.AccommodationID AS CHAR) AS AccommodationID, acc.UniqueID, acc.AltAccommodationName as AccommodationName, acc.AddressLine1, acc.AddressLine2, acc.Latitude, acc.Longitude,case acc_pro.FormType WHEN "0" THEN "Form" WHEN "1" THEN "Data" ELSE "" END as FormType,acc_pro.FilePath, IF(acc.AccRating!="",acc.AccRating,0) AS AccRating, acc.IsFeatures, \
        IFNULL((SELECT IF(ag.MediaUrl!="", ag.MediaUrl, ag.MediaFile) FROM Accommodation_Gallery AS ag WHERE ag.MediaType="1" AND ag.AccommodationID=acc.AccommodationID ORDER BY ag.DisplayOrder ASC LIMIT 1), "' + process.env.NotImageFound + '") AS ImageUrl, \
        acc.ProviderID,IFNULL(acc_pro.Name, "Ocxee Accommodation") AS ProviderName, IFNULL(acc_pro.ImageUrl, "https://ocxeeadmin.s3.eu-west-2.amazonaws.com/ApiProviderImage/oxcee-logo.svg") AS ProviderImageUrl, \
        "" AS RentType, CAST(abr.RentAmount AS CHAR) AS RentAmount, CAST(abr.DepositAmount AS CHAR) DepositAmount, CAST(abr.TotalAmount AS CHAR) AS TotalAmount, \
        IFNULL(cm2.CurrencySymbol, "") AS CurrencySymbol, CAST(abr.NoOfDays AS CHAR) AS NoOfDays, DATE_FORMAT(abr.BookingDate, "%Y-%m-%d") AS BookingDate, CAST(abr.Status AS CHAR) AS Status, IF(abr.StartDate!="0000-00-00", DATE_FORMAT(abr.StartDate, "%Y-%m-%d"), "") AS StartDate, IF(abr.EndDate!="0000-00-00", DATE_FORMAT(abr.EndDate, "%Y-%m-%d"), "") AS EndDate, abr.StudentRemark AS Remark, \
        (SELECT IF(COUNT(wl.WishlistID)>0,"1","0") FROM Accommodation_Wishlist AS wl WHERE wl.AccommodationID=abr.AccommodationID AND wl.StudentID="' + request.UserId + '") AS IsWishlist, \
        IFNULL(cm.CountryName,"") AS CountryName, IFNULL(sm.StateName,"") AS StateName, IFNULL(ct.CityName,"") AS CityName, IFNULL(arc.RoomCategory,"") AS RoomCategory, \
        abr.RatingID,abr.BookingNo,CAST(abr.PayStatus as CHAR) as PayStatus,(SELECT CurrencyCode FROM Mst_Country mc WHERE mc.CountryID=arc.CurrencyID) as currency \
        ,abr.PayAmount,abr.TransactionID,abr.FormUrl, \
        IFNULL(CAST((SELECT BookingID FROM Student_Details2 as sd where sd.BookingID = abr.BookingID limit 1) as CHAR),"0") as IsstudentDetail FROM Accommodation_BookingRequest AS abr \
        INNER JOIN Accommodation AS acc ON acc.AccommodationID=abr.AccommodationID \
        LEFT JOIN Accommodation_RoomCategory AS arc ON arc.AccRoomCategoryID=abr.AccRoomCategoryID \
        LEFT JOIN Accommodation_Provider AS acc_pro ON acc_pro.ProviderID=acc.ProviderID \
        LEFT JOIN Mst_Country AS cm ON cm.CountryID=acc.CountryID \
        LEFT JOIN Mst_Country AS cm2 ON cm2.CountryID=acc.CurrencyID \
        LEFT JOIN Mst_State AS sm ON sm.StateID=acc.StateID \
        LEFT JOIN Mst_City AS ct ON ct.CityID=acc.CityID \
        WHERE abr.StudentID=? ' + where + ' ORDER BY abr.EntryDate DESC LIMIT ' + offset + ', ' + request.Limit;
    var book_data = await sqlhelper.select(book_query, where_array, (err, res) => {
        if (err) {
            callback(err, null);
            return 0;
        } else if (_.isEmpty(res)) {
            callback(null, {
                'status': '0',
                'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
                'data': {}
            });
            return 0;
        } else {
            return json_response(res);
        }
    });

    if (book_data == 0) {
        return;
    }

    var response = {
        'status': '0',
        'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
        'data': {},
    };

    if (book_data.length > 0) {
        let AccomIdList = _.map(book_data, 'AccommodationID');
        let gellery_query = 'SELECT ag.AccommodationID, ' + FieldReplace + ' ag.Caption FROM Accommodation_Gallery AS ag WHERE ag.MediaType="1" AND ag.AccommodationID IN(' + AccomIdList.join(',') + ') ORDER BY ag.DisplayOrder ASC';
        var gellery_data = await sqlhelper.select(gellery_query, [], (err, res) => {
            if (err) {
                console.log(err);
                return {};
            } else {
                return _.groupBy(res, 'AccommodationID');
            }
        });

        for (let i = 0; i < book_data.length; i++) {
            if (process.env.IsShowProviderIcon == 0) {
                book_data[i]['ProviderImageUrl'] = ''; // Add by Dhiraj 07-04-21
            }

            book_data[i]['ImageUrlList'] = [{
                'ImageUrl': process.env.NotImageFound,
                'Caption': ''
            }];
            if (gellery_data[book_data[i]['AccommodationID']] != undefined) {
                let tmp_gellery = _.map(gellery_data[book_data[i]['AccommodationID']], gData => _.omit(gData, ['AccommodationID'])).splice(0, 5);
                book_data[i]['ImageUrlList'] = tmp_gellery;
            }

            book_data[i]['IsFeature'] = '0';
            if (book_data[i]['IsFeatures'] != '' && book_data[i]['IsFeatures'].split(',').includes('160')) {
                book_data[i]['IsFeature'] = '1';
            }

            book_data[i]['IsOffer'] = '0';
            if (book_data[i]['IsFeatures'] != '' && book_data[i]['IsFeatures'].split(',').includes('161')) {
                book_data[i]['IsOffer'] = '1';
            }
            delete book_data[i]['IsFeatures'];

            // start generate acc slug
            let AccSlug = await Common.GenerateAccSlug(book_data[i]['AccommodationName'], book_data[i]['CountryName'], book_data[i]['StateName'], book_data[i]['CityName'], book_data[i]['UniqueID']);
            book_data[i]['AccommodationSlug'] = AccSlug;
            delete book_data[i]['CountryName'];
            delete book_data[i]['StateName'];
            delete book_data[i]['CityName'];
            delete book_data[i]['UniqueID'];
            // end generate acc slug

            book_data[i]['IsReview'] = '0';
            if (book_data[i]['RatingID'] <= 0 && !['5'].includes(book_data[i]['Status'])) {
                book_data[i]['IsReview'] = '1';
            }
            delete book_data[i]['RatingID'];
            book_data[i]['AccRating'] = parseInt(book_data[i]['AccRating']);
        }

        response.status = '1';
        response.message = 'The Data Fetching process is completed successfully.';
        response.data = {
            'CurrentPage': request.PageNo,
            'TotalPage': Math.ceil(total_record / request.Limit).toString(),
            'TotalRecord': total_record.toString(),
            'List': book_data,
        };
    }
    callback(null, json_response(response));
}

User.GetMyEnquiryList = async (request, callback) => {
    let where = ' AND si.StudentID=? ';
    let where_array = [request.UserId];

    if (request.ServiceID != undefined && request.ServiceID > 0) {
        where += ' AND si.ServiceID=? ';
        where_array.push(request.ServiceID);
    }
    if (request.StatusID != undefined && request.StatusID > 0) {
        where += ' AND si.Status=? ';
        where_array.push(request.StatusID);
    }
    if (request.FromDate != undefined && request.FromDate.trim() != '') {
        where += ' AND DATE(si.EntryDate) >= ? ';
        where_array.push(request.FromDate);
    }
    if (request.ToDate != undefined && request.ToDate.trim() != '') {
        where += ' AND DATE(si.EntryDate) <= ? ';
        where_array.push(request.ToDate);
    }

    request.PageNo = (request.PageNo > 0 ? request.PageNo : '1');
    request.Limit = ((request.Limit > 0 && request.Limit <= 50) ? request.Limit : '20');

    let total_query = 'SELECT COUNT(si.InquiryID) AS total \
        FROM Student_Inquiry AS si \
        INNER JOIN Mst_Services AS sm ON sm.ServiceID=si.ServiceID \
        WHERE si.Type="2" ' + where;
    let total_record = await sqlhelper.select(total_query, where_array, (err, res) => {
        if (err || _.size(res) <= 0) {
            console.log(err);
            return 0;
        } else {
            return res[0]['total'];
        }
    });

    let offset = (request.PageNo * request.Limit - request.Limit);
    let si_query = 'SELECT CAST(si.InquiryID AS CHAR) AS InquiryID, si.InquiryNo, sm.Name AS ServiceName, CONCAT(si.FirstName, " ", si.LastName) AS FullName, si.Email, si.PhoneNo, CAST(si.Status AS CHAR) AS Status, DATE_FORMAT(si.EntryDate, "%Y-%m-%d %H:%i:%s") AS EntryDate,TransactionID,PayStatus,si.PayAmount,si.CurrencySymbol \
        FROM Student_Inquiry AS si \
        INNER JOIN Mst_Services AS sm ON sm.ServiceID=si.ServiceID \
        WHERE si.Type="2" ' + where + ' ORDER BY si.EntryDate DESC LIMIT ' + offset + ', ' + request.Limit;
    var si_data = await sqlhelper.select(si_query, where_array, (err, res) => {
        if (err) {
            callback(err, null);
            return 0;
        } else if (_.isEmpty(res)) {
            callback(null, {
                'status': '0',
                'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
                'data': {}
            });
            return 0;
        } else {
            return json_response(res);
        }
    });

    if (si_data == 0) {
        return;
    }

    var response = {
        'status': '0',
        'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
        'data': {},
    };

    if (si_data.length > 0) {
        response.status = '1';
        response.message = 'The Data Fetching process is completed successfully.';
        response.data = {
            'CurrentPage': request.PageNo,
            'TotalPage': Math.ceil(total_record / request.Limit).toString(),
            'TotalRecord': total_record.toString(),
            'List': si_data,
        };
    }
    callback(null, json_response(response));
}

User.SubmitReview = async (request, callback) => {
    let rating_count = 0;
    if (request.BookingID > 0) {
        let booking_query = 'SELECT abr.BookingID, abr.RatingID FROM Accommodation_BookingRequest AS abr WHERE abr.Status NOT IN(5) AND abr.StudentID=? AND abr.AccommodationID=? AND abr.BookingID=?';
        let booking_data = await sqlhelper.select(booking_query, [request.UserId, request.AccommodationID, request.BookingID], (err, res) => {
            if (err) {
                callback(json_response(err), null);
                return 0;
            } else if (res.length <= 0) {
                callback(null, {
                    'status': '0',
                    'message': 'Sorry, something went wrong; please check your internet connection or try again later.'
                });
                return 0;
            } else {
                return json_response(res[0]);
            }
        });
        if (booking_data == 0) {
            return false;
        }

        if (booking_data.RatingID > 0) {
            return callback(null, {
                'status': '0',
                'message': 'Sorry, you are already review on this accommodation.'
            });
        }
        rating_count = booking_data.RatingID;
    } else {
        let rating_query = 'SELECT COUNT(ar.RatingID) AS total FROM Accommodation_Rating AS ar WHERE ar.StudentID=? AND ar.AccommodationID=?';
        rating_count = await sqlhelper.select(rating_query, [request.UserId, request.AccommodationID], (err, res) => {
            if (err) {
                callback(null, {
                    'status': '0',
                    'message': 'Sorry, something went wrong; please check your internet connection or try again later.'
                });
                return -1;
            } else {
                return res[0]['total'];
            }
        });
        if (rating_count == -1) {
            return false;
        }
    }

    var response = {
        'status': '0',
        'message': 'Sorry, you have already reviewed this accommodation. We cannot proceed with another one.',
    };

    if (rating_count <= 0) {
        let TotalRating = parseInt(request.FacilitiesRating) +
            parseInt(request.LocationRating) +
            parseInt(request.TransportationRating) +
            parseInt(request.SafetyRating) +
            parseInt(request.StaffRating) +
            parseInt(request.ValueRating);

        let AverageRating = (TotalRating / 6).toFixed(2);

        let insert_data = {
            'AccommodationID': request.AccommodationID,
            'StudentID': request.UserId,
            'FacilitiesRating': request.FacilitiesRating,
            'LocationRating': request.LocationRating,
            'TransportationRating': request.TransportationRating,
            'SafetyRating': request.SafetyRating,
            'StaffRating': request.StaffRating,
            'ValueRating': request.ValueRating,
            'AverageRating': AverageRating,
            'Review': request.Review,
            'ReviewDate': moment().format('YYYY-MM-DD HH:mm:ss'),
            'IsApprove': '0',
        }

        let RatingID = await sqlhelper.insert('Accommodation_Rating', insert_data, (err, res) => {
            if (err) {
                console.log(err);
                return 0;
            } else {
                return res.insertId;
            }
        });

        response['status'] = '0';
        response['message'] = 'Sorry, something went wrong; please check your internet connection or try again later.';

        if (RatingID > 0) {
            if (request.BookingID > 0) {
                let update_data = {
                    'RatingID': RatingID
                };
                let where_data = {
                    'BookingID': request.BookingID
                };

                await sqlhelper.update('Accommodation_BookingRequest', update_data, where_data, (err, res) => {
                    if (err) console.log(err);
                    return res.affectedRows;
                });
            }

            response['status'] = '1';
            response['message'] = 'Dear user, your review for the accommodation has been submitted successfully.';
            response['data'] = {
                'IsReview': '0'
            };
        }
    }

    return callback(null, json_response(response));
}

User.SubmitTestimonial = async (request, callback) => {
    let insert_data = {
        'Name': request.Name,
        'Gender': request.Gender,
        'Designation': request.Designation,
        'ServiceID': request.ServiceID,
        'CountryID': request.CountryID,
        'CompanyName': (request.CompanyName != undefined ? request.CompanyName : ''),
        'ImageURL': '',
        'Description': request.Description,
        'Rating': request.Rating,
        'Active': '0',
        'EntryDate': moment().format('YYYY-MM-DD HH:mm:ss'),
        'EntryIP': request.IpAddress,
    };

    if (request.Image != undefined && request.Image.trim() != '') {
        let file_array = {
            'base64_data': request.Image,
            'file_name': 'Mst_Services/' + uuidv4() + '.jpeg',
            'content_type': 'Image/jpeg',
        }
        let file_data = await Common.S3FileUpload(file_array);
        if (file_data['Location'] != undefined) {
            insert_data['ImageURL'] = file_data['Location'];
        }
    }

    await sqlhelper.insert('Mst_WebTestimonial', insert_data, (err, res) => {
        if (err) {
            callback(err, null);
        } else if (res.insertId > 0) {
            callback(null, {
                'status': '1',
                'message': 'Data Submission completed. Your data has been submitted successfully.',
                'data': {}
            });
        } else {
            callback(null, {
                'status': '0',
                'message': 'Somthing is wrong.',
                'data': {}
            });
        }
    });
}

User.GetMasterData = async (request, callback) => {
    let para_query = 'SELECT ParameterTypeID, CAST(ParameterValueID AS CHAR) AS Id, ParameterValue AS Name, Image AS ImageUrl FROM Mst_ParameterValue WHERE ParameterTypeID IN(5,6,7) AND Active="1" ORDER BY DisplayOrder ASC';
    let para_data = await sqlhelper.select(para_query, [], (err, res) => {
        if (err) {
            console.log(err);
            return [];
        } else {
            return res;
        }
    });

    var final_data = {};
    for (let i = 0; i < para_data.length; i++) {
        let tmp_data = para_data[i];
        if (tmp_data.ParameterTypeID == '5') {
            if (final_data['property_type_list'] == undefined) {
                final_data['property_type_list'] = [];
            }
            delete tmp_data.ParameterTypeID;
            final_data['property_type_list'].push(tmp_data);
        }
        if (tmp_data.ParameterTypeID == '6') {
            if (final_data['isfeature_list'] == undefined) {
                final_data['isfeature_list'] = [];
            }
            delete tmp_data.ParameterTypeID;
            final_data['isfeature_list'].push(tmp_data);
        }
        if (tmp_data.ParameterTypeID == '7') {
            if (final_data['person_prefix_list'] == undefined) {
                final_data['person_prefix_list'] = [];
            }
            delete tmp_data.ParameterTypeID;
            final_data['person_prefix_list'].push(tmp_data);
        }
    }

    let country_query = 'SELECT CAST(CountryID AS CHAR) AS Id, CountryName AS Name, CONCAT("' + image_location + 'Country-Flag/", CountryCode, "-32.png") AS ImageUrl, CountryCode, CurrencyCode, PhoneCode, CurrencySymbol, CAST(Active AS CHAR) AS Active FROM Mst_Country ORDER BY CountryID ASC';
    let country_data = await sqlhelper.select(country_query, [], (err, res) => {
        if (err) {
            console.log(err);
            return [];
        } else {
            return res;
        }
    });
    final_data['country_list'] = country_data;

    /*var AP_query = 'SELECT CAST(ProviderID AS CHAR) AS Id, Name, ImageUrl FROM Accommodation_Provider WHERE Active="1" ORDER BY ProviderID ASC';
    var AP_data = await sqlhelper.select(AP_query, [], (err, res) => {
        if (err) {
            console.log(err); return [];
        } else {
            return res;
        }
    });
    final_data['provider_list'] = AP_data;*/

    var service_query = 'SELECT CAST(ServiceID AS CHAR) AS Id, Name, PageSlug, IF(MediaImage!="", MediaImage, "' + process.env.NotImageFound + '") AS ImageUrl FROM Mst_Services WHERE Active="1" ORDER BY DisplayOrder ASC';
    var service_data = await sqlhelper.select(service_query, [], (err, res) => {
        if (err) {
            console.log(err);
            return [];
        } else {
            return res;
        }
    });
    final_data['service_list'] = service_data;

    var up_service_query = 'SELECT CAST(ServiceID AS CHAR) AS Id, Name, PageSlug, IF(MediaImage!="", MediaImage, "' + process.env.NotImageFound + '") AS ImageUrl FROM Mst_Services WHERE Active="0" ORDER BY DisplayOrder ASC';
    var up_service_data = await sqlhelper.select(up_service_query, [], (err, res) => {
        if (err) {
            console.log(err);
            return [];
        } else {
            return res;
        }
    });
    final_data['upcoming_service_list'] = up_service_data;

    var insu_type_query = 'SELECT CAST(ServiceTypeID AS CHAR) AS Id, Type AS Name, "" AS ImageUrl FROM Mst_ServicesType WHERE ServiceID="1" AND Active="1"';
    var insu_type_data = await sqlhelper.select(insu_type_query, [], (err, res) => {
        if (err) {
            console.log(err);
            return [];
        } else {
            return res;
        }
    });
    final_data['insurance_type_list'] = insu_type_data;

    callback(null, final_data);
}

// start version update section
User.CheckUpdateAppVersion = async (request, callback) => {
    let check_version_query = 'SELECT AppID, AppOS, AppVersion, IsActive, IsUpdate, IsCompulsory, IsMaintenance, UpdateMessage FROM Mst_App_Version WHERE IsActive="1"';
    let version_data = await sqlhelper.select(check_version_query, [], (err, res) => {
        if (err) {
            callback(null, json_response(err));
            return -1;
        } else {
            return json_response(res);
        }
    });

    if (version_data == -1) {
        return;
    }

    var versionInfo = {
        Android: {
            'AppVersion': request.AppVersion,
            'IsUpdate': '0',
            'IsCompulsory': '0',
            'IsMaintenance': '0',
            'Message': 'No any update.'
        },
        IOS: {
            'AppVersion': request.AppVersion,
            'IsUpdate': '0',
            'IsCompulsory': '0',
            'Istenance': '0',
            'Message': 'No any update.'
        },
    };

    if (_.size(version_data) > 0) {
        version_data.forEach((vData, vIndex) => {
            if (vData.AppOS == '2' && request.AppVersion < vData.AppVersion) {
                versionInfo.Android = {
                    'AppVersion': vData.AppVersion,
                    'IsUpdate': vData.IsUpdate.toString(),
                    'IsCompulsory': vData.IsCompulsory.toString(),
                    'IsMaintenance': vData.IsMaintenance.toString(),
                    'Message': vData.UpdateMessage,
                }
            }

            if (vData.AppOS == '3' && request.AppVersion < vData.AppVersion) {
                versionInfo.IOS = {
                    'AppVersion': vData.AppVersion,
                    'IsUpdate': vData.IsUpdate.toString(),
                    'IsCompulsory': vData.IsCompulsory.toString(),
                    'IsMaintenance': vData.IsMaintenance.toString(),
                    'Message': vData.UpdateMessage,
                }
            }
        });
        // console.log(version_data);
    }

    callback(null, versionInfo);
}
// end version update section

User.GetStateList = async (request, callback) => {
    let query = 'SELECT CAST(StateID AS CHAR) AS Id, StateName AS Name, CAST(Active AS CHAR) AS Active FROM Mst_State WHERE CountryID=? ORDER BY StateName ASC';
    await sqlhelper.select(query, [request.CountryID], (err, res) => {
        if (err) {
            callback(json_response(err), null);
        } else {
            callback(null, {
                'List': json_response(res)
            });
        }
    });
}

User.GetCityList = async (request, callback) => {
    let query = 'SELECT CAST(CityID AS CHAR) AS Id, CityName AS Name, CAST(Active AS CHAR) AS Active FROM Mst_City WHERE CountryID=? AND StateID=? ORDER BY CityName ASC';
    await sqlhelper.select(query, [request.CountryID, request.StateID], (err, res) => {
        if (err) {
            callback(json_response(err), null);
        } else {
            callback(null, {
                'List': json_response(res)
            });
        }
    });
}

User.GetCurrentLocationByIp = async (request, callback) => {
    let LocationData = await Common.GetIpToLocation(request.IpAddress);
    let country_query = 'SELECT CAST(CountryID AS CHAR) AS Id, CountryName AS Name, CONCAT("' + image_location + 'Country-Flag/", CountryCode, "-32.png") AS ImageUrl, CountryCode, CurrencyCode, PhoneCode, CurrencySymbol, CAST(Active AS CHAR) AS Active FROM Mst_Country WHERE CountryName=?';
    let country_data = await sqlhelper.select(country_query, [LocationData.CountryName], (err, res) => {
        if (err || res.length <= 0) {
            console.log(err);
            return {};
        } else {
            return json_response(res[0]);
        }
    });

    country_data['Latitude'] = LocationData['Latitude'];
    country_data['Longitude'] = LocationData['Longitude'];
    country_data['IpAddress'] = LocationData['IpAddress'];
    callback(null, country_data);
}

User.GetStaticPage = async (request, callback) => {
    let static_query = 'SELECT MetaTitle, MetaDes, MetaKeyword, PageName, QuickSlug AS PageSlug, Content AS HtmlContent, Description FROM Mst_QuickLink WHERE Active="1" AND PageName=?';
    await sqlhelper.select(static_query, [request.PageName], (err, res) => {
        if (err) {
            callback(err, null);
        } else if (res.length <= 0) {
            callback(null, {});
        } else {
            callback(null, json_response(res[0]));
        }
    });
}

User.ContactUs = async (request, callback) => {
    let PhoneNoCode = ((request.PhoneNoCode != undefined && request.PhoneNoCode.trim() != '') ? request.PhoneNoCode + ' ' : '');
    let insert_data = {
        'Source': request.Source,
        'FirstName': request.FirstName,
        'LastName': request.LastName,
        'Email': request.Email,
        'PhoneNo': PhoneNoCode + request.PhoneNo,
        'Subject': request.Subject,
        'Message': request.Message,
        'EntryDate': moment().format('YYYY-MM-DD HH:mm:ss'),
        'EntryIP': request.IpAddress,
    };

    let ContactID = await sqlhelper.insert('ContactUs', insert_data, (err, res) => {
        if (err) {
            console.log(err);
            return 0;
        } else {
            return res.insertId;
        }
    });

    var response = {
        'status': '0',
        'message': 'Sorry, something went wrong; please check your internet connection or try again later.',
    };

    if (ContactID > 0) {
        response['status'] = '1';
        response['message'] = 'Thank you for submitting your query; we will get back to it soon.';
    }

    // let EmailData = await Common.GetEmailTemplate('ContactUs');
    // if (_.size(EmailData) > 0) {
    //     let FullName = request.FirstName+' '+request.LastName;
    //     let body = EmailData['Body']
    //         .replace(/%_Name_%/g, FullName)
    //         .replace('%_Email_%', request.Email)
    //         .replace('%_PhoneNo_%', request.PhoneNo)
    //         .replace('%_Subject_%', request.Subject)
    //         .replace('%_Message_%', request.Message);

    //     let MailData = {
    //         'mail_to': request.Email, 
    //         'subject': EmailData['Subject'], 
    //         'body': body, 
    //         'cc_mail': EmailData['CCEmail'],
    //     };
    //     await Common.SendEmailSMTP(MailData);
    // }

    let EmailData = await Common.GetEmailTemplate('FrontEnd.ContactUs');
    if (_.size(EmailData) > 0) {
        let FullName = request.FirstName + ' ' + request.LastName;
        let body = EmailData['Body']
            .replace('{First Name}', FullName)
            .replace('{{STUDENT_PANEL_LINK}}', process.env.STUDENT_PANEL_LINK);

        let MailData = {
            'mail_to': request.Email,
            'subject': EmailData['Subject'],
            'body': body,
            'cc_mail': EmailData['CCEmail'],
        };
        await Common.SendEmailSMTP(MailData);
    }

    return callback(null, json_response(response));
}

User.SubscribeUs = async (request, callback) => {
    let sub_query = 'SELECT COUNT(SubscribeID) AS total FROM SubscribeUs WHERE Email=?';
    let sub_count = await sqlhelper.select(sub_query, [request.Email], (err, res) => {
        if (err) {
            console.log(err);
            return 0;
        } else {
            return res[0]['total'];
        }
    });

    var response = {
        'status': '1',
        'message': 'Hi there, you already have subscribed to our services. Thank you.',
    };

    if (sub_count <= 0) {
        let insert_data = {
            'Email': request.Email,
            'IsSubscribe': '1',
            'EntryDate': moment().format('YYYY-MM-DD HH:mm:ss'),
            'EntryIP': request.IpAddress,
        }

        let SubscribeID = await sqlhelper.insert('SubscribeUs', insert_data, (err, res) => {
            if (err) {
                console.log(err);
                return 0;
            } else {
                return res.insertId;
            }
        });

        response['status'] = '0';
        response['message'] = 'Sorry, something went wrong; please check your internet connection or try again later.';

        if (SubscribeID > 0) {
            response['status'] = '1';
            response['message'] = 'Hello, Thank you for Subscribing to Ocxee; do check our regular updates.';
        }
    }

    return callback(null, json_response(response));
}

User.SubmitArrangeCallInquiry = async (request, callback) => {
    let insert_data = {
        'StudentID': request.UserId,
        'AccommodationID': request.AccommodationID,
        'CallDate': request.CallDate,
        'CallTime': request.CallTime,
        'Message': request.Message,
        'EntryDate': moment().format('YYYY-MM-DD HH:mm:ss'),
        'EntryIP': request.IpAddress,
    }

    let ArrangeCallID = await sqlhelper.insert('ArrangeCall_Inquiry', insert_data, (err, res) => {
        if (err) {
            console.log(err);
            return 0;
        } else {
            return res.insertId;
        }
    });

    let response = {};
    response['status'] = '0';
    response['message'] = 'Sorry, something went wrong; please check your internet connection or try again later.';

    if (ArrangeCallID > 0) {
        response['status'] = '1';
        response['message'] = 'Hello, user your inquiry has been submitted. Thank you for contacting us.';
    }
    let AccommodationName = 'OXCEE'
    if (request.AccommodationID != '0') {
        let accquery = 'SELECT AltAccommodationName as AccommodationName  FROM Accommodation WHERE AccommodationID= ' + request.AccommodationID;
        AccommodationName = await sqlhelper.select(accquery, [], (err, res) => {
            if (err) {
                console.log(err);
                return 0;
            } else {
                return res[0]['AccommodationName'];
            }
        });
    }

    let stdquery = 'SELECT CONCAT(FirstName," ",LastName) as StudentName,PhoneNo,Email  FROM Student WHERE StudentID= ' + request.UserId;
    let StudentData = await sqlhelper.select(stdquery, [], (err, res) => {
        if (err) {
            console.log(err);
            return 0;
        } else {
            return res[0];
        }
    });
    // console.log(StudentData);
    // let reset_pass_link = process.env.STUDENT_PANEL_LINK+'home';
    let EmailData = await Common.GetEmailTemplate('ArrangeCall');
    if (_.size(EmailData) > 0) {
        let body = EmailData['Body']
            .replace('{{Accomadation}}', AccommodationName)
            .replace('{{StudentName}}', StudentData.StudentName)
            .replace('{{MobileNo}}', StudentData.PhoneNo)
            .replace('{{Message}}', request.Message)
            .replace('{{CallDate}}', request.CallDate)
            .replace('{{Email}}', request.Email)
            .replace('{{CallTime}}', request.CallTime);

        let MailData = {
            // 'mail_to':  'parthdevani.dnk@gmail.com', 
            'mail_to': request.Email,
            'subject': EmailData['Subject'],
            'body': body,
            // 'cc_mail': EmailData['CCEmail'],
        };
        // console.log(MailData);
        await Common.SendEmailSMTP(MailData);
    }



    return callback(null, json_response(response));
}

User.SeachActivityLogEntry = async (request, callback) => {
    let CountryName = (request.CountryName != undefined ? request.CountryName.trim() : '');
    let StateName = (request.StateName != undefined ? request.StateName.trim() : '');
    let CityName = (request.CityName != undefined ? request.CityName.trim() : '');

    let csc_where_array = [StateName, CityName, CountryName];
    let csc_query = 'SELECT cn.CountryID, IFNULL(st.StateID, 0) AS StateID, IFNULL(ct.CityID, 0) AS CityID FROM Mst_Country AS cn LEFT JOIN Mst_State AS st ON st.CountryID=cn.CountryID AND st.StateName=? LEFT JOIN Mst_City AS ct ON ct.StateID=st.StateID AND ct.CityName=? WHERE cn.CountryName=? LIMIT 1';
    if (CityName != '' && StateName == '') {
        csc_where_array = [CityName, CountryName];
        csc_query = 'SELECT cn.CountryID, IFNULL(st.StateID, 0) AS StateID, IFNULL(ct.CityID, 0) AS CityID FROM Mst_Country AS cn LEFT JOIN Mst_State AS st ON st.CountryID=cn.CountryID LEFT JOIN Mst_City AS ct ON ct.StateID=st.StateID AND ct.CityName=? WHERE cn.CountryName=? AND ct.CityID!="0" LIMIT 1';
    }

    let csc_data = await sqlhelper.select(csc_query, csc_where_array, (err, res) => {
        if (err || res.length <= 0) {
            return {
                'CountryID': '0',
                'StateID': '0',
                'CityID': '0'
            };
        } else {
            return res[0];
        }
    });

    let insert_data = {
        'Source': request.Source,
        'StudentID': request.UserId,
        'Latitude': request.Latitude,
        'Longitude': request.Longitude,
        'SearchText': (request.Search != undefined ? request.Search : ''),
        'Distance': (request.DistanceRadius != undefined ? request.DistanceRadius : '0'),
        'CountryID': csc_data.CountryID,
        'StateID': csc_data.StateID,
        'CityID': csc_data.CityID,
        'PropertyType': (request.PropertyTypeId != undefined ? request.PropertyTypeId.join(',') : ''),
        'MinBed': (request.MinBed != undefined ? request.MinBed : '0'),
        'MaxBed': (request.MaxBed != undefined ? request.MaxBed : '0'),
        'MinPrice': (request.MinPrice != undefined ? request.MinPrice : '0'),
        'MaxPrice': (request.MaxPrice != undefined ? request.MaxPrice : '0'),
        'EntryDate': moment().format('YYYY-MM-DD HH:mm:ss'),
        'EntryIP': request.IpAddress,
    };

    await sqlhelper.insert('Searching_Activity_Log', insert_data, (err, res) => {
        if (err) {
            callback(err, null);
        } else if (res.insertId > 0) {
            callback(null, {
                'status': '1',
                'message': 'Data Submission completed. Your data has been submitted successfully.',
                'data': {}
            });
        } else {
            callback(null, {
                'status': '0',
                'message': 'Somthing is wrong.',
                'data': {}
            });
        }
    });
}

generateInquiryNo = async (IsType = '0', ServiceID = '0') => {
    let PrefixKey = '';
    let last_InquiryNo = '';
    if (IsType == '0') {
        switch (ServiceID) {
            case '1':
                PrefixKey = 'INS';
                break;
            case '2':
                PrefixKey = 'APT';
                break;
            case '3':
                PrefixKey = 'FRX';
                break;
            case '4':
                PrefixKey = 'TAS';
                break;
            case '5':
                PrefixKey = 'SIM';
                break;
            case '6':
                PrefixKey = 'MNY';
                break;
            case '8':
                PrefixKey = 'ACM';
                break;
            case '9':
                PrefixKey = 'VIS';
                break;
            case '10':
                PrefixKey = 'EDU';
                break;
            case '11':
                PrefixKey = 'ESS';
                break;
            case '12':
                PrefixKey = 'JOB';
                break;
            case '13':
                PrefixKey = 'FRN';
                break;
            case '14':
                PrefixKey = 'JOB';
                break;
            case '15':
                PrefixKey = 'GUS';
                break;
            default:
                PrefixKey = 'NOT';
                break;
        }

        last_InquiryNo = await sqlhelper.select('SELECT InquiryNo FROM Student_Inquiry WHERE ServiceID=? AND InquiryNo!="" ORDER BY InquiryID DESC', [ServiceID], (err, res) => {
            if (res.length > 0 && res[0]['InquiryNo'] != '') {
                return res[0]['InquiryNo'].trim();
            }
            return "";
        });
    } else if (IsType == '1') {
        PrefixKey = 'ACC';

        last_InquiryNo = await sqlhelper.select('SELECT BookingNo FROM Accommodation_BookingRequest WHERE BookingNo!="" ORDER BY BookingID DESC', [], (err, res) => {
            if (res.length > 0 && res[0]['BookingNo'] != '') {
                return res[0]['BookingNo'].trim();
            }
            return "";
        });
    } else if (IsType == '2') {
        PrefixKey = 'TXB';

        last_InquiryNo = await sqlhelper.select('SELECT BookingID FROM Trn_TaxiBooking WHERE BookingID!="" ORDER BY ID DESC', [], (err, res) => {
            if (res.length > 0 && res[0]['BookingID'] != '') {
                return res[0]['BookingID'].trim();
            }
            return "";
        });
    }


    let new_InquiryNo = PrefixKey + moment().format('YYYYMMDD') + '00001';
    if (last_InquiryNo != '') {
        let new_date = PrefixKey + moment().format('YYYYMMDD');
        let old_date = last_InquiryNo.substr(0, 11);
        let old_sr_no = last_InquiryNo.substr(11);
        if (new_date == old_date) {
            let new_sr_no = (parseInt(old_sr_no) + 1).toString();
            if (new_sr_no.length == 1)
                new_sr_no = '0000' + new_sr_no;
            else if (new_sr_no.length == 2)
                new_sr_no = '000' + new_sr_no;
            else if (new_sr_no.length == 3)
                new_sr_no = '00' + new_sr_no;
            else if (new_sr_no.length == 4)
                new_sr_no = '0' + new_sr_no;

            new_InquiryNo = old_date + new_sr_no;
        }
    }
    return new_InquiryNo;
}

User.GetPopularPropertiesList = async (request, callback) => {
    let cn_query = `SELECT CAST(pop.PopularPropoertieID as CHAR) as PopularPropoertieID,pop.Propoertiekey,pop.Title, pop.Description, pop.Image, pop.Fetures, pop.CityID, pop.StateID, pop.CountryID, pop.MinRating, pop.MaxRating, pop.MinPrice, pop.MaxPrice, pop.MinBed, pop.MaxBed, pop.MaxProperty, pop.Active, pop.EntryDate FROM Popular_Propoerties as pop 
    WHERE pop.Active=1 AND pop.Propoertiekey in('popular-propoerties-test','student-recommendation') ORDER BY pop.DisplayOrder ASC`;
    var ConditionData = await sqlhelper.select(cn_query, [], (err, res) => {
        if (err) {
            callback(err, null);
            return -1;
        } else {
            return json_response(res);
        }
    });
    if (ConditionData == -1) {
        return;
    }

    let limit = '10';
    let PropertyData = [];
    for (let [Index, ConditionObj] of ConditionData.entries()) {
        where = '';
        where_array = [];
        where_having = '';

        if (ConditionObj.MaxProperty != undefined && ConditionObj.MaxProperty > 0) {
            limit = ConditionObj.MaxProperty;
        }

        if (ConditionObj.CountryID != undefined && ConditionObj.CountryID > 0) {
            where += ' AND acc.CountryID=? ';
            where_array.push(ConditionObj.CountryID);
        }
        if (ConditionObj.StateID != undefined && ConditionObj.StateID > 0) {
            where += ' AND acc.StateID=? ';
            where_array.push(ConditionObj.StateID);
        }
        if (ConditionObj.CityID != undefined && ConditionObj.CityID > 0) {
            where += ' AND acc.CityID=? ';
            where_array.push(ConditionObj.CityID);
        }

        if (ConditionObj.Fetures != undefined && ConditionObj.Fetures != '') {
            let IsFeature = ConditionObj.Fetures.split(',');
            let where_or = '';
            _.each(IsFeature, (val, index) => {
                where_or += (index == 0 ? ' AND (FIND_IN_SET(?, acc.IsFeatures) ' : ' OR FIND_IN_SET(?, acc.IsFeatures) ');
                where_array.push(val);
            });
            where += (where_or != '' ? where_or + ') ' : '');
        }

        if (ConditionObj.MinRating != undefined && ConditionObj.MinRating > 0) {
            where += ' AND acc.AccRating >= ? ';
            where_array.push(ConditionObj.MinRating);
        }
        if (ConditionObj.MaxRating != undefined && ConditionObj.MaxRating > 0) {
            where += ' AND acc.AccRating <= ? ';
            where_array.push(ConditionObj.MaxRating);
        }

        if (ConditionObj.MinPrice != undefined && ConditionObj.MinPrice > 0) {
            where += ' AND acc.WeeklyRate >= ? ';
            where_array.push(ConditionObj.MinPrice);
        }
        if (ConditionObj.MaxPrice != undefined && ConditionObj.MaxPrice > 0) {
            where += ' AND acc.WeeklyRate <= ? ';
            where_array.push(ConditionObj.MaxPrice);
        }

        if (ConditionObj.MinBed != undefined && ConditionObj.MinBed > 0) {
            where_having += ' AND TotalBeds >= ' + ConditionObj.MinBed + ' ';
        }
        if (ConditionObj.MaxBed != undefined && ConditionObj.MaxBed > 0) {
            where_having += ' AND TotalBeds <= ' + ConditionObj.MaxBed + ' ';
        }

        let acc_query = 'SELECT CAST(acc.AccommodationID AS CHAR) AS AccommodationID, acc.UniqueID, acc.AltAccommodationName as AccommodationName, acc.AddressLine1, acc.AddressLine2, acc.Latitude, acc.Longitude, IF(acc.AccRating!="",acc.AccRating,0) AS AccRating, acc.IsFeatures, \
        IFNULL((SELECT IF(ag.MediaUrl!="", ag.MediaUrl, ag.MediaFile) FROM Accommodation_Gallery AS ag WHERE ag.MediaType="1" AND ag.AccommodationID=acc.AccommodationID ORDER BY ag.DisplayOrder ASC LIMIT 1), "' + process.env.NotImageFound + '") AS ImageUrl, \
        IFNULL(acc_pro.Name, "Ocxee Accommodation") AS ProviderName, IFNULL(acc_pro.ImageUrl, "https://ocxeeadmin.s3.eu-west-2.amazonaws.com/ApiProviderImage/oxcee-logo.svg") AS ProviderImageUrl, \
        "" AS Distance, "pw" AS RentType, CAST(acc.NightlyRate AS CHAR) AS NightlyRate, CAST(acc.WeeklyRate AS CHAR) WeeklyRate, CAST(acc.MonthlyRate AS CHAR) AS MonthlyRate, IFNULL(cm2.CurrencySymbol, "") AS CurrencySymbol, \
        (SELECT CAST(IFNULL(sum(arc.TotalBeds), 0) AS CHAR) FROM Accommodation_RoomCategory AS arc WHERE Active="1" AND arc.AccommodationID=acc.AccommodationID) AS TotalBeds, \
        (SELECT IF(COUNT(wl.WishlistID)>0,"1","0") FROM Accommodation_Wishlist AS wl WHERE wl.AccommodationID=acc.AccommodationID AND wl.StudentID="' + request.UserId + '") AS IsWishlist, \
        IFNULL(cm.CountryName,"") AS CountryName, IFNULL(sm.StateName,"") AS StateName, IFNULL(ct.CityName,"") AS CityName \
        FROM Accommodation AS acc \
        LEFT JOIN Accommodation_Provider AS acc_pro ON acc_pro.ProviderID=acc.ProviderID \
        INNER JOIN Mst_Country AS cm ON cm.CountryID=acc.CountryID \
        INNER JOIN Mst_Country AS cm2 ON cm2.CountryID=acc.CurrencyID \
        INNER JOIN Mst_State AS sm ON sm.StateID=acc.StateID \
        LEFT JOIN Mst_City AS ct ON ct.CityID=acc.CityID \
        WHERE acc.Active="1" ' + where + ' HAVING 1 ' + where_having + ' LIMIT ' + limit;

        let acc_data = await sqlhelper.select(acc_query, where_array, (err, res) => {
            if (err) {
                return [];
            } else {
                return res;
            }
        });

        if (acc_data.length > 0) {
            let AccomIdList = _.map(acc_data, 'AccommodationID');
            let gellery_query = 'SELECT ag.AccommodationID, ' + FieldReplace + ' ag.Caption FROM Accommodation_Gallery AS ag WHERE ag.MediaType="1" AND ag.AccommodationID IN(' + AccomIdList.join(',') + ') ORDER BY ag.DisplayOrder ASC';
            var gellery_data = await sqlhelper.select(gellery_query, [], (err, res) => {
                if (err) {
                    console.log(err);
                    return {};
                } else {
                    return _.groupBy(res, 'AccommodationID');
                }
            });

            for (let i = 0; i < acc_data.length; i++) {
                if (process.env.IsShowProviderIcon == 0) {
                    acc_data[i]['ProviderImageUrl'] = ''; // Add by Dhiraj 07-04-21
                }

                if (acc_data[i]['AddressLine1'] == '' && acc_data[i]['AddressLine2'] == '') {
                    acc_data[i]['AddressLine1'] = acc_data[i]['CityName'] + ', ' + acc_data[i]['StateName'] + ', ' + acc_data[i]['CountryName'];
                }

                acc_data[i]['ImageUrlList'] = [{
                    'ImageUrl': process.env.NotImageFound,
                    'Caption': ''
                }];
                if (gellery_data[acc_data[i]['AccommodationID']] != undefined) {
                    let tmp_gellery = _.map(gellery_data[acc_data[i]['AccommodationID']], gData => _.omit(gData, ['AccommodationID'])).splice(0, 5);
                    acc_data[i]['ImageUrlList'] = tmp_gellery;
                }

                acc_data[i]['IsFeature'] = '0';
                if (acc_data[i]['IsFeatures'] != '' && acc_data[i]['IsFeatures'].split(',').includes('160')) {
                    acc_data[i]['IsFeature'] = '1';
                }
                acc_data[i]['IsOffer'] = '0';
                if (acc_data[i]['IsFeatures'] != '' && acc_data[i]['IsFeatures'].split(',').includes('161')) {
                    acc_data[i]['IsOffer'] = '1';
                }
                delete acc_data[i]['IsFeatures'];

                // start generate acc slug
                var acc_slug = [];
                if (acc_data[i]['CountryName'] != '') {
                    acc_slug.push(acc_data[i]['CountryName'].trim().toLowerCase().replace(/[^\w ]+/g, '').replace(/ +/g, '-'));
                } else {
                    acc_slug.push('country');
                }

                if (acc_data[i]['CityName'] != '') {
                    acc_slug.push(acc_data[i]['CityName'].trim().toLowerCase().replace(/[^\w ]+/g, '').replace(/ +/g, '-'));
                } else if (acc_data[i]['StateName'] != '') {
                    acc_slug.push(acc_data[i]['StateName'].trim().toLowerCase().replace(/[^\w ]+/g, '').replace(/ +/g, '-'));
                } else {
                    acc_slug.push('city');
                }

                acc_slug.push(acc_data[i]['AccommodationName'].trim().toLowerCase().replace(/[^\w ]+/g, '').replace(/ +/g, '-'));
                acc_data[i]['AccommodationSlug'] = process.env.STUDENT_PANEL_LINK + 'student-accommodation/' + acc_slug.join('/') + '/' + acc_data[i]['UniqueID'];

                delete acc_data[i]['CountryName'];
                delete acc_data[i]['StateName'];
                delete acc_data[i]['CityName'];
                // end generate acc slug
            }

            let ListObj = {};
            ListObj['Title'] = ConditionObj['Title'];
            ListObj['Propoertiekey'] = ConditionObj['Propoertiekey'];
            ListObj['Description'] = ConditionObj['Description'];
            ListObj['ImageUrl'] = ConditionObj['Image'];
            ListObj['List'] = acc_data;
            PropertyData[Index] = ListObj;
        }
    };
    callback(null, PropertyData);
}

User.GetPopularCityList = async (request, callback) => {
    // let query = 'SELECT pco.Name AS Title, pco.Description, pco.Image AS ImageUrl, mc.CountryName, mst.StateName, mct.CityName, pco.AccomodationLink, pco.LatLng, "" AS Latitude, "" AS Longitude \
    // FROM Mst_PopulerCities as pco INNER JOIN Mst_Country as mc on mc.CountryID=pco.CountryID LEFT JOIN Mst_State as mst on mst.StateID=pco.StateID LEFT JOIN Mst_City as mct on mct.CityID=pco.CityID \
    // WHERE pco.Active="1" ORDER BY pco.DisplayOrderno ASC';

    let query = 'SELECT pco.Name AS Title, pco.Description, pco.Image AS ImageUrl, mc.CountryName, pco.AccomodationLink, pco.LatLng, "" AS Latitude, "" AS Longitude \
    FROM Mst_PopulerCities as pco INNER JOIN Mst_Country as mc on mc.CountryID=pco.CountryID \
    WHERE pco.Active="1" ORDER BY pco.DisplayOrderno ASC';

    let pc_data = await sqlhelper.select(query, [], (err, res) => {
        if (err) {
            console.log(err);
            return [];
        } else {
            return json_response(res);
        }
    });

    for (let i = 0; i < pc_data.length; i++) {
        if (pc_data[i]['LatLng'] != '') {
            let LatLng = pc_data[i]['LatLng'].split(',');
            if (LatLng[0] != undefined) {
                pc_data[i]['Latitude'] = LatLng[0];
            }
            if (LatLng[1] != undefined) {
                pc_data[i]['Longitude'] = LatLng[1];
            }
        }
        delete pc_data[i]['LatLng'];
    }

    callback(null, pc_data);
}

User.GetDataList = async (request, query, where_array = [], callback) => {
    await sqlhelper.select(query, where_array, (err, res) => {
        if (err) {
            console.log(err);
            callback(err, null);
        } else {
            callback(null, res);
        }
    });
}

User.EmailSubscribe = async (request, callback) => {
    let query = "select EmailAddress from Email_Subscriptions where EmailAddress = '" + request.Email + "'";
    let CheckEmail = await sqlhelper.select(query, [], (err, res) => {
        if (err) {
            return -1;
        } else if (res.length <= 0) {
            return 1;
        } else {
            return -1;
        }
    });
    if (CheckEmail == -1) {
        var UpdateData = {
            SubStatus: '1',
            UpdateDate: moment().format('YYYY-MM-DD HH:mm:ss')
        }
        let where = {
            'EmailAddress': request.Email.trim()
        };
        await sqlhelper.update('Email_Subscriptions', UpdateData, where, (err, res) => {
            if (err) {
                callback(err, null);
            } else {
                callback(null, {
                    status: "1",
                    Message: 'Hello, Thank you for Subscribing to Ocxee; do check our regular updates.'
                });
            }
        });
    } else {
        var InsertData = {
            EmailAddress: request.Email.trim(),
            EntryDate: moment().format('YYYY-MM-DD HH:mm:ss')
        }
        await sqlhelper.insert('Email_Subscriptions', InsertData, (err, res) => {
            if (err) {
                callback(err, null);
            } else {
                callback(null, {
                    status: "1",
                    Message: 'Hello, Thank you for Subscribing to Ocxee; do check our regular updates.'
                });
            }
        });
    }
}

User.EmailUnSubscribe = async (request, callback) => {
    var UpdateData = {
        SubStatus: 0,
        UpdateDate: moment().format('YYYY-MM-DD HH:mm:ss')
    }
    where = {
        'EmailAddress': request.Email.trim()
    };
    await sqlhelper.update('Email_Subscriptions', UpdateData, where, (err, res) => {
        if (err) {
            callback(err, null);
        } else {
            callback(null, {
                status: "1",
                Message: 'Unsubscribing to Ocxee;'
            });
        }
    });
}

User.AddJoiningForm = async (request, callback) => {
    // let query = "select Email from JoiningForm where Email = '"+request.Email+"'";
    // let CheckEmail = await sqlhelper.select(query, [], (err, res) => {
    //     if (err) {
    //         return -1;
    //     }else if (res.length<=0) {
    //         return 1;
    //     } else {
    //         return -1;
    //     }
    // });
    // if(CheckEmail == -1){
    //     callback(null, {status : "0", Message : "Hi there, Email no allredy exit."});
    // }

    // query = "select Phone from JoiningForm where Phone = '"+request.Phone+"'";
    // let Phone = await sqlhelper.select(query, [], (err, res) => {
    //     if (err) {
    //         return -1;
    //     }else if (res.length<=0) {
    //         return 1;
    //     } else {
    //         return -1;
    //     }
    // });
    // if(Phone == -1){
    //     callback(null, {status : "0", Message : "Hi there, Mobile no allredy exit."});
    // }
    var InsertData = {
        Firstname: request.FirstName,
        Lastname: request.LastName,
        Email: request.Email,
        Phone: request.Phone,
        Message: request.Message,
        EntryDate: moment().format('YYYY-MM-DD HH:mm:ss'),
        EntryIP: request.IpAddress
    }

    if (request.CV != undefined && request.CV.trim() != '') {
        // var ext = path.extname(request.CV);
        var ext = 'docx';
        let file_array = {
            'base64_data': request.CV,
            'file_name': 'Mst_Services/' + uuidv4() + '.' + ext,
            'content_type': '',
        }
        let file_data = await Common.S3FileUpload(file_array);
        if (file_data['Location'] != undefined) {
            console.log(file_data['Location']);
            InsertData['CV'] = file_data['Location'];
        }
    }
    await sqlhelper.insert('JoiningForm', InsertData, (err, res) => {
        if (err) {
            callback(err, null);
        } else {
            callback(null, {
                status: "1",
                Message: 'Hello, Thank you for Apllying to Ocxee; do check our regular updates.'
            });
        }
    });
}

User.UpdatePayment = async (request, callback) => {

    let update_data = {
        'PayStatus': request.PayStatus,
        'TransactionID': request.TransactionID,
        'UpdateDate': moment().format('YYYY-MM-DD HH:mm:ss'),
        'UpdateIP': request.IpAddress,
    }

    var where = '';
    var tableName = '';

    if (request.ServiceType == 'precise') {
        if (request.PayStatus == '1') {
            update_data['Status'] = 2;
        }
        where = {
            'BookingID': request.InquiryID
        };
        tableName = 'Accommodation_BookingRequest';

    } else {
        if (request.PayStatus == '1') {
            update_data['Status'] = 3;
        }
        where = {
            'InquiryID': request.InquiryID
        };
        tableName = 'Student_Inquiry';
    }



    await sqlhelper.update(tableName, update_data, where, (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (res.affectedRows == 0) {
            callback(null, json_response({
                'status': '0',
                'message': 'Sorry, something went wrong; please check your internet connection or try again later.'
            }));
            return 0;
        } else {
            callback(null, json_response({
                'status': '1',
                'message': 'Payment Status updated successfully.'
            }));
        }
    });
}

User.UpdatePayment1 = async (request, callback) => {
    let user_query = '(SELECT BookingID as ID, "BookingID" as dbID FROM Accommodation_BookingRequest WHERE BookingNo=?) UNION (SELECT InquiryID as ID,"InquiryID" as dbID FROM Student_Inquiry WHERE InquiryNo=?)';
    let user_data = await sqlhelper.select(user_query, [request.RefID, request.RefID], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (_.isEmpty(res)) {
            callback(null, json_response({
                'status': '0',
                'message': 'The account does not exist, please check your username.'
            }));
            return 0;
        } else {
            return json_response(res[0]);
        }
    });

    if (user_data == 0) {
        return;
    }

    let update_data = {
        'PayStatus': request.PayStatus,
        'PayAmount': request.PayAmount,
        'TransactionID': request.TransactionID,
        'UpdateDate': moment().format('YYYY-MM-DD HH:mm:ss'),
        'UpdateIP': request.IpAddress,
    }

    var where = '';
    var tableName = '';

    if (user_data['dbID'] == 'BookingID') {
        if (request.PayStatus == '1') {
            update_data['Status'] = 2;
        }
        where = {
            'BookingID': user_data['ID']
        };
        tableName = 'Accommodation_BookingRequest';
    } else if (user_data['dbID'] == 'InquiryID') {
        if (request.PayStatus == '1') {
            update_data['Status'] = 3;
        }
        where = {
            'InquiryID': user_data['ID']
        };
        tableName = 'Student_Inquiry';
    } else {
        return;
    }


    await sqlhelper.update(tableName, update_data, where, (err, res) => {
        if (err) {

            callback(json_response(err), null);
            return 0;
        } else if (res.affectedRows == 0) {
            callback(null, json_response({
                'status': '0',
                'message': 'Sorry, something went wrong; please check your internet connection or try again later.'
            }));
            return 0;
        } else {
            callback(null, json_response({
                'status': '1',
                'message': 'Payment Status updated successfully.'
            }));
        }
    });
}

User.GetPaymentDetails = async (request, callback) => {


    // this is old code so please check query  before use..
    let query = "(    SELECT \
                        CAST(Abr.BookingNo as CHAR) as cartId, \
                        CAST(Abr.BookingID as CHAR) as BookingID, \
                        '8' as ServiceID, \
                        'precise' as SerType, \
                        CONCAT(acc.AltAccommodationName as AccommodationName,' (',acr.RoomCategory,')') as PlanName, \
                        (SELECT CONCAT(CurrencySymbol,'(',CurrencyCode,')') FROM Mst_Country mc WHERE mc.CountryID=acr.CurrencyID) as currency, \
                        RentAmount, \
                        DepositAmount, \
                        stu.FirstName as CustomerFName, \
                        stu.LastName as CustomerLName, \
                        stu.PhoneNo_CountryCode as CustPCode, \
                        stu.PhoneNo as CustPhone, \
                        stu.ZipCode as CustZipCode, \
                        stu.Email as CustEmail, \
                        (SELECT CityName FROM Mst_City mci WHERE mci.CityID=stu.CityID) as CustAdd1, \
                        (SELECT StateName FROM Mst_State ms WHERE ms.StateID=stu.StateID) as CustAdd2, \
                        (SELECT CountryName FROM Mst_Country mc WHERE mc.CountryID=stu.CountryID) as CustAdd3, \
                        (SELECT CountryCode FROM Mst_Country mc WHERE mc.CountryID=stu.CountryID) as CustCountryCode \
                    from \
                        Accommodation_BookingRequest as Abr \
                    left Join Accommodation acc \
                        on acc.AccommodationID = Abr.AccommodationID \
                    left join Accommodation_RoomCategory acr \
                        on acr.AccRoomCategoryID = Abr.AccRoomCategoryID \
                    left join Student stu \
                        on stu.StudentID = Abr.StudentID \
                    WHERE \
                        Abr.BookingNo =? \
                ) UNION \
                ( \
                    SELECT \
                        SInquiry.InquiryNo as cartId, \
                        CAST(SInquiry.InquiryID as CHAR) as BookingID, \
                        SInquiry.ServiceID as ServiceID, \
                        'genral' as SerType, \
                        msp.Name as PlanName, \
                        CONCAT(SInquiry.CurrencySymbol,'(',SInquiry.CurrencyCode,')') as currency, \
                        '' as RentAmount, \
                        '' as DepositAmount, \
                        SInquiry.FirstName as CustomerFName, \
                        SInquiry.LastName as CustomerLName, \
                        SInquiry.PhoneNo_CountryCode as CustPCode, \
                        SInquiry.PhoneNo as CustPhone, \
                        '' as CustZipCode, \
                        SInquiry.Email as CustEmail, \
                        SInquiry.CurrentCity as CustAdd1, \
                        SInquiry.CurrentState as CustAdd2, \
                        SInquiry.CurrentCountry as CustAdd3, \
                        (SELECT CountryCode FROM Mst_Country mc WHERE mc.CountryName=SInquiry.CurrentCountry) as CustCountryCode \
                    from \
                        Student_Inquiry as SInquiry \
                    left join Mst_ServicesProvider msp \
                        on msp.ServiceProviderID = SInquiry.ServiceProviderID \
                    WHERE \
                        SInquiry.InquiryNo =? \
                )";

    await sqlhelper.select(query, [request.RefID, request.RefID], (err, res) => {
        if (err) {
            callback(err, null);
        } else if (_.size(res) <= 0) {
            var response = {
                'data': [],
                'message': 'Ref number is not found',
                'status': '0',
                'token': request.Token,
            };
            callback(null, json_response(response));
        } else {
            var response = {
                'data': res[0],
                'message': '',
                'status': '1',
                'token': request.Token,
            };

            callback(null, json_response(response));
        }
    });
}

User.SearchPaymentDetails = async (request, callback) => {

    let query = `( 
                    SELECT
                    CAST(Abr.BookingID as CHAR) as BookingID, Abr.PayStatus, 
                    IF(Abr.AccRoomCategoryID = 0, 
                    ( SELECT CurrencyCode FROM Mst_Country mc WHERE mc.CountryID = acc.CurrencyID ), 
                    ( SELECT CurrencyCode FROM Mst_Country mc WHERE mc.CountryID = acr.CurrencyID )) as CurrencyCode ,
                    Abr.TotalAmount as TotalAmount
                    from Accommodation_BookingRequest as Abr 
                    INNER Join Accommodation acc on acc.AccommodationID = Abr.AccommodationID 
                    left join Accommodation_RoomCategory acr on acr.AccRoomCategoryID = Abr.AccRoomCategoryID 
                    WHERE
                    Abr.BookingNo = ? 
                    and Abr.StudentID = `+ request.UserId + ` 
                ) 
                UNION
                ( 
                    SELECT
                    CAST(SInquiry.InquiryID as CHAR) as BookingID, SInquiry.PayStatus, SInquiry.CurrencyCode as CurrencyCode,0.00 as TotalAmount 
                    from Student_Inquiry as SInquiry 
                    WHERE
                    SInquiry.InquiryNo = ? 
                    and SInquiry.ServiceID = `+ request.ServiceID + ` 
                    and SInquiry.StudentID = `+ request.UserId + `
                )`;

    await sqlhelper.select(query, [request.RefID, request.RefID], (err, res) => {
        if (err) {
            console.log(err);
            callback(err, null);
        } else if (_.size(res) <= 0) {
            var response = {
                'data': [],
                'message': 'Please chcek your Details,Reference number is not matched.',
                'status': '0',
                'token': request.Token,
            };
            callback(null, json_response(response));
        } else {
            var response = {
                'data': res[0],
                'message': '',
                'status': '1',
                'token': request.Token,
            };
            callback(null, json_response(response));
        }
    });
}

User.UserVerification = async (request, callback) => {
    let user_data = 0;
    if (request.ChannelPartnerID > 0 && typeof request.ChannelPartnerID !== 'undefined') {
        let user_query = 'SELECT CAST(ChannelPartnerID AS CHAR) AS UserId,Active,concat(FirstName," ",LastName) as Name, PersonalEmail as Email FROM ChannelPartner WHERE ChannelPartnerID=? LIMIT 1';
        user_data = await sqlhelper.select(user_query, [request.ChannelPartnerID], (err, res) => {
            if (err) {
                callback(json_response(err), null);
                return 0;
            } else if (_.isEmpty(res)) {
                callback(null, json_response({
                    'status': '0',
                    'message': 'Dear, user your account is not found. Check your details and try again.'
                }));
                return 0;
            } else {
                return json_response(res[0]);
            }
        });
    }
    if (request.UserId > 0) {

        let user_query = `SELECT CAST(StudentID AS CHAR) AS UserId,Active,CAST(ChannelPartnerID AS CHAR) AS ChannelPartnerID,
    CAST(IsVarifiedCommsssion AS CHAR) AS IsVarifiedCommsssion,OrderID,concat(FirstName," ",LastName) as Name, Email FROM Student WHERE StudentID=? LIMIT 1`;
        user_data = await sqlhelper.select(user_query, [request.UserId], (err, res) => {
            if (err) {
                callback(json_response(err), null);
                return 0;
            } else if (_.isEmpty(res)) {
                callback(null, json_response({
                    'status': '0',
                    'message': 'Dear, user your account is not found. Check your details and try again.'
                }));
                return 0;
            } else {
                return json_response(res[0]);
            }
        });
    }
    if (user_data == 0) {
        return;
    }
    let update_data = {};
    let where = {};
    let tableName = '';
    let UserName = ""
    if (request.ChannelPartnerID > 0 && typeof request.ChannelPartnerID !== 'undefined') {
        console.log("Hello")
        update_data = {
            'Active': '1',
            'UpdateDate': moment().format('YYYY-MM-DD HH:mm:ss'),
            'UpdateIP': request.IpAddress,
        }

        where = {
            'ChannelPartnerID': request.ChannelPartnerID
        }
        tableName = 'ChannelPartner';
        StudentVarfied = await sqlhelper.update(tableName, update_data, where, async (err, res) => {
            if (err) {
                callback(json_response(err), null);
                return 0;
            } else if (res.affectedRows == 0) {
                callback(null, json_response({
                    'status': '0',
                    'message': 'Sorry, something went wrong; please check your internet connection or try again later.'
                }));
                return -1;
            } else {
                // console.log(user_data)
                if (user_data["Active"] == 0) {
                    let reset_pass_link = process.env.STUDENT_PANEL_LINK + 'home';
                    let EmailData = await Common.GetEmailTemplate('Channel_Partner_verification');
                    if (_.size(EmailData) > 0) {
                        let body = EmailData['Body']
                            .replace('{First Name}', user_data['Name'])
                            .replace('{link}', reset_pass_link);

                        let MailData = {
                            'mail_to': user_data['Email'],
                            'subject': EmailData['Subject'],
                            'body': body,
                            // 'cc_mail': EmailData['CCEmail'],
                        };
                        await Common.SendEmailSMTP(MailData);
                    }
                    return 1;
                }
            }
        });
    } else {

        let update_data = {
            'Active': '1',
            'IsApprove': '1',
            'UpdateDate': moment().format('YYYY-MM-DD HH:mm:ss'),
            'UpdateIP': request.IpAddress,
        }

        let where = {
            'StudentID': request.UserId
        }

        let StudentVarfied = await sqlhelper.update('Student', update_data, where, async (err, res) => {
            if (err) {
                callback(json_response(err), null);
                return 0;
            } else if (res.affectedRows == 0) {
                callback(null, json_response({
                    'status': '0',
                    'message': 'Sorry, something went wrong; please check your internet connection or try again later.'
                }));
                return -1;
            } else {
                // console.log(user_data)
                if (user_data['UserId'] && user_data['UserId'] != '0') {
                    try {
                        let message_notti = Common.GetNotificationMessage('StudentVarified').replace('{{StudentName}}', user_data['Name']);
                        var ActivityArray = {
                            StudentID: request.UserId,
                            ChannelPartnerID: user_data['UserId'],
                            Message: message_notti,
                            Process: 'StudentVarified',
                            ProcessType: '5',
                            ProcessID: request.UserId,
                            ProcessSlug: 'studentdetails',
                        }
                        await Common.SaveNotificationLog(ActivityArray, request);
                    } catch (error) {
                        console.log("Notification not inert -----");
                    }
                }
                if (user_data["Active"] != 1) {
                    let reset_pass_link = process.env.STUDENT_PANEL_LINK + 'home';
                    console.log("hello")
                    let EmailData = await Common.GetEmailTemplate('FrontEnd.StartExploring');
                    if (_.size(EmailData) > 0) {
                        let body = EmailData['Body']
                            .replace('{First Name}', user_data['Name'])
                            .replace('{link}', reset_pass_link);

                        let MailData = {
                            'mail_to': user_data['Email'],
                            'subject': EmailData['Subject'],
                            'body': body,
                            // 'cc_mail': EmailData['CCEmail'],
                        };
                        await Common.SendEmailSMTP(MailData);
                    }
                }
                return 1;
            }
        });

        if (StudentVarfied > -1 && user_data.ChannelPartnerID != '0' && user_data.IsVarifiedCommsssion == '0') {
            // let OrderEntry = {
            //     'UserID': user_data.ChannelPartnerID,
            //     'UserType': 'Channel Partner',
            //     'ReferID': user_data.UserId,
            //     'OrderAmount': Amount,
            //     'Subtotal': Amount,
            //     'OrderTypeID': '1',
            //     'Status': '2',
            //     'OrderDate': moment().format('YYYY-MM-DD'),
            //     'OrderNote': "Student Varification Commission",
            // }
            // let OrderID = await sqlhelper.insert('User_Order', OrderEntry, (err, res) => {
            //     if (err) {
            //         console.log(err);
            //     } else {
            //         console.log("Order Entry Successfully " + res.insertId);
            //         return res.insertId;
            //     }
            // });
            let StudentCount = await Common.ReferralStudentCalculation(user_data.ChannelPartnerID);
            let CommissionData = await Common.GetCommissionCategory(StudentCount);
            let Amount = CommissionData.Commission_Per_Student;

            let OrderID = user_data.OrderID;
            let LedgerID = await Common.GetLedgerID(user_data.ChannelPartnerID);
            if (LedgerID && OrderID) {
                let CommRequest = {
                    'LedgerID': LedgerID,
                    'Amount': Amount,
                    'OrderID': OrderID,
                    'narretion': user_data.UserId + ' Student Varification Commission'
                }
                let Data = await Common.Ac_Wallet_Transaction_Entry(CommRequest);
                console.log("Result For Common Commision fun ---> " + Data);
                if (StudentCount == CommissionData.Min_Student) {
                    let incentive = CommissionData.Cash_Incentive;
                    let OrderEntry = {
                        'UserID': user_data.ChannelPartnerID,
                        'UserType': 'Channel Partner',
                        'ReferID': user_data.UserId,
                        'OrderAmount': incentive,
                        'Subtotal': incentive,
                        'OrderTypeID': '6',
                        'Status': '2',
                        'OrderDate': moment().format('YYYY-MM-DD'),
                        'OrderNote': "Cash Incentive",
                    }
                    let IncentiveOrderID = await sqlhelper.insert('User_Order', OrderEntry, (err, res) => {
                        if (err) {
                            console.log(err);
                        } else {
                            console.log("Order Entry Successfully " + res.insertId);
                            return res.insertId;
                        }
                    });
                    let CommRequest = {
                        'LedgerID': LedgerID,
                        'Amount': incentive,
                        'OrderID': IncentiveOrderID,
                        'narretion': ' Cash Incentive for ' + StudentCount + ' students'
                    }
                    let Data2 = await Common.Ac_Wallet_Transaction_Entry(CommRequest);
                }
                if (Data == 1) {
                    await sqlhelper.update('Student', { 'IsVarifiedCommsssion': '1' }, { 'StudentID': user_data.UserId }, (err, res) => {
                        if (err) console.log(err);
                        else console.log("Stundent Update For Commission");
                    });
                    let FinalBalance = await Common.BalanceCalculation(LedgerID);
                    console.log("FinalBalance Final  Balance -->" + FinalBalance);
                    await sqlhelper.update('ChannelPartner', { 'Balance': FinalBalance, 'CP_Category_Id': CommissionData.CP_Category_Id, 'Student_Referral_Count': StudentCount }, { 'LedgerID': LedgerID }, (err, res) => {
                        if (err) console.log(err);
                        else console.log("ChannelPartner Update For Balance");
                    });
                    await sqlhelper.update('User_Order', { 'Status': '2' }, { 'OrderID': OrderID }, (err, res) => {
                        if (err) console.log(err);
                        else console.log("Stundent Update For Commission");
                    });
                } else {
                    await sqlhelper.select(`delete from User_Order where OrderID=?`, [OrderID], (err, res) => {
                        if (err) console.log(err);
                    });
                }
            }
        }
    }

    var status = "1";
    if (request.ChannelPartnerID > 0 && typeof request.ChannelPartnerID !== 'undefined') {
        status = "2";
    }
    var response = {
        'data': [],
        'message': 'Dear ' + user_data.Name + ', your verification process has been succeeded.',
        'status': status,
        'token': request.Token,
    };
    callback(null, json_response(response));
}
User.CPVerification = async (request, callback) => {
    let user_data = 0;
    if (request.ChannelPartnerID > 0 && typeof request.ChannelPartnerID !== 'undefined') {
        let user_query = 'SELECT CAST(ChannelPartnerID AS CHAR) AS UserId,concat(FirstName," ",LastName) as Name, PersonalEmail as Email FROM ChannelPartner WHERE ChannelPartnerID=? LIMIT 1';
        user_data = await sqlhelper.select(user_query, [request.ChannelPartnerID], (err, res) => {
            if (err) {
                callback(json_response(err), null);
                return 0;
            } else if (_.isEmpty(res)) {
                callback(null, json_response({
                    'status': '0',
                    'message': 'Dear, user your account is not found. Check your details and try again.'
                }));
                return 0;
            } else {
                return json_response(res[0]);
            }
        });
    }

    if (user_data == 0) {
        return;
    }
    let update_data = {};
    let where = {};
    let tableName = '';
    update_data = {
        'Active': '1',
        'UpdateDate': moment().format('YYYY-MM-DD HH:mm:ss'),
        'UpdateIP': request.IpAddress,
    }

    where = {
        'ChannelPartnerID': request.ChannelPartnerID
    }
    tableName = 'ChannelPartner';
    StudentVarfied = await sqlhelper.update(tableName, update_data, where, async (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (res.affectedRows == 0) {
            callback(null, json_response({
                'status': '0',
                'message': 'Sorry, something went wrong; please check your internet connection or try again later.'
            }));
            return -1;
        } else {
            let reset_pass_link = process.env.STUDENT_PANEL_LINK + 'home';
            let EmailData = await Common.GetEmailTemplate('Channel_Partner_verification');
            if (_.size(EmailData) > 0) {
                let body = EmailData['Body']
                    .replace('{First Name}', user_data['Name'])
                    .replace('{link}', reset_pass_link);

                let MailData = {
                    'mail_to': user_data['Email'],
                    'subject': EmailData['Subject'],
                    'body': body,
                    // 'cc_mail': EmailData['CCEmail'],
                };
                await Common.SendEmailSMTP(MailData);
            }
            return 1;
        }
    });

    var response = {
        'data': [],
        'message': 'Dear User, your verification process has been succeeded ',
        'status': '1',
        'token': request.Token,
    };
    callback(null, json_response(response));
}

User.SendUserOffer = async (request, callback) => {
    let TodateDate = moment().format('YYYY-MM-DD HH:mm:ss');
    let insertOffer = 0;
    let expireDate = moment().add(15, 'days').format('YYYY-MM-DD HH:mm:ss');
    let offer_query = 'SELECT ot.OfferTrackID, IF(ot.UpdateDate!="0000-00-00 00:00:00",DATE_ADD(ot.UpdateDate,INTERVAL 30 DAY),DATE_ADD(ot.EntryDate,INTERVAL 30 DAY)) as TrackDate, concat(std.FirstName," ",std.LastName) as FullName, std.Email FROM `Offer_Tracking` as ot left join Student as std on std.StudentID = ot.StudentID WHERE ot.StudentID=?';
    let offer_data = await sqlhelper.select(offer_query, [request.UserId], async (err, res) => {
        if (err) {
            callback(json_response(err), null);
            console.log(err);
            return 0;
        } else if (_.isEmpty(res)) {
            let user_data = await Common.GetStudentDeatils(Number(request.UserId));
            user_data['TrackDate'] = TodateDate;
            user_data['OfferTrackID'] = 0;
            return user_data;
        } else {
            //console.log(res[0]);
            return json_response(res[0]);
        }
    });

    if (offer_data != 0) {
        let datecom1 = moment(offer_data['TrackDate']).format('YYYYMMDDHHmmss');
        let datecom2 = moment(TodateDate).format('YYYYMMDDHHmmss');
        if (datecom1 <= datecom2) {
            if (offer_data['OfferTrackID'] != 0) {
                let offer_data = {
                    'UpdateDate': TodateDate,
                    'UpdateIP': request.IpAddress,
                    'ServiceID': request.ServiceID,
                    'ExpireDate': moment(expireDate).format('YYYY-MM-DD'),
                }

                let where = {
                    'StudentID': request.UserId
                }

                insertOffer = await sqlhelper.update('Offer_Tracking', offer_data, where, (err, res) => {
                    if (err) {
                        return 0;
                    } else if (res.affectedRows == 0) {
                        return 0;
                    } else {
                        return res['affectedRows'];
                    }
                });
            } else {
                var insert_data = {
                    'EntryDate': TodateDate,
                    'EntryIP': request.IpAddress,
                    'StudentID': request.UserId,
                    'ServiceID': request.ServiceID,
                    'ExpireDate': moment(expireDate).format('YYYY-MM-DD'),
                };

                insertOffer = await sqlhelper.insert('Offer_Tracking', insert_data, (err, res) => {
                    if (err) {
                        return 0;
                    } else {
                        return res.insertId;
                    }
                });
            }

        } else {
            insertOffer = 0;
        }
    }

    if (insertOffer != 0) {
        let EmailData = await Common.GetEmailTemplate('FrontEnd.ServiceOffer');
        if (_.size(EmailData) > 0) {
            let body = EmailData['Body']
                .replace('{First Name}', offer_data['FullName'])
                .replace('{Service_name}', request.ServicName)
                .replace('{expiredate}', moment(expireDate).format('DD/MM/YYYY'))
                .replace('{link}', process.env.STUDENT_PANEL_LINK + 'assets/images/mail/offer-code.jpg')
                .replace('{{STUDENT_PANEL_LINK}}', process.env.STUDENT_PANEL_LINK);

            let MailData = {
                'mail_to': offer_data['Email'],
                'subject': EmailData['Subject'],
                'body': body,
                'cc_mail': EmailData['CCEmail'],
            };
            await Common.SendEmailSMTP(MailData);
        }
    }

    var response = {
        'message': '',
        'status': '1',
    };

    callback(null, json_response(response));
    return;
}

User.UpdateData = async (UpdateData, where, request, callback) => {
    await sqlhelper.update(request.TableName, UpdateData, where, (err, res) => {
        if (err) {
            console.log(err);
            callback(json_response(err), null);
            return 0;
        } else {
            callback(null, json_response({
                'status': '1',
                'message': 'Thank you your feedback successfully send.',
                'isUpadate': res.changedRows
            }));
        }
    });
}

User.BitrixApiRequest = async (request, callback) => {
    let inquiry_query = 'SELECT *, CAST(ServiceID AS CHAR) AS ServiceID, CAST(ServiceTypeID AS CHAR) AS ServiceTypeID FROM Student_Inquiry WHERE Type="2" AND InquiryID>=? AND InquiryID<=?';
    let inquiry_data = await sqlhelper.select(inquiry_query, [request.FromInquiryID, request.ToInquiryID], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return -1;
        } else if (res.length <= 0) {
            callback(null, {
                'status': '0',
                'message': 'Data not found.'
            });
            return -1;
        } else {
            return json_response(res);
        }
    });

    if (inquiry_data == -1) {
        return false;
    }

    let response = {
        'status': '0',
        'message': 'Data not found.'
    };
    if (inquiry_data.length > 0) {
        response = {
            'status': '1',
            'message': 'Data send on bitrix successfully.',
            'data': {
                'bitrix': []
            }
        };

        for (let i = 0; i < inquiry_data.length; i++) {
            let tmp_data = inquiry_data[i];
            // console.log(tmp_data.InquiryID + ' => ' + tmp_data.InquiryType);
            let bitrix_res = await Common.BtrixCRMRequest(tmp_data, tmp_data.ServiceID);
            response.data['bitrix'].push(bitrix_res);
        }
    }
    callback(null, response);
}

User.ServiveLogEntry = async (request, callback) => {
    let EntryData = {
        ServiceID: request.ServiceID,
        StudentID: request.UserId,
        Source: request.Source,
        EntryDate: moment().format('YYYY-MM-DD HH:mm:ss'),
        EntryIP: request.IpAddress
    }
    let user_data = await sqlhelper.insert('HST_Service_log', EntryData, (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else {
            res = json_response(res);
            return res.insertId
        }
    });
    callback(null, user_data);
}

User.GetBlogList = async (request, callback) => {
    let where = '';
    let where_array = [];
    let having = '';

    if (request.TagID != undefined && request.TagID != '') {
        where += ' AND FIND_IN_SET(' + request.TagID + ', BlogTag)';
        where_array.push(request.TagID);
    }

    if (request.BlogCategory != undefined && request.BlogCategory != '') {
        where += ' AND mb.BlogCategory=?';
        where_array.push(request.BlogCategory);
    }

    if (request.Search != undefined && request.Search != '') {
        having += ' AND Category like "%' + request.Search + '%"';
        having += ' OR BlogTitle like "%' + request.Search + '%"';
    }

    let total_query = `select count(count.BlogID) as total from (SELECT mb.BlogID,mb.BlogTitle, mb.PageSlug,IFNULL(mb.PageDescription,'') as PageDescription, mb.MediaImage, mb.ThumbnailImage as ThumbImage,mb.MiniImage,DATE_FORMAT(mb.EntryDate, '%Y-%m-%d %H:%i:%s') as EntryDate,mb.BlogLikes,mb.BlogComments,
                            (select IF(LikeID,1,0) from Trn_Blog_Likes as tbl where tbl.BlogID=mb.BlogID AND tbl.StudentID = '` + request.UserId + `' limit 1) as IsLike,
                            TIMESTAMPDIFF(SECOND,mb.EntryDate,NOW()) as SecondDiff,
                            IF(mb.BlogCategory != '',(SELECT CONCAT(ParameterValue,'[',ParameterValueID,']') FROM Mst_ParameterValue where ParameterValueID = mb.BlogCategory and ParameterTypeID='40'),"-") as Category,
                            IF(mb.BlogTag != '',(SELECT GROUP_CONCAT(ParameterValue,'[',ParameterValueID,']') FROM Mst_ParameterValue where FIND_IN_SET(ParameterValueID, mb.BlogTag) and ParameterTypeID='41' ),"-") as Tags
                        FROM
                            Mst_Blogs as mb
                        WHERE 
                            /* mb.StartDate <= CURDATE() 
                            AND mb.EndDate >= CURDATE() 
                            AND */ 
                        mb.Active = 1 ` + where + `
                        HAVING 1 ` + having + `) as count`;
    let total_record = await sqlhelper.select(total_query, where_array, (err, res) => {
        if (err || _.size(res) <= 0) {
            console.log(err);
            return 0;
        } else {
            return res[0]['total'];
        }
    });

    request.PageNo = (request.PageNo > 0 ? request.PageNo : '1');
    request.Limit = ((request.Limit > 0 && request.Limit <= 50) ? request.Limit : '16');
    let offset = (request.PageNo * request.Limit - request.Limit);
    let query = `SELECT mb.BlogID,mb.BlogTitle, mb.PageSlug,IFNULL(mb.PageDescription,'') as PageDescription, mb.MediaImage, mb.ThumbnailImage as ThumbImage,mb.MiniImage,DATE_FORMAT(mb.EntryDate, '%Y-%m-%d %H:%i:%s') as EntryDate,mb.BlogLikes,mb.BlogComments,
                        (select IF(LikeID,1,0) from Trn_Blog_Likes as tbl where tbl.BlogID=mb.BlogID AND tbl.StudentID = '` + request.UserId + `' limit 1) as IsLike,
                        TIMESTAMPDIFF(SECOND,mb.EntryDate,NOW()) as SecondDiff,
                        IF(mb.BlogCategory != '',(SELECT CONCAT(ParameterValue,'[',ParameterValueID,']') FROM Mst_ParameterValue where ParameterValueID = mb.BlogCategory and ParameterTypeID='40'),"-") as Category,
                        IF(mb.BlogTag != '',(SELECT GROUP_CONCAT(ParameterValue,'[',ParameterValueID,']') FROM Mst_ParameterValue where FIND_IN_SET(ParameterValueID, mb.BlogTag) and ParameterTypeID='41' ),"-") as Tags
                    FROM
                        Mst_Blogs as mb
                    WHERE 
                        /* mb.StartDate <= CURDATE() 
                        AND mb.EndDate >= CURDATE() 
                        AND */ 
                    mb.Active = 1 ` + where + `
                    HAVING 1 ` + having + `
                    ORDER BY mb.EntryDate DESC LIMIT ` + offset + `, ` + request.Limit;
    let blog_list = await sqlhelper.select(query, where_array, (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (res.length <= 0) {
            return 0;
        } else {
            return json_response(res);
        }
    });

    var response = {
        'status': '0',
        'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
        'data': {},
    };

    if (blog_list.length > 0) {
        let BlogFiler = {};
        let BFRCategory = [];
        let BFRTags = [];
        for (let i = 0; i < blog_list.length; i++) {
            blog_list[i]['TimeLabel'] = moment.duration(-blog_list[i]['SecondDiff'], 'seconds').humanize(true);
            blog_list[i]['link'] = '/blog/' + blog_list[i]['PageSlug'];
            blog_list[i]['PageUrl'] = process.env.STUDENT_PANEL_LINK + '/blog/' + blog_list[i]['PageSlug'];
            delete blog_list[i]['PageSlug'];
            // This logic develp for masonry effect on front side --Start by Parth Devani 04-05-2021    
            if (blog_list[i]['Category'] != '-' && blog_list[i]['Category'] != null) {

                let category = blog_list[i]['Category'];
                let CategoryID = category.substring(category.indexOf("[") + 1, category.indexOf("]"));
                let CategoryName = category.substring(0, category.indexOf(CategoryID) - 1);
                let BFCategory = {};
                BFCategory['ID'] = CategoryID;
                BFCategory['Name'] = CategoryName;
                if (!_.some(BFRCategory, BFCategory)) {
                    BFRCategory.push(BFCategory);
                }
                blog_list[i]['Category'] = CategoryName;
                blog_list[i]['FilterID'] = CategoryID;
            } else {
                blog_list[i]['Category'] = '-';
                blog_list[i]['FilterID'] = i;
            }

            if (blog_list[i]['Tags'] != '-' && blog_list[i]['Tags'] != null) {
                let BlogTagsArray = blog_list[i]['Tags'].split(',');
                if (BlogTagsArray.length > 0) {
                    for (let t = 0; t < BlogTagsArray.length; t++) {
                        let tags = BlogTagsArray[t];
                        let TagID = tags.substring(tags.indexOf("[") + 1, tags.indexOf("]"));
                        let TagName = tags.substring(0, tags.indexOf(TagID) - 1);
                        let BFTag = {};
                        BFTag['ID'] = TagID;
                        BFTag['Name'] = TagName;
                        if (!_.some(BFRTags, BFTag)) {
                            BFRTags.push(BFTag);
                        }
                    }
                }
            }

            // end by Parth Devani

        }
        BlogFiler['Category'] = BFRCategory;
        BlogFiler['Tags'] = BFRTags;


        response.status = '1';
        response.message = 'The Data Fetching process is completed successfully.';
        response.data = {
            'CurrentPage': parseInt(request.PageNo),
            'TotalPage': parseInt(Math.ceil(total_record / request.Limit)),
            'TotalRecord': parseInt(total_record),
            'List': blog_list,
            'BlogFilter': BlogFiler
        };

    }
    callback(null, json_response(response));
}

User.GetBlogCategory = async (request, callback) => {
    let para_query = 'SELECT CAST(ParameterValueID AS CHAR) AS Id, ParameterValue AS Name FROM Mst_ParameterValue WHERE ParameterTypeID="40 AND Active="1" ORDER BY DisplayOrder ASC';
    let blogCategory_list = await sqlhelper.select(para_query, [], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (res.length <= 0) {
            return 0;
        } else {
            return json_response(res);
        }
    });
    if (blogCategory_list == 0) {
        return;
    }

    var response = {
        'status': '0',
        'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
        'data': {},
    };

    if (blogCategory_list.length > 0) {
        response.status = '1';
        response.message = 'The Data Fetching process is completed successfully.';
        response.data = {
            'List': blogCategory_list,
        };
    }

    callback(null, json_response(response));
}

User.GetBlogCategoryCount = async (request, callback) => {

    let para_query = 'SELECT CAST(mp.ParameterValueID AS CHAR) AS Id, mp.ParameterValue AS Name,COUNT(mb.BlogID) as CountCategoory FROM Mst_ParameterValue as mp LEFT JOIN Mst_Blogs AS mb on mb.BlogCategory=mp.ParameterValueID and mb.Active = 1 and mb.StartDate <= NOW() and mb.EndDate >= NOW() WHERE mp.ParameterTypeID="40" AND mp.Active=1 group by mp.ParameterValueID';
    let blogCategory_list = await sqlhelper.select(para_query, [], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (res.length <= 0) {
            return 0;
        } else {
            return json_response(res);
        }
    });
    if (blogCategory_list == 0) {
        return;
    }

    var response = {
        'status': '0',
        'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
        'data': {},
    };

    if (blogCategory_list.length > 0) {
        let sum = 0;
        for (let i = 0; i < blogCategory_list.length; i++) {
            sum = sum + parseInt(blogCategory_list[i]['CountCategoory']);
        }
        response.status = '1';
        response.message = 'The Data Fetching process is completed successfully.';
        response.data = {
            'List': blogCategory_list,
            'Total': sum
        };
    }

    callback(null, json_response(response));
}

User.GetRecentBlog = async (request, callback) => {
    let fromDate = moment().subtract(30, "days").format('YYYY-MM-DD');
    let toDate = moment().format('YYYY-MM-DD');
    /* mb.StartDate <= CURDATE()  
                        AND mb.EndDate >= CURDATE()
                        HAVING RecentDate>= '`+fromDate+`' AND RecentDate<= '`+toDate+`' AND */
    let query = `SELECT mb.BlogID, mb.BlogTitle, mb.MediaImage,mb.MiniImage,mb.ThumbnailImage as ThumbImage,mb.EntryDate as RecentDate,mb.PageSlug,
                        TIMESTAMPDIFF(SECOND,mb.EntryDate,NOW()) as SecondDiff, 
                        IF(mb.BlogCategory != '',(SELECT ParameterValue FROM Mst_ParameterValue where ParameterValueID = mb.BlogCategory and ParameterTypeID='40'),"") as Category, 
                        IF(mb.BlogTag != '',(SELECT GROUP_CONCAT(ParameterValue) FROM Mst_ParameterValue where FIND_IN_SET(ParameterValueID, mb.BlogTag) and ParameterTypeID='41'),"") as Tags 
                    FROM 
                        Mst_Blogs as mb 
                    WHERE 
                        mb.Active = 1
                    ORDER BY mb.EntryDate DESC LIMIT 05`;
    let blog_list = await sqlhelper.select(query, [], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (res.length <= 0) {
            return 0;
        } else {
            return json_response(res);
        }
    });

    var response = {
        'status': '0',
        'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
        'data': {},
    };

    if (blog_list.length > 0) {
        for (let i = 0; i < blog_list.length; i++) {
            blog_list[i]['TimeLabel'] = moment.duration(-blog_list[i]['SecondDiff'], 'seconds').humanize(true);
            blog_list[i]['link'] = '/blog/' + blog_list[i]['PageSlug'];
            delete blog_list[i]['PageSlug'];
        }

        response.status = '1';
        response.message = 'The Data Fetching process is completed successfully.';
        response.data = {
            'List': blog_list,
        };
    }
    callback(null, json_response(response));
}

User.GetBlogDetail = async (request, callback) => {

    let query = `SELECT mb.BlogID,mb.PageTitle as SEOTitle,mb.SeoKeyword as SEOKeyword, mb.PageDescription as SEODes,mb.BlogTitle, mb.MediaImage, mb.Description, mb.Body,mb.BlogLikes,mb.BlogComments,
                        (select IF(tbl.LikeID,1,0) from Trn_Blog_Likes as tbl where tbl.BlogID=mb.BlogID AND tbl.StudentID = '` + request.UserId + `' limit 1) as IsLike,
                        TIMESTAMPDIFF(SECOND,mb.EntryDate,NOW()) as SecondDiff,
                        IF(mb.BlogCategory != '',(SELECT ParameterValue FROM Mst_ParameterValue where ParameterValueID = mb.BlogCategory and ParameterTypeID='40'),"") as Category, 
                        mb.BlogCategory as CategoryID,
                        IF(mb.BlogTag != '',(SELECT GROUP_CONCAT(ParameterValue) FROM Mst_ParameterValue where FIND_IN_SET(ParameterValueID, mb.BlogTag) and ParameterTypeID='41'),"") as Tags 
                    FROM 
                        Mst_Blogs as mb 
                    WHERE 
                        mb.PageSlug = ? `;
    let blog_data = await sqlhelper.select(query, [request.PageSlug], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (res.length <= 0) {
            return 0;
        } else {
            return json_response(res[0]);
        }
    });

    var response = {
        'status': '0',
        'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
        'data': {},
    };

    if (blog_data != 0) {
        blog_data['TimeLabel'] = moment.duration(-blog_data['SecondDiff'], 'seconds').humanize(true);


        response.status = '1';
        response.message = 'The Data Fetching process is completed successfully.';
        response.data = blog_data;
    }
    callback(null, json_response(response));
}

User.GetBlogStaticData = async (request, callback) => {
    let finalData = {};
    let fromDate = moment().subtract(30, "days").format('YYYY-MM-DD');
    let toDate = moment().format('YYYY-MM-DD');
    // mb.StartDate <= CURDATE()  
    // AND mb.EndDate >= CURDATE()
    // HAVING RecentDate>= '`+fromDate+`' AND RecentDate<= '`+toDate+`'
    let query1 = `SELECT mb.BlogID, mb.BlogTitle,mb.MiniImage, mb.MediaImage,mb.ThumbnailImage as ThumbImage,mb.EntryDate as RecentDate,mb.PageSlug,
                        TIMESTAMPDIFF(SECOND,mb.EntryDate,NOW()) as SecondDiff, 
                        IF(mb.BlogCategory != '',(SELECT ParameterValue FROM Mst_ParameterValue where ParameterValueID = mb.BlogCategory and ParameterTypeID='40'),"") as Category, 
                        IF(mb.BlogTag != '',(SELECT GROUP_CONCAT(ParameterValue) FROM Mst_ParameterValue where FIND_IN_SET(ParameterValueID, mb.BlogTag) and ParameterTypeID='41'),"") as Tags 
                    FROM 
                        Mst_Blogs as mb 
                    WHERE 
                        mb.Active = 1
                    ORDER BY mb.EntryDate DESC LIMIT 05`;
    let blog_list1 = await sqlhelper.select(query1, [], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (res.length <= 0) {
            return 0;
        } else {
            return json_response(res);
        }
    });

    if (blog_list1.length > 0) {
        for (let i = 0; i < blog_list1.length; i++) {
            blog_list1[i]['TimeLabel'] = moment.duration(-blog_list1[i]['SecondDiff'], 'seconds').humanize(true);
            blog_list1[i]['link'] = '/blog/' + blog_list1[i]['PageSlug'];
            delete blog_list1[i]['PageSlug'];
        }
    }

    finalData['RecentBlog'] = blog_list1;

    let query2 = `SELECT mb.BlogID,mb.PageSlug, mb.BlogTitle,mb.IsheaderBlog, mb.MediaImage,DATE_FORMAT(mb.EntryDate, '%Y-%m-%d %H:%i:%s') as EntryDate,mb.BlogCategory,
                        TIMESTAMPDIFF(SECOND,mb.EntryDate,NOW()) as SecondDiff, 
                        IF(mb.BlogCategory != '',(SELECT ParameterValue FROM Mst_ParameterValue where ParameterValueID = mb.BlogCategory and ParameterTypeID='40'),"") as Category, 
                        IF(mb.BlogTag != '',(SELECT GROUP_CONCAT(ParameterValue) FROM Mst_ParameterValue where FIND_IN_SET(ParameterValueID, mb.BlogTag) and ParameterTypeID='41'),"") as Tags 
                    FROM 
                        Mst_Blogs as mb 
                    WHERE 
                        mb.StartDate <= CURDATE() 
                        AND mb.EndDate >= CURDATE() 
                        AND mb.Active = 1 AND mb.IsheaderBlog=1`;
    let blog_list2 = await sqlhelper.select(query2, [], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (res.length <= 0) {
            return 0;
        } else {
            return json_response(res[0]);
        }
    });

    if (blog_list2 != 0) {
        blog_list2['TimeLabel'] = moment.duration(-blog_list2['SecondDiff'], 'seconds').humanize(true);
        blog_list2['link'] = '/blog/' + blog_list2['PageSlug'];
        delete blog_list2['PageSlug'];
    }

    finalData['HeaderBlog'] = blog_list2;

    // let query3 = 'SELECT CAST(mp.ParameterValueID AS CHAR) AS Id, mp.ParameterValue AS Name,COUNT(mb.BlogID) as CountCategoory FROM Mst_ParameterValue as mp LEFT JOIN Mst_Blogs AS mb on mb.BlogCategory=mp.ParameterValueID and mb.Active = 1 and mb.StartDate <= NOW() and mb.EndDate >= NOW() WHERE mp.ParameterTypeID="40" AND mp.Active=1 group by mp.ParameterValueID ORDER BY CountCategoory DESC';
    // and mb.StartDate <= NOW() and mb.EndDate >= NOW()
    let category_query = `SELECT mp.ParentParameterValue as ParentID,
    (select pmv.ParameterValue from Mst_ParameterValue as pmv where pmv.ParameterValueID=mp.ParentParameterValue) as ParentCategory,
    CAST(mp.ParameterValueID AS CHAR) AS Id, mp.ParameterValue AS Name,COUNT(mb.BlogID) as CountCategoory 
    FROM Mst_ParameterValue as mp 
    LEFT JOIN Mst_Blogs AS mb on mb.BlogCategory=mp.ParameterValueID and mb.Active = 1 
    WHERE mp.ParameterTypeID="40" AND mp.Active=1 group by mp.ParameterValueID ORDER BY CountCategoory DESC`;
    let catrgory_list = await sqlhelper.select(category_query, [], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (res.length <= 0) {
            return 0;
        } else {
            return json_response(res);
        }
    });
    // console.log(catrgory_list)
    let NewCategoryArray = [];
    let tmp = {};
    let countIndex = [];
    for (const [key, item] of Object.entries(catrgory_list)) {
        tmp = {
            Id: item.Id,
            Name: item.Name,
            CountCategoory: item.CountCategoory
        }
        if (item.ParentID > 0) {
            if (countIndex.includes(item.ParentID)) {
                let addedIndex = countIndex.indexOf(item.ParentID);
                NewCategoryArray[addedIndex].ChieldData.push(tmp);
            } else {
                countIndex.push(item.ParentID);
                let tmpobj = {
                    ParentID: item.ParentID,
                    ParentCategory: item.ParentCategory,
                    ChieldData: []
                }
                tmpobj.ChieldData.push(tmp);
                NewCategoryArray.push(tmpobj);
            }
        }
    }
    // console.log(NewCategoryArray);
    finalData['CategoryList'] = NewCategoryArray;
    finalData['SubCategoryList'] = catrgory_list;

    var response = {
        'status': '1',
        'message': 'The Data Fetching process is completed successfully.',
        'data': finalData,
    };

    callback(null, json_response(response));
}

User.AddToBlogLike = async (request, callback) => {
    let response = {};
    let check_query = `SELECT LikeID FROM Trn_Blog_Likes WHERE BlogID=? AND StudentID=?`
    let check_data = await sqlhelper.select(check_query, [request.BlogID, request.UserId], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (_.isEmpty(res)) {
            return 0;
        } else {
            return json_response(res);
        }
    });
    let get_totalLikes_query = `SELECT BlogLikes as totalLikes FROM Mst_Blogs WHERE BlogID=?`
    let get_totalLikes = await sqlhelper.select(get_totalLikes_query, [request.BlogID], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else {
            return json_response(res[0]['totalLikes']);
        }
    });
    if (check_data != 0) {
        let like = get_totalLikes > 0 ? get_totalLikes - 1 : 0;
        await sqlhelper.update('Mst_Blogs', {
            'BlogLikes': like
        }, {
            'BlogID': request.BlogID
        }, (err, res) => {
            if (err) console.log(err);
            return res.affectedRows;
        });
        let delete_query = 'delete FROM Trn_Blog_Likes WHERE StudentID="' + request.UserId + '" AND BlogID="' + request.BlogID + '"';
        let delete_data = await sqlhelper.select(delete_query, [], (err, res) => {
            if (err) {
                console.log(err)
                callback(err, new Array());
                return 0;
            } else {
                return res.affectedRows;
            }
        });
        response['status'] = '0';
        response['message'] = 'You already liked this block.';
        response['data'] = {
            'BlogLikes': like
        };
    } else {
        let insert_data = {
            'StudentID': request.UserId,
            'BlogID': request.BlogID,
            'EntryDate': moment().format('YYYY-MM-DD HH:mm:ss'),
            'EntryIP': request.IpAddress,
        };

        let insert_id = await sqlhelper.insert('Trn_Blog_Likes', insert_data, (err, res) => {
            if (err) {
                callback(null, json_response(err));
                return 0;
            } else {
                return res['insertId'];
            }
        });

        if (insert_id > 0) {
            let addlike = get_totalLikes + 1;
            await sqlhelper.update('Mst_Blogs', {
                'BlogLikes': addlike
            }, {
                'BlogID': request.BlogID
            }, (err, res) => {
                if (err) console.log(err);
                return res.affectedRows;
            });
            response['status'] = '1';
            response['message'] = 'Your like for the Block has been submitted successfully.';
            response['data'] = {
                'BlogLikes': addlike
            };
        }
    }
    callback(null, json_response(response));
}

User.AddBlogToComment = async (request, callback) => {
    let response = {};
    let check_query = `SELECT CommentID FROM Trn_Blog_Comments WHERE BlogID=? AND StudentID=?`
    let check_data = await sqlhelper.select(check_query, [request.BlogID, request.UserId], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (_.isEmpty(res)) {
            return 0;
        } else {
            return json_response(res);
        }
    });

    if (check_data != 0) {
        response['status'] = '0';
        response['message'] = 'You already commented this block.';
        response['data'] = {
            'BlogComments': 0
        };
    } else {
        let insert_data = {
            'StudentID': request.UserId,
            'BlogID': request.BlogID,
            'EntryDate': moment().format('YYYY-MM-DD HH:mm:ss'),
            'EntryIP': request.IpAddress,
            'Name': request.FirstName,
            'Email': request.Email,
            'URL': (request.Website ? request.Website : ''),
            'Message': request.Comment,
        };

        let insert_id = await sqlhelper.insert('Trn_Blog_Comments', insert_data, (err, res) => {
            if (err) {
                callback(null, json_response(err));
                return 0;
            } else {
                return res['insertId'];
            }
        });

        if (insert_id > 0) {
            let get_totalCommets_query = `SELECT count(CommentID) as totalComment FROM Trn_Blog_Comments WHERE BlogID=?`
            let get_totalCommets = await sqlhelper.select(get_totalCommets_query, [request.BlogID], (err, res) => {
                if (err) {
                    callback(json_response(err), null);
                    return 0;
                } else {
                    return json_response(res[0]['totalComment']);
                }
            });

            let update_data = {
                'BlogComments': get_totalCommets
            };
            let where_data = {
                'BlogID': request.BlogID
            };

            await sqlhelper.update('Mst_Blogs', update_data, where_data, (err, res) => {
                if (err) console.log(err);
                return res.affectedRows;
            });

            response['status'] = '1';
            response['message'] = 'Your comment for the Block has been submitted successfully.';
            response['data'] = {
                'BlogComments': update_data['BlogComments']
            };
        }
    }
    callback(null, json_response(response));
}

User.GetRecommList = async (request, callback) => {
    request.PageNo = (request.PageNo > 0 ? request.PageNo : '1');
    request.Limit = ((request.Limit > 0 && request.Limit <= 50) ? request.Limit : '20');

    let where = '';
    if (request.Search != undefined && request.Search.trim() != '') {
        where += ' AND acc.AltAccommodationName LIKE "%' + request.Search + '%" ';
    }

    if (request.PropertyTypeId != undefined && request.PropertyTypeId > 0) {
        where += ' AND FIND_IN_SET(' + request.PropertyTypeId + ', acc.PropertyType) ';
    }

    if (request.FromDate != undefined && request.FromDate.trim() != '') {
        where += 'AND HSE.EntryDate>="' + request.FromDate + ' 00:00:00"';
    }
    if (request.ToDate != undefined && request.ToDate.trim() != '') {
        where += 'AND HSE.EntryDate<="' + request.ToDate + ' 23:59:59"';
    }


    let total_query = `SELECT count(*) as total
                            FROM HST_Student_Email AS HSE
                        INNER JOIN Accommodation AS acc ON FIND_IN_SET(acc.AccommodationID,HSE.AccommodationID)
                        LEFT JOIN Accommodation_Provider AS acc_pro ON acc_pro.ProviderID=acc.ProviderID
                        INNER JOIN Mst_Country AS cm ON cm.CountryID=acc.CountryID
                        INNER JOIN Mst_Country AS cm2 ON cm2.CountryID=acc.CurrencyID
                        LEFT JOIN Mst_State AS sm ON sm.StateID=acc.StateID 
                        LEFT JOIN Mst_City AS ct ON ct.CityID=acc.CityID 
                        WHERE find_in_set(?,StudentID) ` + where + ` ORDER BY HSE.EntryDate DESC`;
    let total_record = await sqlhelper.select(total_query, [request.UserId], (err, res) => {
        if (err || _.size(res) <= 0) {
            console.log(err);
            return 0;
        } else {
            return res[0]['total'];
        }
    });

    let offset = (request.PageNo * request.Limit - request.Limit);
    let acc_query = `SELECT DATE_FORMAT(HSE.EntryDate, "%M %e,%Y") AS Mail_Date,acc.AccommodationID,acc.UniqueID,acc.AltAccommodationName as AccommodationName,acc.PropertyType,acc.AccRating,IF(acc.Active!=0 && acc.CountryID!=0 && acc.StateID!=0,1,0) AS Active,acc.AddressLine1,acc.AddressLine2,acc.IsFeatures,"" AS Distance,cm2.CurrencySymbol,IFNULL(cm.CountryName,"") AS CountryName, IFNULL(sm.StateName,"") AS StateName, IFNULL(ct.CityName,"") AS CityName,
                    (SELECT CAST(IFNULL(sum(arc.TotalBeds), 1) AS CHAR) FROM Accommodation_RoomCategory AS arc WHERE Active="1" AND arc.AccommodationID=acc.AccommodationID) AS TotalBeds,
                    IFNULL(acc_pro.Name, "Ocxee Accommodation") AS ProviderName,IF(acc_pro.RentyType="" || ISNULL(acc_pro.RentyType),"pw",acc_pro.RentyType) AS RentType, CAST(acc.NightlyRate AS CHAR) AS NightlyRate, CAST(acc.WeeklyRate AS CHAR) WeeklyRate, CAST(acc.MonthlyRate AS CHAR) AS MonthlyRate,
                    IFNULL(acc_pro.ImageUrl, "https://ocxeeadmin.s3.eu-west-2.amazonaws.com/ApiProviderImage/oxcee-logo.svg") AS ProviderImageUrl,
                    (SELECT IF(COUNT(wl.WishlistID)>0,"1","0") FROM Accommodation_Wishlist AS wl WHERE wl.AccommodationID=acc.AccommodationID AND wl.StudentID=?) AS IsWishlist
                    FROM HST_Student_Email AS HSE
                    INNER JOIN Accommodation AS acc ON FIND_IN_SET(acc.AccommodationID,HSE.AccommodationID)
                    LEFT JOIN Accommodation_Provider AS acc_pro ON acc_pro.ProviderID=acc.ProviderID
                    INNER JOIN Mst_Country AS cm ON cm.CountryID=acc.CountryID
                    INNER JOIN Mst_Country AS cm2 ON cm2.CountryID=acc.CurrencyID
                    LEFT JOIN Mst_State AS sm ON sm.StateID=acc.StateID 
                    LEFT JOIN Mst_City AS ct ON ct.CityID=acc.CityID 
                    WHERE find_in_set(?,StudentID) ` + where + ` ORDER BY HSE.EntryDate DESC LIMIT ` + offset + `, ` + request.Limit;;
    var acc_data = await sqlhelper.select(acc_query, [request.UserId, request.UserId], (err, res) => {
        if (err) {
            console.log(err);
            callback(err, null);
            return 0;
        } else if (_.isEmpty(res)) {
            callback(null, {
                'status': '0',
                'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
                'data': {}
            });
            return 0;
        } else {
            return json_response(res);
        }
    });

    if (acc_data == 0) {
        return;
    }

    var response = {
        'status': '0',
        'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
        'data': acc_data,
    };

    if (acc_data.length > 0) {
        let AccomIdList = _.map(acc_data, 'AccommodationID');

        let gellery_query = 'SELECT ag.AccommodationID, ' + FieldReplace + ' ag.Caption FROM Accommodation_Gallery AS ag WHERE ag.MediaType="1" AND ag.AccommodationID IN(' + AccomIdList.join(',') + ') ORDER BY ag.DisplayOrder ASC';
        var gellery_data = await sqlhelper.select(gellery_query, [], (err, res) => {
            if (err) {
                console.log(err);
                return {};
            } else {
                return _.groupBy(res, 'AccommodationID');
            }
        });


        for (let i = 0; i < acc_data.length; i++) {

            if (process.env.IsShowProviderIcon == 0) {
                acc_data[i]['ProviderImageUrl'] = '';
            }

            acc_data[i]['ImageUrlList'] = [{
                'ImageUrl': process.env.NotImageFound,
                'Caption': ''
            }];
            if (gellery_data[acc_data[i]['AccommodationID']] != undefined) {
                let tmp_gellery = _.map(gellery_data[acc_data[i]['AccommodationID']], gData => _.omit(gData, ['AccommodationID'])).splice(0, 5);
                acc_data[i]['ImageUrlList'] = tmp_gellery;
            }

            acc_data[i]['IsFeature'] = '0';
            if (acc_data[i]['IsFeatures'] != '' && acc_data[i]['IsFeatures'].split(',').includes('160')) {
                acc_data[i]['IsFeature'] = '1';
            }

            acc_data[i]['IsOffer'] = '0';
            if (acc_data[i]['IsFeatures'] != '' && acc_data[i]['IsFeatures'].split(',').includes('161')) {
                acc_data[i]['IsOffer'] = '1';
            }
            delete acc_data[i]['IsFeatures'];

            let AccSlug = await Common.GenerateAccSlug(acc_data[i]['AccommodationName'], acc_data[i]['CountryName'], acc_data[i]['StateName'], acc_data[i]['CityName'], acc_data[i]['UniqueID']);
            acc_data[i]['AccommodationSlug'] = AccSlug;
            delete acc_data[i]['CountryName'];
            delete acc_data[i]['StateName'];
            delete acc_data[i]['CityName'];
        }

        response.status = '1';
        response.message = 'The Data Fetching process is completed successfully.';
        response.data = {
            'CurrentPage': request.PageNo,
            'TotalPage': Math.ceil(total_record / request.Limit).toString(),
            'TotalRecord': total_record.toString(),
            'List': acc_data,
        };

    }

    callback(null, json_response(response));
}

User.SetUserPassword = async (request, callback) => {
    // console.log(request)
    let user_query = `SELECT CAST(StudentID AS CHAR) AS UserId,CAST(ChannelPartnerID AS CHAR) AS ChannelPartnerID,
    CAST(IsVarifiedCommsssion AS CHAR) AS IsVarifiedCommsssion,OrderID,concat(FirstName," ",LastName) as Name, Email FROM Student WHERE StudentID=? LIMIT 1`;
    let user_data = await sqlhelper.select(user_query, [request.UserId], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (_.isEmpty(res)) {
            callback(null, json_response({
                'status': '0',
                'message': 'Dear, user your account is not found. Check your details and try again.'
            }));
            return 0;
        } else {
            return json_response(res[0]);
        }
    });

    if (user_data == 0) {
        return;
    }

    let update_data = {
        'Active': '1',
        'IsApprove': 1,
        'Password': md5(request.Password),
        'UpdateDate': moment().format('YYYY-MM-DD HH:mm:ss'),
        'UpdateIP': request.IpAddress,
    }

    let where = {
        'StudentID': request.UserId
    }
    let StudentVarfied = await sqlhelper.update('Student', update_data, where, async (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return -1;
        } else if (res.affectedRows == 0) {
            callback(null, json_response({
                'status': '0',
                'message': 'Sorry, something went wrong; please check your internet connection or try again later.'
            }));
            return -1;
        } else {
            let reset_pass_link = process.env.STUDENT_PANEL_LINK + 'home';
            let EmailData = await Common.GetEmailTemplate('FrontEnd.StartExploring');
            if (_.size(EmailData) > 0) {
                let body = EmailData['Body']
                    .replace('{First Name}', user_data['Name'])
                    .replace('{link}', reset_pass_link);

                let MailData = {
                    'mail_to': user_data['Email'],
                    'subject': EmailData['Subject'],
                    'body': body,
                    // 'cc_mail': EmailData['CCEmail'],
                };
                await Common.SendEmailSMTP(MailData);
            }
            return res;
        }
    });
    // console.log(StudentVarfied)
    if (StudentVarfied != -1 && user_data.ChannelPartnerID != '0' && user_data.IsVarifiedCommsssion == '0') {

        // let Amount = await Common.GetSettingValue('Student_Varification_Commission');
        let StudentCount = await Common.ReferralStudentCalculation(user_data.ChannelPartnerID);

        let CommissionData = await Common.GetCommissionCategory(StudentCount);
        console.log(CommissionData);
        let Amount = CommissionData.Commission_Per_Student;
        let CP_Category = CommissionData.CP_Category_Id;

        let OrderID = user_data.OrderID;
        let LedgerID = await Common.GetLedgerID(user_data.ChannelPartnerID);
        if (LedgerID && OrderID) {
            let CommRequest = {
                'LedgerID': LedgerID,
                'Amount': Amount,
                'OrderID': OrderID,
                'narretion': user_data.UserId + ' Student Varification Commission'
            }
            let Data = await Common.Ac_Wallet_Transaction_Entry(CommRequest);
            if (StudentCount == CommissionData.Min_Student) {
                let incentive = CommissionData.Cash_Incentive;
                let OrderEntry = {
                    'UserID': user_data.ChannelPartnerID,
                    'UserType': 'Channel Partner',
                    'ReferID': user_data.UserId,
                    'OrderAmount': incentive,
                    'Subtotal': incentive,
                    'OrderTypeID': '6',
                    'Status': '2',
                    'OrderDate': moment().format('YYYY-MM-DD'),
                    'OrderNote': "Cash Incentive",
                }
                let IncentiveOrderID = await sqlhelper.insert('User_Order', OrderEntry, (err, res) => {
                    if (err) {
                        console.log(err);
                    } else {
                        console.log("Order Entry Successfully " + res.insertId);
                        return res.insertId;
                    }
                });
                let CommRequest = {
                    'LedgerID': LedgerID,
                    'Amount': incentive,
                    'OrderID': IncentiveOrderID,
                    'narretion': ' Cash Incentive for ' + StudentCount + ' students'
                }
                let Data2 = await Common.Ac_Wallet_Transaction_Entry(CommRequest);
            }
            if (Data == 1) {
                await sqlhelper.update('Student', { 'IsVarifiedCommsssion': '1' }, { 'StudentID': user_data.UserId }, (err, res) => {
                    if (err) console.log(err);
                    else console.log("Stundent Update For Commission");
                });
                let FinalBalance = await Common.BalanceCalculation(LedgerID);
                console.log("FinalBalance Final  Balance -->" + FinalBalance);
                await sqlhelper.update('ChannelPartner', { 'Balance': FinalBalance, 'CP_Category_Id': CP_Category, 'Student_Referral_Count': StudentCount }, { 'LedgerID': LedgerID }, (err, res) => {
                    if (err) console.log(err);
                    else console.log("ChannelPartner Update For Balance");
                });
                await sqlhelper.update('User_Order', { 'Status': '2' }, { 'OrderID': OrderID }, (err, res) => {
                    if (err) console.log(err);
                    else console.log("Stundent Update For Commission");
                });
            } else {
                await sqlhelper.select(`delete from User_Order where OrderID=?`, [OrderID], (err, res) => {
                    if (err) console.log(err);
                });
            }
        }
    }
    var response = {
        'data': [],
        'message': 'Dear User, your Password has been set.',
        'status': '1',
        'token': request.Token,
    };
    callback(null, json_response(response));

}

User.GetSEOConetent = async (request, callback) => {
    let where = '';
    let where_array = [];
    let SEOData = {};
    let CityName = request.CityName.split('-').join(' ');
    let CountryName = request.CountryName.split('-').join(' ');
    where += ` AND cm.CountryName="` + CountryName + `" AND ct.CityName="` + CityName + `" `;
    let seo_query = `SELECT seo.MetaTitle,seo.MetaDescription,seo.MetaKeyword,cm.CurrencySymbol,
                          seom.Title,seom.Description,seo.AccSeoID
                    FROM Accommodation_SEO_Content as seo 
                    LEFT join Accommodation_SEO_Content_multiple AS seom ON seom.AccSeoID=seo.AccSeoID 
                    INNER JOIN Mst_Country AS cm ON cm.CountryID=seo.CountryID 
                    LEFT JOIN Mst_City AS ct ON ct.CityID=seo.CityID 
                    where 1 and seo.Active="1" ` + where + `
                    order by seom.DisplayOrder ASC`;
    let seo_data = await sqlhelper.select(seo_query, where_array, (err, res) => {
        if (err) {
            console.log(err);
            callback(json_response(err), null);
            return 0;
        } else if (res.length <= 0) {
            return 0;
        } else {
            return res;
        }
    });

    let seo_data2 = '';
    if (seo_data == 0) {
        seo_data2 = await sqlhelper.select(`select CurrencySymbol from Mst_Country where 1 AND CountryName='` + request.CountryName + `'`, "", (err, res) => {
            if (err) {
                console.log(err);
                callback(json_response(err), null);
                return 0;
            }
            else
                return res
        })
    }
    if (seo_data != 0) {
        let NearBySearchQuery = "SELECT Type,Title,Url FROM Mst_NearBySearch WHERE Active=1 AND AccSeoID=" + seo_data[0]['AccSeoID'] + " AND Type=3 ORDER BY Sequence";
        var NearBySearchCityData = await sqlhelper.select(NearBySearchQuery, "", (err, res) => {
            if (err) {
                console.log(err);
                callback(json_response(err), null);
                return 0;
            }
            else
                return res
        })
        NearBySearchQuery = "SELECT Type,Title,Url FROM Mst_NearBySearch WHERE Active=1 AND AccSeoID=" + seo_data[0]['AccSeoID'] + " AND Type=2 ORDER BY Sequence";
        var NearBySearchAreaData = await sqlhelper.select(NearBySearchQuery, "", (err, res) => {
            if (err) {
                console.log(err);
                callback(json_response(err), null);
                return 0;
            }
            else
                return res
        })
        NearBySearchQuery = "SELECT Type,Title,Url FROM Mst_NearBySearch WHERE Active=1 AND AccSeoID=" + seo_data[0]['AccSeoID'] + " AND Type=1 ORDER BY Sequence";
        var NearBySearchUniversityData = await sqlhelper.select(NearBySearchQuery, "", (err, res) => {
            if (err) {
                console.log(err);
                callback(json_response(err), null);
                return 0;
            }
            else
                return res
        })
        let FaqQuery = `SELECT FAQ.QueAndAns,FAQ.AccFaqID
                    FROM Accommodation_FAQ_Content as FAQ 
                    where 1 and FAQ.Active=1 AND FAQ.AccSeoID='` + seo_data[0]['AccSeoID'] + `'`;
        var FaqQueryData = await sqlhelper.select(FaqQuery, "", (err, res) => {
            if (err) {
                console.log(err);
                callback(json_response(err), null);
                return -1;
            } else if (res.length > 0) {
                return res[0]['QueAndAns']
            } else {
                return "{}";
            }
        })
        if (FaqQueryData != "" && FaqQueryData) SEOData['FaqQueryData'] = FaqQueryData;
    }
    // console.log(seo_data2)
    var response = {
        'status': '0',
        'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
        'data': {},
    };

    if (seo_data != 0 || seo_data2 != 0) {
        if (seo_data.length > 0) {
            SEOData['SeoHeader'] = {
                'MetaTitle': seo_data[0]['MetaTitle'],
                'MetaDescription': seo_data[0]['MetaDescription'],
                'MetaKeyword': seo_data[0]['MetaKeyword'],
                'CurrencySymbol': seo_data[0]['CurrencySymbol']
            }

            SEOData['SEOBody'] = await _.map(seo_data, object => {
                return _.omit(object, ['MetaTitle', 'MetaDescription', 'MetaKeyword', 'CurrencySymbol'])
            });
            SEOData['NearBySearchCityData'] = NearBySearchCityData;
            SEOData['NearBySearchAreaData'] = NearBySearchAreaData;
            SEOData['NearBySearchUniversityData'] = NearBySearchUniversityData;


            var response = {
                'status': '1',
                'message': 'Successfully fetched Data.',
                'data': SEOData,
            };

        }
        else if (seo_data2.length > 0) {
            SEOData['SeoHeader'] = {
                'MetaTitle': '',
                'MetaDescription': '',
                'MetaKeyword': '',
                'CurrencySymbol': seo_data2[0]['CurrencySymbol']
            }
            var response = {
                'status': '1',
                'message': 'Successfully fetched Data.',
                'data': SEOData,
            };
        }
        callback(null, json_response(response));
    }
}
User.GetRecentServiceWiseBlog = async (request, callback) => {
    let where = 'mb.StartDate <= CURDATE() AND mb.EndDate >= CURDATE() AND mb.Active = 1';
    let whereArray = [];
    if (request.BlogCategory) {
        where += 'AND mb.BlogCategory = ?';
        whereArray.push(request.BlogCategory);
    }
    let query = `SELECT mb.BlogID, mb.BlogTitle, mb.MediaImage,mb.ThumbnailImage as ThumbImage,mb.EntryDate as RecentDate,mb.PageSlug as link,
                        TIMESTAMPDIFF(SECOND,mb.EntryDate,NOW()) as SecondDiff
                    FROM 
                        Mst_Blogs as mb 
                    WHERE ` + where + `
                    ORDER BY mb.EntryDate DESC LIMIT 15`;
    let blog_list = await sqlhelper.select(query, [whereArray], (err, res) => {
        if (err) {
            callback(json_response(err), [

            ]);
            return 0;
        } else if (res.length <= 0) {
            return [];
        } else {
            return json_response(res);
        }
    });
    if (blog_list.length > 0) {
        blog_list.map(x => {
            x.SecondDiff = moment.duration(-x.SecondDiff, 'seconds').humanize(true),
                x.link = '/blog/' + x.link
        });
    }
    callback(null, json_response(blog_list));
}

User.GetRecentServiceWiseNews = async (request, callback) => {
    let where = 'mb.StartDate <= CURDATE() AND mb.EndDate >= CURDATE() AND mb.Active = 1';
    let whereArray = [];
    if (request.NewsCategory) {
        where += 'AND mb.NewsCategory = ?';
        whereArray.push(request.NewsCategory);
    }
    let query = `SELECT mb.NewsID, mb.Title, mb.MediaURL,mb.ThumbnailImage as ThumbImage,mb.EntryDate as RecentDate,
                        TIMESTAMPDIFF(SECOND,mb.EntryDate,NOW()) as SecondDiff
                    FROM 
                        Mst_News as mb 
                    WHERE ` + where + `
                    ORDER BY mb.EntryDate DESC LIMIT 15`;
    let NewsData = await sqlhelper.select(query, [whereArray], (err, res) => {
        if (err) {
            console.log(err);
            callback(json_response(err), []);
            return 0;
        } else if (res.length <= 0) {
            return [];
        } else {
            return json_response(res);
        }
    });

    if (NewsData.length > 0) {
        NewsData.map(x => {
            x.SecondDiff = moment.duration(-x.SecondDiff, 'seconds').humanize(true)
            // x.link='/blog/'+x.link
        });
    }
    callback(null, json_response(NewsData));
}

User.GetAccommodationBookedDate = async (AccommodationID, callback) => {
    let query = 'SELECT DATE_FORMAT(FromDate,"%Y-%m-%d") as FromDate,DATE_FORMAT(ToDate,"%Y-%m-%d") as ToDate FROM Accommodation_Booked_Date where Active = "1" AND AccommodationID = ?';
    let acc_book_date = await sqlhelper.select(query, [AccommodationID], (err, res) => {
        if (err || _.size(res) <= 0) {
            if (err) console.log(err);
            return [];
        } else {
            return json_response(res);
        }
    });
    let BookedDate = [];

    if (acc_book_date.length != 0) {
        let TempDate = [];
        const fn = _.spread(_.union);
        for (let index = 0; index < acc_book_date.length; index++) {
            const element = acc_book_date[index];

            var getDaysBetweenDates = function (startDate, endDate) {
                var now = startDate.clone(),
                    dates = [];
                while (now.isSameOrBefore(endDate)) {
                    dates.push(now.format('DD-MM-YYYY'));
                    now.add(1, 'days');
                }
                return dates;
            };

            const startDate = moment(element.FromDate, "YYYY-MM-DD");
            const endDate = moment(element.ToDate, "YYYY-MM-DD");
            const dateList = await getDaysBetweenDates(startDate, endDate);
            TempDate.push(dateList);
        }
        const result = await fn(TempDate);
        BookedDate = result;
    }
    callback(null, BookedDate);
}

User.GroupedAccommodation = async (request, callback) => {
    let where_having = '';
    let where = '';
    let where_array = [];

    // if (request.AreaName != undefined && request.AreaName != '') {
    //     where += ' AND acc.Area=? ';
    //     where_array.push(request.AreaName);
    // }

    // if (request.CityName != undefined && request.CityName != '') {
    //     where += ' AND ct.CityName=? ';
    //     where_array.push(request.CityName);
    // }

    // if(request.StateName != undefined && request.StateName != ''){
    //     where += ' AND sm.StateName=? ';
    //     where_array.push(request.StateName);
    // }  

    if (request.CountryName != undefined && request.CountryName != '') {
        where += ' AND cm.CountryName=? ';
        where_array.push(request.CountryName);
    }

    if (request.PropertyTypeId != undefined && _.size(request.PropertyTypeId) > 0 && _.isArray(request.PropertyTypeId)) {
        where += '';
        let where_or = '';
        _.each(request.PropertyTypeId, (pData, pIndex) => {
            where_or += (pIndex > 0 ? ' OR' : '') + ' FIND_IN_SET(?, acc.PropertyType) ';
            where_array.push(pData);
        });
        where += (where_or != '' ? ' AND (' + where_or + ')' : '');
    }

    if (request.IsFeature != undefined && request.IsFeature != '' && request.IsFeature != '0') {
        where += ' AND FIND_IN_SET(?, acc.IsFeatures) ';
        where_array.push(request.IsFeature);
    }

    if (request.MinBed != undefined && request.MinBed > 0) {
        where_having += ' AND TotalBeds >= ' + request.MinBed;
    }

    if (request.MaxBed != undefined && request.MaxBed > 0) {
        where_having += ' AND TotalBeds <= ' + request.MaxBed;
    }

    if (request.MinPrice != undefined && request.MinPrice > 0) {
        where += ' AND acc.WeeklyRate >= ? ';
        where_array.push(request.MinPrice);
    }

    if (request.MaxPrice != undefined && request.MaxPrice > 0) {
        where += ' AND acc.WeeklyRate <= ? ';
        where_array.push(request.MaxPrice);
    }
    let extra = ''
    if (request.MoveinDate != undefined && request.MoveinDate != '') {
        extra = `AND acc.AccommodationID IN (SELECT AccommodationID from Accommodation_RoomCategoryRent as acc_room INNER JOIN Mst_ParameterValue AS pv ON pv.ParameterValueID=acc_room.IntakeTypeID AND acc_room.Active=1 AND acc_room.Status>0`
        extra += ' AND DATE_FORMAT(acc_room.StartDate, "%Y %m")=DATE_FORMAT("' + request.MoveinDate + '","%Y %m") '
    }
    if (request.MoveoutDate != undefined && request.MoveoutDate != '') {
        if (extra == '') {
            extra = `AND acc.AccommodationID IN (SELECT AccommodationID from Accommodation_RoomCategoryRent as acc_room INNER JOIN Mst_ParameterValue AS pv ON pv.ParameterValueID=acc_room.IntakeTypeID AND acc_room.Active=1 AND acc_room.Status>0`
        }
        extra += ' AND DATE_FORMAT(acc_room.EndDate, "%Y %m")=DATE_FORMAT("' + request.MoveoutDate + '","%Y %m") '
    }
    if ((request.MoveinDate != undefined && request.MoveinDate != '') || (request.MoveoutDate != undefined && request.MoveoutDate != '')) {
        where += extra + ' OR pv.ParameterValueID=169)'
    }
    let order_by = ' ORDER BY acc.IsFeatures, Distance ASC ';
    if (request.SortBy != undefined && request.SortBy != null && request.SortBy.trim() == 'PriceLowHigh') {
        order_by = ' ORDER BY acc.WeeklyRate ASC, Distance ASC ';
    } else if (request.SortBy != undefined && request.SortBy != null && request.SortBy.trim() == 'PriceHighLow') {
        order_by = ' ORDER BY acc.WeeklyRate DESC, Distance ASC ';
    } else if (request.SortBy != undefined && request.SortBy != null && request.SortBy.trim() == 'Distance') {
        order_by = ' ORDER BY acc.IsFeatures, Distance ASC ';
    }

    let acc_query = 'SELECT acc.AccommodationID,IF(acc.ProviderID!=0,acc_pro.ParentName,"Oxcee offline api") AS ParentName, \
    TRUNCATE((3959 * acos(cos(radians(' + request.Latitude + ')) * cos(radians(acc.Latitude)) * cos(radians(acc.Longitude) - radians(' + request.Longitude + ')) + sin(radians(' + request.Latitude + ')) * sin(radians(acc.Latitude)))), 2) AS Distance, \
    (SELECT CAST(IFNULL(sum(arc.TotalBeds), 0) AS CHAR) FROM Accommodation_RoomCategory AS arc WHERE Active="1" AND arc.AccommodationID=acc.AccommodationID) AS TotalBeds, \
    (select group_concat(acc_room.status) from Accommodation_RoomCategoryRent as acc_room inner join Accommodation_RoomCategory as arc on acc_room.AccRoomCategoryID=arc.AccRoomCategoryID AND arc.Active="1" where acc_room.status > 0 AND acc_room.AccommodationID=acc.AccommodationID) as room_status \
    FROM Accommodation AS acc \
    LEFT JOIN Accommodation_Provider AS acc_pro ON acc_pro.ProviderID=acc.ProviderID \
    INNER JOIN Mst_Country AS cm ON cm.CountryID=acc.CountryID \
    INNER JOIN Mst_Country AS cm2 ON cm2.CountryID=acc.CurrencyID  \
    INNER JOIN Mst_State AS sm ON sm.StateID=acc.StateID \
    LEFT JOIN Mst_City AS ct ON ct.CityID=acc.CityID \
    WHERE acc.Active="1" '+ where + ' HAVING Distance<=' + request.DistanceRadius + ' ' + where_having + ' ' + order_by;
    // console.log(acc_query)
    let acc_data = await sqlhelper.select(acc_query, where_array, (err, res) => {
        if (err || _.size(res) <= 0) {
            console.log(err);
            return 0;
        } else {
            return json_response(res);
        }
    });

    var response = {
        'status': '0',
        'message': 'Something is went to wrong.',
        'data': {
            'ProviderList': [],
            'AccList': []
        },
    };

    if (acc_data === 0) {
        response['message'] = 'Sorry, No Data founded. Make sure you have entered the right details.';
    } else {
        let AccList = _.map(acc_data, 'AccommodationID');
        let room_status = _.map(acc_data, 'room_status');
        acc_data = await _.map(acc_data, object => {
            return _.omit(object, ['Distance', 'TotalBeds', 'room_status'])
        });
        let ProviderData = await _.chain(acc_data)
            .groupBy("ParentName")
            .map((value, key) => ({ ParentName: key, Accommodation: _.reverse(_.map(value, 'AccommodationID')) }))
            .value();

        response['message'] = 'Provider Data fetched Successfully.';
        response['data']['ProviderList'] = ProviderData;
        response['data']['AccList'] = AccList;
        response['data']['room_status'] = room_status;
    }
    // console.log("----parent Names-----");
    // console.log(response['data']);

    callback(null, json_response(response));
}

User.GetProviderPriorityList = async (AccList, LIMIT, request, callback) => {

    var response = {
        'status': '0',
        'message': 'Something is went to wrong in Provider Sequence.',
        'data': {
            'orderedList': [],
            'unorderedList': AccList
        },
    };

    let ParentSequence = [];
    let where = '';
    let where_array = [];

    if (request.AreaName != undefined && request.AreaName != '') {
        where += ' AND acclist.Area=? ';
        where_array.push(request.AreaName);
    }

    if (request.CityName != undefined && request.CityName != '') {
        where += ' AND ct.CityName=? ';
        where_array.push(request.CityName);
    }

    if (request.StateName != undefined && request.StateName != '') {
        where += ' AND sm.StateName=? ';
        where_array.push(request.StateName);
    }

    if (request.CountryName != undefined && request.CountryName != '') {
        where += ' AND cm.CountryName=? ';
        where_array.push(request.CountryName);
    }


    let list_query = 'SELECT acclist.ProviderSequence \
        FROM Accommodation_ListingOrder AS acclist \
        INNER JOIN Mst_Country AS cm ON cm.CountryID=acclist.CountryID \
        INNER JOIN Mst_State AS sm ON sm.StateID=acclist.StateID \
        INNER JOIN Mst_City AS ct ON ct.CityID=acclist.CityID \
        WHERE acclist.Active="1" ' + where;
    let list_data = await sqlhelper.select(list_query, where_array, (err, res) => {
        if (err || _.size(res) <= 0) {
            console.log(err);
            return 0;
        } else {
            // console.log(json_response(res[0]));
            return json_response(res[0]);
        }
    });

    if (list_data != 0) {
        const element = list_data['ProviderSequence'];
        ParentSequence = JSON.parse(element);
    } else {

        // console.log('default entry');
        let where_default = '';
        where_default += ' AND acclist.CountryID=0 ';
        where_default += ' AND acclist.StateID=0 ';
        where_default += ' AND acclist.CityID=0 ';

        let default_query = 'SELECT acclist.ProviderSequence \
                                FROM Accommodation_ListingOrder AS acclist \
                                WHERE  Active="1" ' + where_default;
        let default_data = await sqlhelper.select(default_query, [], (err, res) => {
            if (err || _.size(res) <= 0) {
                console.log(err);
                return 0;
            } else {
                return json_response(res[0]);
            }
        });

        // console.log(default_data);

        if (default_data != 0) {
            const element = default_data['ProviderSequence'];
            ParentSequence = JSON.parse(element);
            // console.log('inside sequence');
            // console.log(ParentSequence);
        }
    }

    // let ParentSequence = [
    //     { "ParentName": "Uniplaces", 'Sequence':17, 'NoOfProperety':1 },
    //     { "ParentName": "Study Abroad", 'Sequence':8, 'NoOfProperety':1 },
    //     { "ParentName": "Home Stay", 'Sequence':19, 'NoOfProperety':1 },
    //     { "ParentName": "Housing Anywhere", 'Sequence':14, 'NoOfProperety':1 },
    //     { "ParentName": "UniAcco", 'Sequence':16, 'NoOfProperety':1 },
    //     { "ParentName": "Flatio", 'Sequence':20, 'NoOfProperety':1 },
    //     { "ParentName": "Londonist UK", 'Sequence':2, 'NoOfProperety':1 },
    //     { "ParentName": "TheSquare", 'Sequence':13, 'NoOfProperety':1 },
    //     { "ParentName": "Four Stay", 'Sequence':21, 'NoOfProperety':1 },
    //     { "ParentName": "Coliving", 'Sequence':22, 'NoOfProperety':1 },
    //     { "ParentName": "London Nest", 'Sequence':8, 'NoOfProperety':1 },
    //     { "ParentName": "Harrington Housing", 'Sequence':14, 'NoOfProperety':1 },
    //     { "ParentName": "Homes For Students", 'Sequence':5, 'NoOfProperety':1 },
    //     { "ParentName": "The Stay Club", 'Sequence':1, 'NoOfProperety':3 },
    //     { "ParentName": "AXO Student", 'Sequence':4, 'NoOfProperety':1 },
    //     { "ParentName": "Britannia Students", 'Sequence':3, 'NoOfProperety':1 },
    //     { "ParentName": "Host UK", 'Sequence':9, 'NoOfProperety':1 },
    //     { "ParentName": "The Student Housing Company", 'Sequence':6, 'NoOfProperety':1 },
    //     { "ParentName": "Collegiate AC", 'Sequence':7, 'NoOfProperety':1 },
    //     { "ParentName": "Yara CapitalLtd", 'Sequence':10, 'NoOfProperety':1 },
    //     { "ParentName": "Safestay", 'Sequence':15, 'NoOfProperety':1 },
    //     { "ParentName": "PVL Accommodation", 'Sequence':12, 'NoOfProperety':1 },
    //     { "ParentName": "Oxcee offline api", 'Sequence':30, 'NoOfProperety':1 },
    //     { "ParentName": "IconInc @ Roomzzz", 'Sequence':11, 'NoOfProperety':1 },
    //     { "ParentName": "jahnwales", 'Sequence':29, 'NoOfProperety':1 },
    // ];

    // if ( request.CityName != 'London') {
    //     ParentSequence=[];
    // }

    // console.log(`provider data-${ParentSequence.length}`);
    // console.log(ParentSequence);

    if (ParentSequence.length > 0) {
        let lastSequence = await _.maxBy(ParentSequence, 'Sequence');
        for (let index = 0; index < AccList.length; index++) {
            const element = AccList[index];

            let find_data = { ['ParentName']: element['ParentName'] };
            let find_index = _.findIndex(ParentSequence, find_data);
            if (find_index >= 0) {
                let MinValue = (ParentSequence[find_index]['NoOfProperety'] <= LIMIT ? ParentSequence[find_index]['NoOfProperety'] : LIMIT);
                AccList[index]['Sequence'] = ParentSequence[find_index]['Sequence'];
                AccList[index]['NoOfProperety'] = MinValue;
            } else {
                AccList[index]['Sequence'] = (lastSequence.Sequence + 1);
                AccList[index]['NoOfProperety'] = 1;
            }
        }

        let Sum = _.sumBy(AccList, function (o) { return o.NoOfProperety; })
        // console.log("Sumation of Min value");
        // console.log(Sum);

        // if(Sum<LIMIT){
        //     let additional = LIMIT - Sum ;
        //     let totalProvider= AccList.length;
        //     let dividedCost= ( additional / totalProvider );
        //     let FixSum=Math.floor(dividedCost);
        //     let ExtraSum=Math.ceil(dividedCost);
        //     let ExtraIndex= (additional - totalProvider);

        //     if(ExtraIndex < 0){
        //         ExtraIndex = additional;
        //     }

        //     for (let index = 0; index < AccList.length; index++) {
        //         let SumAmount=0;
        //         let OutLimit=false;
        //         if(index<ExtraIndex){
        //             SumAmount=ExtraSum;
        //         }else{
        //             SumAmount=FixSum;
        //         }
        //         // if(index<ExtraIndex && ((AccList[index]['NoOfProperety']+SumAmount)>LIMIT)){
        //         //     ExtraIndex = ExtraIndex+1;
        //         //     OutLimit=true;
        //         // }else if(index>=ExtraIndex && ((AccList[index]['NoOfProperety']+SumAmount)>LIMIT)){
        //         //     FixSub = FixSub+1;
        //         //     OutLimit=true;
        //         // }
        //         // if(!OutLimit)
        //         // {
        //             AccList[index]['NoOfProperety']=(AccList[index]['NoOfProperety']+SumAmount);
        //         // }
        //     }
        // }else if(Sum>LIMIT){


        //     let less =  Sum - LIMIT  ;
        //     let totalProvider= AccList.length;
        //     let dividedCost= ( less / totalProvider );
        //     let FixSub=Math.ceil(dividedCost);
        //     let ExtraSub=Math.floor(dividedCost);
        //     let ExtraIndex= (totalProvider - less  );

        //     if(ExtraIndex  < 0){
        //         ExtraIndex = (-1 * ExtraIndex);
        //     }

        //     let subIndex=0;
        //     for (let index = (AccList.length-1); index >= 0; index--) {
        //         let SubAmount=0;
        //         let IsNegative = false;

        //         if(subIndex<ExtraIndex && (AccList[index]['NoOfProperety']<ExtraSub)){
        //             ExtraIndex = ExtraIndex+1;
        //             IsNegative=true;
        //         }else if(subIndex>=ExtraIndex && (AccList[index]['NoOfProperety']<FixSub)){
        //             FixSub = FixSub+1;
        //             IsNegative=true;
        //         }

        //         if(!IsNegative){
        //             if(subIndex<ExtraIndex){
        //                 SubAmount=ExtraSub;
        //             }else{
        //                 SubAmount=FixSub;
        //             }
        //             AccList[index]['NoOfProperety']=(AccList[index]['NoOfProperety'] - SubAmount);
        //         }
        //         subIndex= subIndex +1;
        //     }
        // }

        let Sum1 = _.sumBy(AccList, function (o) { return o.NoOfProperety; })
        // console.log("Sum1ation of Min value");
        // console.log(Sum1);

        // console.log("---mapping array---");
        // console.log(AccList);

        // console.log("---orderBy Array---");
        // console.log(_.orderBy(AccList, ['Sequence'], ['asc']));

        response.data.orderedList = await _.orderBy(AccList, ['Sequence'], ['asc']);
    }

    callback(null, json_response(response));
}

User.GenratePageToken = async (request, PageList, room_status, callback) => {
    var response = {
        'status': '0',
        'message': 'Page token is not genrated',
        'token': '0'
    };

    let CountryName = (request.CountryName != undefined ? request.CountryName.trim() : '');
    let StateName = (request.StateName != undefined ? request.StateName.trim() : '');
    let CityName = (request.CityName != undefined ? request.CityName.trim() : '');

    let csc_where_array = [StateName, CityName, CountryName];
    let csc_query = 'SELECT cn.CountryID, IFNULL(st.StateID, 0) AS StateID, IFNULL(ct.CityID, 0) AS CityID FROM Mst_Country AS cn LEFT JOIN Mst_State AS st ON st.CountryID=cn.CountryID AND st.StateName=? LEFT JOIN Mst_City AS ct ON ct.StateID=st.StateID AND ct.CityName=? WHERE cn.CountryName=? LIMIT 1';
    if (CityName != '' && StateName == '') {
        csc_where_array = [CityName, CountryName];
        csc_query = 'SELECT cn.CountryID, IFNULL(st.StateID, 0) AS StateID, IFNULL(ct.CityID, 0) AS CityID FROM Mst_Country AS cn LEFT JOIN Mst_State AS st ON st.CountryID=cn.CountryID LEFT JOIN Mst_City AS ct ON ct.StateID=st.StateID AND ct.CityName=? WHERE cn.CountryName=? AND ct.CityID!="0" LIMIT 1';
    }

    let csc_data = await sqlhelper.select(csc_query, csc_where_array, (err, res) => {
        if (err || res.length <= 0) {
            return {
                'CountryID': '0',
                'StateID': '0',
                'CityID': '0'
            };
        } else {
            return res[0];
        }
    });

    let insert_data = {
        'Source': request.Source,
        'StudentID': request.UserId,
        'Latitude': request.Latitude,
        'Longitude': request.Longitude,
        'SearchText': (request.Search != undefined ? request.Search : ''),
        'Distance': (request.DistanceRadius != undefined ? request.DistanceRadius : '0'),
        'CountryID': csc_data.CountryID,
        'StateID': csc_data.StateID,
        'CityID': csc_data.CityID,
        'PageArray': JSON.stringify(PageList),
        'Area': request.AreaName,
        'PropertyType': (request.PropertyTypeId != undefined ? request.PropertyTypeId.join(',') : ''),
        'MinBed': (request.MinBed != undefined ? request.MinBed : '0'),
        'MaxBed': (request.MaxBed != undefined ? request.MaxBed : '0'),
        'MinPrice': (request.MinPrice != undefined ? request.MinPrice : '0'),
        'MaxPrice': (request.MaxPrice != undefined ? request.MaxPrice : '0'),
        'EntryDate': moment().format('YYYY-MM-DD HH:mm:ss'),
        'EntryIP': request.IpAddress,
    };

    await sqlhelper.insert('Searching_Activity_Log', insert_data, async (err, res) => {
        if (err) {
            callback(err, null);
        } else {
            let token = res.insertId;
            let update_query = 'UPDATE Searching_Activity_Log SET PageToken="' + md5(token) + '" WHERE LogID=?';
            await sqlhelper.select(update_query, [res.insertId], (err, res) => {
                if (err) {
                    console.log(err);
                    callback(err, null);
                } else {
                    // console.log('test');
                    // console.log(token);
                    callback(null, token);
                }
            });
        }
    });
}

User.GetPageDataByToken = async (PageToken, callback) => {
    var response = {
        'status': '0',
        'message': 'Page token is not genrated',
        'PageArray': []
    };

    let page_query = 'SELECT LogID,PageArray FROM `Searching_Activity_Log` WHERE `PageToken`="' + PageToken + '"';

    await sqlhelper.select(page_query, [], (err, res) => {
        if (err) {
            console.log(err);
            callback(err, null)
        } else if (res.length <= 0) {
            callback(null, response)
        } else {
            let PageArray;
            PageArray = JSON.parse(res[0]['PageArray']);
            // response['status']='1';
            // response['message']='Page data successfully retrived.';
            response['PageArray'] = PageArray;
            response['LogID'] = res[0]['LogID'];
            callback(null, response)
        }
    });
}

User.GroupedAccommodationList = async (PageList, request, PageData, all_room_status, callback) => {
    let acc_query = 'SELECT CAST(acc.AccommodationID AS CHAR) AS AccommodationID, acc.UniqueID, acc.AltAccommodationName as AccommodationName, acc.AddressLine1, acc.AddressLine2, acc.Latitude, acc.Longitude, IF(acc.AccRating!="",acc.AccRating,0) AS AccRating, acc.IsFeatures,acc.ProviderID, \
        IFNULL((SELECT IF(ag.MediaUrl!="", ag.MediaUrl, ag.MediaFile) FROM Accommodation_Gallery AS ag WHERE ag.MediaType="1" AND ag.AccommodationID=acc.AccommodationID ORDER BY ag.DisplayOrder ASC LIMIT 1), "' + process.env.NotImageFound + '") AS ImageUrl, \
        IFNULL(acc_pro.Name, "Ocxee Accommodation") AS ProviderName, IFNULL(acc_pro.ImageUrl, "https://ocxeeadmin.s3.eu-west-2.amazonaws.com/ApiProviderImage/oxcee-logo.svg") AS ProviderImageUrl, \
        CAST(TRUNCATE((3959 * acos(cos(radians(' + request.Latitude + ')) * cos(radians(acc.Latitude)) * cos(radians(acc.Longitude) - radians(' + request.Longitude + ')) + sin(radians(' + request.Latitude + ')) * sin(radians(acc.Latitude)))), 2) AS CHAR) AS Distance, \
        IF(acc_pro.RentyType="" || ISNULL(acc_pro.RentyType),"pw",acc_pro.RentyType) AS RentType, CAST(acc.NightlyRate AS CHAR) AS NightlyRate, CAST(acc.WeeklyRate AS CHAR) WeeklyRate, CAST(acc.MonthlyRate AS CHAR) AS MonthlyRate, \
        IFNULL(cm2.CurrencySymbol, "") AS CurrencySymbol, \
        (SELECT CAST(IF(sum(arc.TotalBeds)>0,sum(arc.TotalBeds) ,1) AS CHAR) FROM Accommodation_RoomCategory AS arc WHERE Active="1" AND arc.AccommodationID=acc.AccommodationID) AS TotalBeds, \
        (SELECT IF(COUNT(wl.WishlistID)>0,"1","0") FROM Accommodation_Wishlist AS wl WHERE wl.AccommodationID=acc.AccommodationID AND wl.StudentID="' + request.UserId + '") AS IsWishlist, \
        IFNULL(cm.CountryName,"") AS CountryName, IFNULL(sm.StateName,"") AS StateName, IFNULL(ct.CityName,"") AS CityName, \
        (select group_concat(acc_room.status) from Accommodation_RoomCategoryRent as acc_room inner join Accommodation_RoomCategory as arc on acc_room.AccRoomCategoryID=arc.AccRoomCategoryID AND arc.Active="1" where acc_room.status > 0 AND acc_room.AccommodationID=acc.AccommodationID) as room_status \
        FROM Accommodation AS acc \
        LEFT JOIN Accommodation_Provider AS acc_pro ON acc_pro.ProviderID=acc.ProviderID \
        INNER JOIN Mst_Country AS cm ON cm.CountryID=acc.CountryID \
        INNER JOIN Mst_Country AS cm2 ON cm2.CountryID=acc.CurrencyID \
        INNER JOIN Mst_State AS sm ON sm.StateID=acc.StateID \
        LEFT JOIN Mst_City AS ct ON ct.CityID=acc.CityID \
        WHERE acc.Active="1" and acc.AccommodationID in ('+ PageList + ') ORDER BY FIELD(AccommodationID,' + PageList + ')';
    var acc_data = await sqlhelper.select(acc_query, [], (err, res) => {
        if (err) {
            callback(err, null);
            return 0;
        } else if (_.isEmpty(res)) {
            callback(null, {
                'status': '0',
                'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
                'data': {}
            });
            return 0;
        } else {
            return json_response(res);
        }
    });

    if (acc_data == 0) {
        return;
    }

    var response = {
        'status': '0',
        'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
        'data': {},
    };

    if (acc_data.length > 0) {
        let AccomIdList = _.map(acc_data, 'AccommodationID');
        let ProviderIdList = _.uniq(_.map(acc_data, 'ProviderID'));

        // query = "SELECT af.FeaturesName, pv.Image AS ImageUrl, CAST(af.AccommodationID AS CHAR) AS AccommodationID FROM Accommodation_Features AS af INNER JOIN Mst_ParameterValue AS pv ON pv.ParameterValueID=af.FeaturesID WHERE af.FeaturesID IN(1,2,11,13,14) AND af.AccommodationID IN(" + AccomIdList.join(',') + ") ORDER BY pv.DisplayOrder ASC";
        // var feature_tmp = await sqlhelper.select(query, [], (err, res) => {
        //     if (err) {
        //         console.log(err);
        //         return [];
        //     } else {
        //         return json_response(res);
        //     }
        // });

        // var feature_data = {};
        // _.each(feature_tmp, (fData, fIndex) => {
        //     if (feature_data[fData.AccommodationID] == undefined) {
        //         feature_data[fData.AccommodationID] = [];
        //     }
        //     feature_data[fData.AccommodationID].push({
        //         'Text': fData.FeaturesName,
        //         'ImageUrl': fData.ImageUrl,
        //     });
        // });

        let offer_query = "SELECT AccommodationID,Offer FROM `Accommodation_Offer` where `AccommodationID` IN(" + AccomIdList.join(',') + ") and Active='1' order by DisplayOrder ASC";
        var offer_tmp = await sqlhelper.select(offer_query, [], (err, res) => {
            if (err) {
                console.log(err);
                return [];
            } else {
                return json_response(res);
            }
        });

        var offer_data = {};
        _.each(offer_tmp, (oData, fIndex) => {
            if (offer_data[oData.AccommodationID] == undefined) {
                offer_data[oData.AccommodationID] = [];
            }
            offer_data[oData.AccommodationID].push(oData.Offer);
        });

        let common_offer_query = "SELECT ProviderID,Offer FROM `Accommodation_Offer_Common` where `ProviderID` IN(" + ProviderIdList.join(',') + ") and Active='1' order by DisplayOrder ASC";
        var common_offer_tmp = await sqlhelper.select(common_offer_query, [], (err, res) => {
            if (err) {
                console.log(err);
                return [];
            } else {
                return json_response(res);
            }
        });

        var common_offer_data = {};
        _.each(common_offer_tmp, (coData, fIndex) => {
            if (common_offer_data[coData.ProviderID] == undefined) {
                common_offer_data[coData.ProviderID] = [];
            }
            common_offer_data[coData.ProviderID].push(coData.Offer);
        });

        let gellery_query = 'SELECT ag.AccommodationID, ' + FieldReplace + ' ag.Caption FROM Accommodation_Gallery AS ag WHERE ag.MediaType="1" AND ag.AccommodationID IN(' + AccomIdList.join(',') + ') ORDER BY ag.DisplayOrder ASC';
        // console.log(gellery_query);
        var gellery_data = await sqlhelper.select(gellery_query, [], (err, res) => {
            if (err) {
                console.log(err);
                return {};
            } else {
                return _.groupBy(res, 'AccommodationID');
            }
        });

        for (let i = 0; i < acc_data.length; i++) {
            let message = '';
            let color = '';
            if (acc_data[i].room_status) {
                let room_status = acc_data[i].room_status.split(',');
                let sold_status = room_status.filter(sold => sold === '3');
                // if(sold_status.length===0) { 
                //     message = 'Availability'; 
                //     color='accommodation-list-available-green-bg-ptn.svg';
                // }else 
                if (sold_status.length === room_status.length) {
                    message = 'Sold Out';
                    color = 'accommodation-list-available-red-bg-ptn.svg';
                } else if (sold_status.length > 0 && sold_status.length < room_status.length) {
                    // message = 'Limited availability'; 
                    message = 'Limited availability';
                    color = 'accommodation-list-available-orange-bg-ptn.svg';
                }
            }
            acc_data[i].room_status_message = message;
            acc_data[i].room_status_color = color;


            if (process.env.IsShowProviderIcon == 0) {
                acc_data[i]['ProviderImageUrl'] = ''; // Add by Dhiraj 07-04-21
            }

            if (acc_data[i]['AddressLine1'] == '' && acc_data[i]['AddressLine2'] == '') {
                acc_data[i]['AddressLine1'] = acc_data[i]['CityName'] + ', ' + acc_data[i]['StateName'] + ', ' + acc_data[i]['CountryName'];
            }

            // if (feature_data[acc_data[i]['AccommodationID']] != undefined) {
            //     acc_data[i]['feature_list'] = feature_data[acc_data[i]['AccommodationID']];
            // } else {
            //     acc_data[i]['feature_list'] = [];
            // }

            if (offer_data[acc_data[i]['AccommodationID']] != undefined) {
                acc_data[i]['offer_list'] = offer_data[acc_data[i]['AccommodationID']];
            } else {
                acc_data[i]['offer_list'] = [];
            }

            if (common_offer_data[acc_data[i]['ProviderID']] != undefined) {
                var tempOfferAcc = acc_data[i]['offer_list'];
                var finalOffer = _.concat(tempOfferAcc, common_offer_data[acc_data[i]['ProviderID']]);
                acc_data[i]['offer_list'] = finalOffer;
            }

            acc_data[i]['ImageUrlList'] = [{
                'ImageUrl': process.env.NotImageFound,
                'Caption': ''
            }];
            if (gellery_data[acc_data[i]['AccommodationID']] != undefined) {
                let tmp_gellery = _.map(gellery_data[acc_data[i]['AccommodationID']], gData => _.omit(gData, ['AccommodationID'])).splice(0, 5);
                // tmp_gellery = tmp_gellery.replace(s3link,ImageLink);
                // console.log(tmp_gellery);
                acc_data[i]['ImageUrlList'] = tmp_gellery;
            }

            acc_data[i]['IsFeature'] = '0';
            if (acc_data[i]['IsFeatures'] != '' && acc_data[i]['IsFeatures'].split(',').includes('160')) {
                acc_data[i]['IsFeature'] = '1';
            }
            acc_data[i]['IsOffer'] = '0';
            if (acc_data[i]['IsFeatures'] != '' && acc_data[i]['IsFeatures'].split(',').includes('161')) {
                acc_data[i]['IsOffer'] = '1';
            }
            delete acc_data[i]['IsFeatures'];

            // start generate acc slug
            let AccSlug = await Common.GenerateAccSlug(acc_data[i]['AccommodationName'], acc_data[i]['CountryName'], acc_data[i]['StateName'], acc_data[i]['CityName'], acc_data[i]['UniqueID']);
            acc_data[i]['AccommodationSlug'] = AccSlug;
            acc_data[i]['IsOurSlug'] = AccSlug.includes(process.env.STUDENT_PANEL_LINK) || AccSlug.length <= 0 ? false : true
            delete acc_data[i]['CountryName'];
            delete acc_data[i]['StateName'];
            delete acc_data[i]['CityName'];
            // end generate acc slug
        }
        let all_sold_status = 0;
        let all_room_status_count = 0;
        all_room_status = all_room_status.filter(function (el) { return el != null });
        // console.log(all_room_status);
        if (all_room_status.length > 0) {
            for (let i = 0; i < all_room_status.length; i++) {
                let room_status = all_room_status[i].split(',');
                let sold_status = room_status.filter(sold => sold === '3');
                all_sold_status = all_sold_status + sold_status.length;
                all_room_status_count = all_room_status_count + room_status.length;
            }
        }
        let SoldOutMeter = {};
        let Percentage = parseFloat((all_sold_status * 100 / all_room_status_count).toFixed(2));
        if (Percentage > 50) {
            SoldOutMeter = {
                TotalRooms: all_room_status_count,
                TotalSoldRooom: all_sold_status,
                Percentage: Percentage,
                MeterColor: 'availability-score-meter.svg',
                MeterImage: process.env.S3_LOCATION + 'Mst_Services/availability-score-meter.svg',
                Message: 'in high demand'
            }
            if (Percentage > 50 && Percentage <= 80) {
                SoldOutMeter['MeterColor'] = 'availability-score-meter-orange.svg';
                SoldOutMeter['MeterImage'] = process.env.S3_LOCATION + 'Mst_Services/availability-score-meter-orange.png';
                SoldOutMeter['Message'] = 'in high demand';
            } else if (Percentage > 80 && Percentage <= 100) {
                SoldOutMeter['MeterColor'] = 'availability-score-meter-orange.svg';
                SoldOutMeter['MeterImage'] = process.env.S3_LOCATION + 'Mst_Services/availability-score-meter-red.svg';
                SoldOutMeter['Message'] = 'last few rooms available';
            }
        }
        response.status = '1';
        response.message = 'The Data Fetching process is completed successfully.';
        response.data = {
            'TotalPage': PageData.TotalPage.toString(),
            'TotalRecord': PageData.TotalRecord.toString(),
            'CurrentPage': request.PageNo,
            'List': acc_data,
            'PageToken': PageData.PageToken.toString(),
            'SoldOutMeter': SoldOutMeter
        };
        request['SearchID'] = PageData.SearchID.toString();
        response.data['AdsData'] = await GetAccAdsList(request);
    }
    callback(null, json_response(response));
}

User.SubmitGeneralEnquiry = async (request, callback) => {
    let Source = 'WEB';
    if (request.Source == '2') {
        Source = 'Android';
    } else if (request.Source == '3') {
        Source = 'IOS';
    }

    let insert_data = {
        'Source': Source,
        'FirstName': request.FirstName,
        'LastName': request.LastName,
        'Email': request.Email,
        'MobileNo': request.MobileNo,
        'CountryID': request.CountryID,
        'PageUrl': request.PageUrl,
        'Description': request.Description,
        'UniversityName': request.UniversityName,
        'LatLong': request.LatLong,
        'SerchKeyword': request.SerchKeyword,
        'EntryDate': moment().format('YYYY-MM-DD HH:mm:ss'),
        'EntryIP': request.IpAddress,
    };

    await sqlhelper.insert('GenearlInquiry', insert_data, (err, res) => {
        if (err) {
            console.log(err);
            callback(err, null);
        } else if (res.insertId > 0) {
            callback(null, {
                'status': '1',
                'message': 'Data Submission completed. Your data has been submitted successfully.',
                'data': {}
            });
        } else {
            callback(null, {
                'status': '0',
                'message': 'Somthing is wrong.',
                'data': {}
            });
        }
    });
}

GetAccAdsList = async (request) => {
    let imgsize = "277x306/";
    let ImageLink = process.env.CloudFrontLink + imgsize;
    let s3link = "";
    let where = ` AND (mc.CountryName="${request.CountryName}" AND mcc.CityName="${request.CityName}" And IsCity=1) OR ((mc.CountryName="${request.CountryName}" OR mcc.CityName="${request.CityName}")  And IsCity=0)`
    var response = []
    let query = `SELECT adm.AccAdsID,replace(adm.Ad,"` + s3link + `","` + ImageLink + `") as ImageUrl,adm.AdLink as Url,adm.AdType as Type FROM Accommodation_Ads AS adm 
    left join Mst_Country as mc on mc.CountryID=adm.CountryID
    left join Mst_City as mcc on find_in_set(mcc.CityID, adm.CityID) where adm.Active='1' `+ where + ` group by adm.AccAdsID order by adm.OrderNo asc`;
    let Data = await sqlhelper.select(query, [], (err, res) => {
        if (err) {
            console.log(err);
            return [];
        } else if (res.length <= 0) {
            return [];
        } else {
            return res;
        }
    });
    response = new Promise(async (resolve) => {
        if (Data.length === 0) {
            let default_query = `SELECT adm.AccAdsID,replace(adm.Ad,"` + s3link + `","` + ImageLink + `") as ImageUrl,adm.AdLink as Url,adm.AdType as Type FROM Accommodation_Ads AS adm 
            where adm.Active='1' AND adm.CountryID=0 AND adm.CityID=0 order by adm.OrderNo asc`;

            let Default_Data = await sqlhelper.select(default_query, [], (err, res) => {
                if (err) {
                    console.log(err);
                    return [];
                } else {
                    return res;
                }
            });
            Data = Default_Data;
        }
        for (const item of Data) {
            let LogID = request.SearchID || 0;
            let tmpinsert = {
                'OfferID': item.AccAdsID,
                'ImpType': '1',
                'LogID': LogID,
                'EntryDate': moment().format('YYYY-MM-DD HH:mm:ss'),
                'EntryIP': request.IpAddress
            }
            item['SearchID'] = LogID;
            await sqlhelper.insert('Acc_Ads_Impression', tmpinsert, (err, res) => {
                if (err) console.log(err);
            });
        }
        resolve(Data);
    })
    return response;
}

User.InsertData = async (InsertData, request, callback) => {
    await sqlhelper.insert(request.TableName, InsertData, (err, res) => {
        if (err) {
            console.log(err);
            callback(json_response(err), null);
            return 0;
        } else {
            callback(null, json_response({
                'status': '1',
                'message': ''
            }));
        }
    });
}
User.addFormUrl = async (req, callback) => {
    let update_data = {};
    let request = req.body
    var response = { 'status': '1', 'message': 'something is wrong.', 'data': {} };
    let BookingID = request.BookingID;
    if (request.BookingID > 0) {
        update_data['UpdateBy'] = request.UserID;
        update_data['UpdateDate'] = moment().format('YYYY-MM-DD HH:mm:ss');
        update_data['UpdateIP'] = request.IpAddress;
        if (request.FileUrl != undefined && request.FileUrl.trim() != '') {
            // var ext = path.extname(request.FileUrl);
            var ext = request;
            let file_array = {
                'base64_data': request.FileUrl,
                'file_name': 'Mst_Services/' + uuidv4() + '.' + ext,
                'content_type': '',
            }
            let file_data = await Common.S3FileUpload(file_array);
            if (file_data['Location'] != undefined) {
                console.log(file_data['Location']);
                update_data['FormUrl'] = file_data['Location'];
            }
        }
        let where_data = {
            'BookingID': BookingID,
        };

        let acc_update = await sqlhelper.update('Accommodation_BookingRequest', update_data, where_data, (err, res) => {
            if (err) {
                callback(err, new Array());
                return 0;
            } else {
                console.log(update_data['FormUrl'])
                response['message'] = "Document Successfully Upload";
                response['data'] = update_data['FormUrl'];
                return res;
            }
        });
        if (acc_update == 0) {
            return;
        }
    }
    callback(null, response);
};

User.AddStudentDetails = async (request, Details, callback) => {
    let update_data = {};
    var response = { 'status': '1', 'message': 'something is wrong.', 'data': {} };
    let Student_DetailID = request.Student_DetailID;

    // let BookingID_query = "SELECT BookingID FROM Student_Details2 WHERE BookingID=? LIMIT 1";
    // let BookingID_exits = await sqlhelper.select(BookingID_query, [request.BookingID], (err, res) => {
    //     if (err) {
    //         callback(json_response(err), null);
    //         return 0;
    //     } else if (res.length > 0) {
    //         callback(null, json_response({
    //             'status': '0',
    //             'message': 'This Booking  already exists on the platform; try a different one.'
    //         }));
    //         return 0;
    //     } else {
    //         return 1;
    //     }
    // });

    // if (BookingID_exits == 0) {
    //     return;
    // }
    if (request.Student_DetailID > 0) {
        update_data['UpdateDate'] = moment().format('YYYY-MM-DD HH:mm:ss');
        update_data['UpdateIP'] = request.IpAddress;

        Details['update_data']['EntryDate'] = moment().format('YYYY-MM-DD HH:mm:ss');
        Details['update_data']['EntryIP'] = request.IpAddress;

        let user_update = await sqlhelper.update(Details['table_name'], Details['update_data'], Details['where_data'], async (err, res) => {
            if (err) {
                console.log(err);
                callback(err, new Array());
                return 0;
            } else {
                response['message'] = "Document Successfully Updated";
                await sqlhelper.update('Accommodation_BookingRequest', { status: '2' }, { BookingID: request.BookingID }, (err, res) => {
                    if (err) console.log(err);
                });
                return res;
            }
        });
        if (user_update == 0) {
            return;
        }
    } else {
        Details['update_data']['EntryDate'] = moment().format('YYYY-MM-DD HH:mm:ss');
        Details['update_data']['EntryIP'] = request.IpAddress;
        let user_Insert = await sqlhelper.insert(Details['table_name'], Details['update_data'], async (err, res) => {
            if (err) {
                console.log(err);
                callback(json_response(err), null);
                return 0;
            } else {
                res = json_response(res);
                Student_DetailID = res.insertId;
                response['message'] = "Document Successfully Added";
                await sqlhelper.update('Accommodation_BookingRequest', { status: '2' }, { BookingID: request.BookingID }, (err, res) => {
                    if (err) console.log(err);
                });
                return res.insertId;
            }
        });
        if (user_Insert == 0) {
            return;
        }
    }
    callback(null, response);
};


User.AddPartner = async (request, callback) => {
    let emailid_query = "SELECT PersonalEmail FROM ChannelPartner WHERE PersonalEmail=? LIMIT 1";
    let emailid_exits = await sqlhelper.select(emailid_query, [request.Email], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (res.length > 0) {
            callback(null, json_response({
                'status': '0',
                'message': 'This Email Id already exists on the platform; try a different one.'
            }));
            return 0;
        } else {
            return 1;
        }
    });

    if (emailid_exits == 0) {
        return;
    }
    let partner_query = "SELECT CompanyName FROM ChannelPartner WHERE LOWER(CompanyName)= '" + request.CompanyName.toLowerCase() + "'  LIMIT 1";
    let partner_exits = await sqlhelper.select(partner_query, [], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (res.length > 0) {
            callback(null, json_response({
                'status': '0',
                'message': 'This Partner Name is already exists on the platform; try a different one.'
            }));
            return 0;
        } else {
            return 1;
        }
    });

    if (partner_exits == 0) {
        return;
    }
    let CountryName = (request.CountryName != undefined ? request.CountryName.trim() : '');
    let StateName = (request.StateName != undefined ? request.StateName.trim() : '');
    let CityName = (request.CityName != undefined ? request.CityName.trim() : '');

    let csc_where_array = [StateName, CityName, CountryName];
    let csc_query = 'SELECT cn.CountryID, IFNULL(st.StateID, 0) AS StateID, IFNULL(ct.CityID, 0) AS CityID FROM Mst_Country AS cn LEFT JOIN Mst_State AS st ON st.CountryID=cn.CountryID AND st.StateName=? LEFT JOIN Mst_City AS ct ON ct.StateID=st.StateID AND ct.CityName=? WHERE cn.CountryName=? LIMIT 1';
    if (CityName != '' && StateName == '') {
        csc_where_array = [CityName, CountryName];
        csc_query = 'SELECT cn.CountryID, IFNULL(st.StateID, 0) AS StateID, IFNULL(ct.CityID, 0) AS CityID FROM Mst_Country AS cn LEFT JOIN Mst_State AS st ON st.CountryID=cn.CountryID LEFT JOIN Mst_City AS ct ON ct.StateID=st.StateID AND ct.CityName=? WHERE cn.CountryName=? AND ct.CityID!="0" LIMIT 1';
    }

    let csc_data = await sqlhelper.select(csc_query, csc_where_array, (err, res) => {
        if (err || res.length <= 0) {
            return {
                'CountryID': '0',
                'StateID': '0',
                'CityID': '0'
            };
        } else {
            return res[0];
        }
    });

    let Data = {
        'Apistatus': '0',
        'message': 'This domain already exists on the platform; try a different one.'
    };
    let SubDomainName_query = "SELECT SubDomainName FROM ChannelPartner WHERE SubDomainName=? LIMIT 1";
    let SubDomainName_exits = await sqlhelper.select(SubDomainName_query, [request.SubDomainName], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (res.length > 0) {
            callback(null, json_response(Data));
            return 0;
        } else {
            return 1;
        }
    });
    if (SubDomainName_exits === 0) {
        return;
    } else {
        Data = await Common.CreateSubDomain(request.SubDomainName, 'CREATE');
    }
    if (Data['Apistatus'] == '0') {
        callback(null, json_response({
            'Apistatus': '0',
            'message': 'Domain name not valid; try a different one.'
        }));
        return;
    }

    let PhoneNoCode = ((request.PhoneNo_CountryCode != undefined && request.PhoneNo_CountryCode.trim() != '') ? request.PhoneNo_CountryCode + ' ' : '');
    var randomstring = Math.random().toString(36).slice(-8);

    let insert_data = {
        'FirstName': request.FirstName,
        'LastName': request.LastName,
        'CompanyName': request.CompanyName,
        'SubDomainName': request.SubDomainName,
        'RegisterOfficeAddress': request.Location ? request.Location : "",
        'CorrespondenceAddress': request.Location ? request.Location : "",
        'CountryID': csc_data.CountryID,
        'StateID': csc_data.StateID,
        'CityID': csc_data.CityID,
        'PersonalEmail': request.Email,
        'ContactPhoneNo': request.PhoneNo,
        'ContactPhoneNo_CountyCode': PhoneNoCode,
        'EntryDate': moment().format('YYYY-MM-DD HH:mm:ss'),
        'EntryIP': request.IpAddress,
        'PersonalPassword': md5(request.Password),
        'LoginID': request.Email
    };
    // return false;

    let ChannelPartnerID = await sqlhelper.insert('ChannelPartner', insert_data, (err, res) => {
        if (err) {
            console.log(err);
            return 0;
        } else {
            return res.insertId;
        }
    });

    if (ChannelPartnerID == 0) {
        return;
    }

    var response = {
        'status': '0',
        'message': 'Sorry, something went wrong; please check your internet connection or try again later.',
    };


    if (ChannelPartnerID > 0) {
        response['ChannelPartnerID'] = ChannelPartnerID;
        let ledger_data = {
            'UserID': ChannelPartnerID,
            'LedgerName': request.FirstName,
            'Mobile': request.PhoneNo,
            'Email': request.Email,
            'IsUser': '1',
            'Entrydate': moment().format('YYYY-MM-DD HH:mm:ss'),
            'UserType': 'Channel Partner'
        };
        let LedgerID = await sqlhelper.insert('Mst_Ledger', ledger_data, (err, res) => {
            if (err) {
                console.log(err);
                return 0;
            } else {
                return res.insertId;
            }
        });

        let update_data = {
            'LedgerID': LedgerID,
        }

        let where = {
            'ChannelPartnerID': ChannelPartnerID
        }
        await sqlhelper.update('ChannelPartner', update_data, where, (err, res) => {
            if (err) {
                return 0;
            } else if (res.affectedRows == 0) {
                return 0;
            } else {
                return 0;
            }
        });

        // sending email for Verification
        let Session = {
            // 'UserId': user_data['UserId'],
            'ChannelPartnerID': ChannelPartnerID,
            'ExpiredTime': moment().add(24, 'hours').format('YYYYMMDDHHmmss'),
        }

        Session = encodeURIComponent(Common.TokenEncrypt(JSON.stringify(Session)));
        let reset_pass_link = process.env.STUDENT_PANEL_LINK + 'email-verification?Session=' + Session;

        let user_name = request.FirstName + ' ' + request.LastName;
        let EmailData = await Common.GetEmailTemplate('Channel_Partner_Regestration');
        if (_.size(EmailData) > 0) {
            let body = EmailData['Body']
                .replace('{First Name}', user_name)
                .replace('{link}', reset_pass_link);

            let MailData = {
                'mail_to': request.Email,
                'subject': EmailData['Subject'],
                'body': body,
                //'cc_mail': EmailData['CCEmail'],
            };
            await Common.SendEmailSMTP(MailData);
        }

        response['status'] = '1';
        response['message'] = 'Registration completed successfully';
        console.log(response)
    }
    return callback(null, json_response(response));
}

User.AddTexiRequest = async (request, Details, callback) => {
    console.log(Details['update_data'])
    console.log(Details['where_data'])
    let update_data = {};
    var response = { 'status': '1', 'message': 'something is wrong.', 'data': {}, "IsUpdate": 0 };
    let ID = request.ID;
    if (request.ID > 0) {
        update_data['UpdateDate'] = moment().format('YYYY-MM-DD HH:mm:ss');
        update_data['UpdateIP'] = request.IpAddress;

        Details['update_data']['EntryDate'] = moment().format('YYYY-MM-DD HH:mm:ss');
        Details['update_data']['EntryIP'] = request.IpAddress;

        let user_update = await sqlhelper.update(Details['table_name'], Details['update_data'], Details['where_data'], async (err, res) => {
            if (err) {
                console.log(err);
                callback(err, new Array());
                return 0;
            } else {
                response['message'] = "Request Successfully Updated";
                response['IsUpdate'] = 1
                return res;
            }
        });
        if (user_update == 0) {
            return;
        }
    } else {
        let BookingID = await generateInquiryNo('2', "0");
        Details['update_data']['EntryDate'] = moment().format('YYYY-MM-DD HH:mm:ss');
        Details['update_data']['EntryIP'] = request.IpAddress;
        Details['update_data']['BookingID'] = BookingID;
        Details['update_data']['Paymessage'] = "Texi booking by " + request.pname + ".\nHaving Great pleasure to work with you.\nPlease pay and book your texi.";



        let user_Insert = await sqlhelper.insert(Details['table_name'], Details['update_data'], async (err, res) => {
            if (err) {
                console.log(err);
                callback(json_response(err), null);
                return 0;
            } else {
                res = json_response(res);
                ID = res.insertId;
                response['message'] = "Texi booking by " + request.pname + ".\nHaving Great pleasure to work with you.\nPlease pay and book your texi.";
                response["data"] = res.insertId;
                return res.insertId;
            }
        });
        if (user_Insert == 0) {
            return;
        }
    }
    callback(null, response);
};

User.UserActiveAndSetPassword = async (request, callback) => {
    // console.log(request)
    let user_query = 'SELECT CAST(StudentID AS CHAR) AS UserId, CONCAT(FirstName, " ", LastName) AS FullName, Email, CAST(Active AS CHAR) AS Active FROM Student WHERE Email=? LIMIT 1';
    let user_data = await sqlhelper.select(user_query, [request.UserName], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (_.isEmpty(res)) {
            callback(null, json_response({
                'status': '0',
                'message': 'The account does not exist, please check your username.'
            }));
            return 0;
        } else {
            return json_response(res[0]);
        }
    });
    // console.log(user_data)
    if (user_data == 0) {
        return;
    }

    if (user_data['Active'] == '1') {
        var response = {};
        response['message'] = 'Dear user, your account is already activated.';
        response['status'] = '1';
        callback(null, json_response(response));
        return;
    }

    // let Session = {
    //     'UserId': user_data['UserId'],
    //     'ExpiredTime': moment().add(24, 'hours').format('YYYYMMDDHHmmss'),
    // }
    // Session = encodeURIComponent(Common.TokenEncrypt(JSON.stringify(Session)));
    // let reset_pass_link = process.env.STUDENT_PANEL_LINK + 'set-password?Session=' + Session;
    // // console.log(reset_pass_link);

    // let EmailData = await Common.GetEmailTemplate('FrontEnd.EmailByCP');
    // if (_.size(EmailData) > 0) {
    //     let body = EmailData['Body']
    //         .replace('{First Name}', user_data['FullName'])
    //         .replace('{cpname}', request.CpName)
    //         .replace('{link}', reset_pass_link);

    //     let MailData = {
    //         'mail_to': user_data['Email'],
    //         'subject': EmailData['Subject'],
    //         'body': body,
    //         'cc_mail': EmailData['CCEmail'],
    //     };
    //     await Common.SendEmailSMTP(MailData);
    // }

    var response = {
        'message': 'Dear user, the link for resetting your password is sent to your registered email id. Do check your mail.',
        'status': '1',
    };

    callback(null, json_response(response));
    return;
}
User.AddCPLandingPageVisit = async (request, callback) => {
    let insert_data = {
        "ChannelpartnerID": request.ChannelpartnerID,
        "Page": 'Landing',
        "EntryDate": moment().format('YYYY-MM-DD HH:mm:ss'),
        "EntryIP": request.IpAddress
    }
    var response = {};
    let user_Insert = await sqlhelper.insert('TRN_CP_LandingPage_Traffic', insert_data, async (err, res) => {
        if (err) {
            console.log(err);
            callback(json_response(err), null);
            return 0;
        } else {
            res = json_response(res);
            ID = res.insertId;
            response['message'] = "Visit entry successfully";
            response["status"] = "1";
            return res.insertId;
        }
    });
    if (user_Insert == 0) {
        return;
    } else {
        callback(null, response);
    }
}
User.GetTexiDetail = async (request, callback) => {
    request.PageNo = (request.PageNo > 0 ? request.PageNo : '1');
    request.Limit = ((request.Limit > 0 && request.Limit <= 50) ? request.Limit : '20');
    let query = ` ` + request.Limit;
    let offset = (request.PageNo * request.Limit - request.Limit);
    let where = ' AND StudentID=? ';
    let where_array = [request.UserId];

    let si_query = 'select Trn_TaxiBooking.*,MS.Name as SProvider from Trn_TaxiBooking LEFT JOIN Mst_ServicesProvider as MS on MS.ServiceProviderID=Trn_TaxiBooking.SProviderID WHERE StudentID=?  ORDER BY EntryDate DESC LIMIT ' + offset + ', ' + request.Limit;
    var si_data = await sqlhelper.select(si_query, where_array, (err, res) => {
        if (err) {
            callback(err, null);
            return 0;
        } else if (_.isEmpty(res)) {
            callback(null, {
                'status': '0',
                'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
                'data': {}
            });
            return 0;
        } else {
            return json_response(res);
        }
    });
    let total_query = "select COUNT(StudentID) AS total from Trn_TaxiBooking WHERE StudentID=?"
    let total_record = await sqlhelper.select(total_query, where_array, (err, res) => {
        if (err || _.size(res) <= 0) {
            console.log(err);
            return 0;
        } else {
            return res[0]['total'];
        }
    });
    if (si_data == 0) {
        return;
    }
    var response = {
        'status': '0',
        'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
        'data': {},
    };
    if (si_data.length > 0) {
        response.status = '1';
        response.message = 'The Data Fetching process is completed successfully.';
        response.data = {
            'CurrentPage': request.PageNo,
            'TotalPage': Math.ceil(total_record / request.Limit).toString(),
            'TotalRecord': total_record.toString(),
            'List': si_data,
        };
    }
    callback(null, json_response(response));

}
User.UploadStudentCv = async (request, callback) => {

    request.PageNo = (request.PageNo > 0 ? request.PageNo : '1');
    request.Limit = ((request.Limit > 0 && request.Limit <= 50) ? request.Limit : '20');
    let query = ` ` + request.Limit;
    let offset = (request.PageNo * request.Limit - request.Limit);
    let insertdata = {
        StudentID: request.StudentID,
        Status: request.status,
        Message: request.message,
        ResumeId: request.ResumeId,
        EntryDate: moment().format('YYYY-MM-DD HH:mm:ss'),
        FilePath: ""
    }
    let user_query = "select StudentID from Student_CV_Detail where StudentID=?"
    let StudentID = await sqlhelper.select(user_query, [request.StudentID], (err, res) => {
        if (err) {
            callback(json_response(err), null);
            return 0;
        } else if (res[0] == undefined) {
            // callback(json_response(err), null);
            return 0;
        } else {
            return res[0].StudentID;
        }
    });
    if (StudentID == 0) {
        if (request.base64 != undefined && request.base64.trim() != '') {
            var ext = request.base64.substring(
                request.base64.indexOf(":") + 1,
                request.base64.lastIndexOf(";")
            );
            let file_array = {
                'base64_data': request.base64,
                'file_name': 'Mst_Services/' + uuidv4() + "." + request.ext + "x",
                'content_type': ext == "application/msword" ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document" : ext,
            }
            // console.log(JSON.stringify(file_array))
            let file_data = await Common.S3FileUpload(file_array);
            if (file_data['Location'] != undefined) {
                insertdata['FilePath'] = file_data['Location'];
                console.log(file_data['Location'])
            }
        }
        let user_data = await sqlhelper.insert('Student_CV_Detail', insertdata, async (err, res) => {
            if (err) {
                callback(json_response(err), null);
                return;
            } else {
                return res.insertId;
            }
        });
        if (user_data == 0) {
            return
        }
    }
    var response = {
        'status': '1',
        'message': '',
        'data': {},
    };
    callback(null, json_response(response));

}

exports.Offerget = (req, res) => {
    User.Offerget(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            console.log(error);
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            // console.log(data.data)
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data.data));
        }
    });
};

User.FoodPartnerPageData = async (request, callback) => {
    let Res = {
        'data':{},
        'Status':'0'
    };
    let date=moment().format('YYYY-MM-DD')
    let where = "";
    let where2 = ` AND (('`+date+`' BETWEEN DATE(pfo.OfferStartDate) AND DATE(pfo.OfferEndDate)) OR (DATE(pfo.OfferEndDate)='0000-00-00'))`;
    if(request.SearchId){
        where += ` AND (pfo.OfferTitle="${request.SearchId}" OR pfo.OfferDescription="${request.SearchId}"
        OR mc.CountryName="${request.SearchId}" OR mcity.CityName="${request.SearchId}")`;
    }
    where+= where2
    console.log(request)
    let Countquery = `select count(*) as count from (select 
    (select count(*) from Food_Provider_Offer as pfo 
    left join Mst_Country as mc on mc.CountryID = pfo.CountryID
    left join Mst_City as mcity on mcity.CityID = pfo.CityID
    where pfo.Food_Provider_Id = fp.Food_Provider_Id and pfo.Active='1' ${where} ) as TotalOffer 
    from Food_Provider as fp 
    where fp.Active = "1" Having TotalOffer > 0) as q`;
    // console.log(Countquery);
    let Total = await sqlhelper.select(Countquery, [], (err, res) => {
        if (err || _.size(res) <= 0) {
            if (err) console.log(err);
            return 0;
        } else {
            return json_response(res[0]['count']);
        }
    });
    // console.log(Total)

    request.PageNo = (request.PageNo > 0 ? request.PageNo : 1);
    let offset = (request.PageNo * request.Limit - request.Limit);
    let query = `select fp.Food_Provider_Id,Name,CompanyName,CompanyLogo,
    (select count(*) from Food_Provider_Offer as pfo 
    left join Mst_Country as mc on mc.CountryID = pfo.CountryID
    left join Mst_City as mcity on mcity.CityID = pfo.CityID
    where pfo.Food_Provider_Id = fp.Food_Provider_Id and pfo.Active='1' ${where} ) as TotalOffer 
    from Food_Provider as fp 
    where fp.Active = "1" Having TotalOffer > 0 Order By fp.OrderNo  LIMIT ${offset} , ${request.Limit}`;
    // console.log(query);

    let FoodProviderData = await sqlhelper.select(query, [], (err, res) => {
        if (err || _.size(res) <= 0) {
            if (err) console.log(err);
            return [];
        } else {
            Res['Status'] = '1';
            return json_response(res);
        }
    });
    // console.log(FoodProviderData);
    let Proquery = `select '0' as IsGetOffer,Offer_Id,pfo.Food_Provider_Id,OfferTitle,OfferDescription,OfferImage,Exclusive,OfferCode,
    (select Thumbnail  from Food_Provider as fp where fp.Food_Provider_Id= pfo.Food_Provider_Id ) as Thumbnail
    from Food_Provider_Offer as pfo
    where pfo.Active = "1" AND pfo.Exclusive = "1" ${where2}  Order By  OfferDisplayOrder`;
    
    let PopularOffers = await sqlhelper.select(Proquery, [], (err, res) => {
        if (err || _.size(res) <= 0) {
            if (err) console.log(err);
            return [];
        } else {
            Res['Status'] = '1';
            return json_response(res);
        }
    });

    
    // console.log(request);
    for (let index = 0; index < FoodProviderData.length; index++) {
        const element = FoodProviderData[index];
        let OfferQuery = `select IF(ISNULL(so.Offer_Id)=1,'0','1') as IsGetOffer,pfo.Offer_Id,pfo.Food_Provider_Id,OfferTitle,OfferDescription,OfferImage,Exclusive,pfo.OfferCode,
        (select CompanyLogo  from Food_Provider as fp where fp.Food_Provider_Id= pfo.Food_Provider_Id ) as Thumbnail
        from Food_Provider_Offer as pfo
        left join Mst_Country as mc on mc.CountryID = pfo.CountryID
        left join Mst_City as mcity on mcity.CityID = pfo.CityID
        left join Student_Offer as so on so.Offer_Id = pfo.Offer_Id and so.StudentID=?
        where pfo.Active = "1" ${where} AND pfo.Food_Provider_Id=?  Order By  OfferDisplayOrder`;
        console.log(OfferQuery)
        console.log(where)
        let OfferData = await sqlhelper.select(OfferQuery, [request.UserId,element.Food_Provider_Id], (err, res) => {
            if (err || _.size(res) <= 0) {
                if (err) console.log(err);
                return [];
            } else {
                Res['Status'] = '1';
                return json_response(res);
            }
        });
        FoodProviderData[index]['OfferDetails'] = OfferData;
        // FoodProviderData[index]['TotalOffer'] = OfferData.length;
    }
    // console.log(PopularOffers);
    Res['data']['FoodProviderData'] = FoodProviderData;
    Res['data']['PopularOffers'] = PopularOffers;
    Res['data']['CurrentPage'] = request.PageNo;
    Res['data']['TotalRecord'] = Total;
    console.log(Total);
    Res['data']['TotalPage'] =  Math.ceil(Total / request.Limit).toString();
    // console.log(Res);
    callback(null, Res);
}

User.Offerget = async (request, callback) => {
    let Checkuery = `select * from Student_Offer where Offer_Id=? AND StudentID=?`;
    let Data = await sqlhelper.select(Checkuery, [request.OfferID,request.UserID], (err, res) => {
        if (err || _.size(res) <= 0) {
            if (err) console.log(err);
            return -1;
        } else {
            return 1;
        }
    });
    console.log(Data);
    if(Data === -1){
        let insertdata = {
            StudentID: request.UserID,
            Offer_Id: request.OfferID,
            OfferCode : request.OfferCode,
            Food_Provider_Id : request.Food_Provider_Id,
            EntryDate: moment().format('YYYY-MM-DD HH:mm:ss'),
        }
        let user_data = await sqlhelper.insert('Student_Offer', insertdata, async (err, res) => {
            if (err) {
                callback(json_response(err), null);
                return -1;
            } else {
                return res.insertId;
            }
        });
        if (user_data === -1) {
            return
        }
    }
    var response = {
        'status': '1',
        'message': '',
        'data': {},
    };
    callback(null, json_response(response));
}

User.MyOffer = async (request, callback) => {
    request.PageNo = (request.PageNo > 0 ? request.PageNo : '1');
    request.Limit = ((request.Limit > 0 && request.Limit <= 50) ? request.Limit : '20');
    let offset = (request.PageNo * request.Limit - request.Limit);
    let where_array = [request.UserId];
    let response = {
        'status': '0',
        'message': 'Sorry, No Data founded. Make sure you have entered the right details.',
        'data': {
            'CurrentPage': 0,
            'TotalPage': 0,
            'TotalRecord': 0,
            'List': [],
        }
    }

    let si_query = `select ot.Offer_Id as OfferTrackID,fo.OfferImage,ot.StudentID,ot.Food_Provider_Id,fo.OfferCode,fp.Thumbnail as ProviderImage,fo.OfferTitle from Student_Offer as ot 
    left join Food_Provider_Offer as fo on fo.Offer_Id=ot.Offer_Id AND fo.Active=1
    left join Food_Provider as fp on fp.Food_Provider_Id=fo.Food_Provider_Id AND fp.Active=1
    ORDER BY ot.EntryDate DESC LIMIT ${offset} , ${request.Limit} `;
    var si_data = await sqlhelper.select(si_query, where_array, (err, res) => {
        if (err) {
            callback(err, null);
            return 0;
        } else if (_.isEmpty(res)) {
            callback(null, response);
            return 0;
        } else {
            return json_response(res);
        }
    });
    console.log(si_data)
    let total_query = "select COUNT(StudentID) AS total from Student_Offer WHERE StudentID=?"
    let total_record = await sqlhelper.select(total_query, where_array, (err, res) => {
        if (err || _.size(res) <= 0) {
            console.log(err);
            return 0;
        } else {
            return res[0]['total'];
        }
    });
    if (si_data == 0) {
        return;
    }
    
    if (si_data.length > 0) {
        response.status = '1';
        response.message = 'The Data Fetching process is completed successfully.';
        response.data = {
            'CurrentPage': request.PageNo,
            'TotalPage': Math.ceil(total_record / request.Limit).toString(),
            'TotalRecord': total_record.toString(),
            'List': si_data,
        };
    }
    // console.log(response);
    callback(null, json_response(response));

}

module.exports = User;