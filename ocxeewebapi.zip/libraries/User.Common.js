// default_token QhBEFUIcvbUWHHBsxsGjVQeLykaUphpMkoZkI0KTlM4=
require('dotenv').config();
const crypto = require('crypto');
const _ = require('lodash');
const moment = require('moment');
const AWS = require('aws-sdk');
const FCM = require('fcm-node');
const request = require('request');
const { v4: uuidv4 } = require('uuid');
const sqlhelper = require("../helpers/sqlhelper");
var Common = {};
const FileType = require('file-type');
global.ApiGlobalRequest = {};
const stripe = require('stripe')(process.env.StripeKey);


Common.GenerateNewToken = async (request) => {
    let HstID = uuidv4();
    let insert_log_data = {
        'HstID': HstID,
        'StudentID': request.UserId,
        'Source': request.Source,
        'AppVersion': request.AppVersion,
        'DeviceId': request.DeviceId,
        'DeviceToken': request.DeviceToken,
        'EntryIP': request.IpAddress,
        'LoginDate': moment().format('YYYY-MM-DD HH:mm:ss'),
    };

    await sqlhelper.insert('HST_Student_Login', insert_log_data, (err, res) => {
        if (err) {
            console.log(err);
        }
    });
    return Common.TokenEncrypt(HstID);
}

Common.TokenVerification = async (request) => {
    ApiGlobalRequest = request;
    let DEFAULT_TOKEN = process.env.DEFAULT_TOKEN;

    var allowedDefaultTokenService = [
        'UserLogin',
        'UserRegistration',
        'UserForgetPassword',
        'UserResetPassword',
        'GetMasterData',
        'GetStateList',
        'GetCityList',
        'GetAccommodationList',
        'GetAccommodationDetails',
        'GetCurrentLocationByIp',
        'GetServiceDetails',
        'GetServiceAutoCompleteList',
        'SubmitServiceEnquiry',
        'SubmitPartnerRequestEnquiry',
        'GetStaticPage',
        'SubmitTestimonial',
        'SubscribeUs',
        'ContactUs',
        'GetPopularPropertiesList',
        'GetPopularCityList',
        'GetHomeSliderList',
        'EmailSubscribe',
        'AddJoiningForm',
        'UpdatePayment',
        'UpdatePayment1',
        'GetPaymentDetails',
        'SearchPaymentDetails',
        'UserVerification',
        'SendUserOffer',
        'AddFeedback',
        'EmailUnSubscribe',
        'GetBlogList',
        'GetBlogCategory',
        'GetBlogCategoryCount',
        'GetRecentBlog',
        'GetBlogDetail',
        'GetBlogStaticData',
        'AddBlogToLike',
        'AddBlogToComment',
        'GetRecommList',
        'SetUserPassword',
        'GetSEOConetent',
        'GetAccommodationPageData',
        'GetAccList',
        'GetParameterID',
        'GetSEOConetentDetails',
        'GetServiceSeoContent',
        'UserBlogComment',
        'GetServiceList',
        'SubmitGeneralEnquiry',
        'Adslist',
        'AccAdslist',
        'GetCountryList',
        'AddAdsImpression',
        'GetavAilableTaxiData',
        'AddPartner',
        'CpartnerInfo',
        'GetStudentInfo',
        'CPVerification',
        'AddCPLandingPageVisit',
        'FoodPartnerPageData'
    ];

    var response = {};
    if (request.Token != undefined && request.Token != null && request.Token != '') {
        let Token = Common.TokenDecrypt(request.Token);
        var is_allowes = _.indexOf(allowedDefaultTokenService, request.ServiceName);
        if (is_allowes >= 0 && DEFAULT_TOKEN == Token) {
            response['token'] = request.Token;
            response['status'] = '1';
            response['message'] = 'Authentication success.';
        } else {
            let query = 'SELECT HstID, StudentID, LoginDate FROM HST_Student_Login WHERE HstID=? AND StudentID=?';
            let LogData = await sqlhelper.select(query, [Token, request.UserId], (err, res) => {
                if (err.sqlMessage != undefined || _.isEmpty(res)) {
                    return [];
                } else {
                    return res;
                }
            });

            if (LogData.length > 0) {
                let CurrentTime = moment().format('YYYYMMDDHHmmss');
                let ExpectedTime = moment(LogData[0]['LoginDate']).add(24, 'hours').format('YYYYMMDDHHmmss');
                if (CurrentTime <= ExpectedTime) {
                    response['status'] = '1';
                    response['token'] = request.Token;
                    response['message'] = 'Authentication success.';
                } else {
                    response['status'] = '2';
                    response['token'] = request.Token;
                    response['message'] = 'Session expired. try to login again.';
                }
            } else {
                response['status'] = '2';
                response['message'] = 'Authentication Fail.';
            }
        }
    } else {
        response['status'] = '2';
        response['message'] = 'Authentication Fail.';
    }

    return response;
}

Common.TokenEncrypt = (value) => {
    var IV_KEY = process.env.SECRET_KEY.substr(0, 16);
    var encryptor = crypto.createCipheriv(process.env.ENCRYPT_TYPE, process.env.SECRET_KEY, IV_KEY);
    return encryptor.update(value, 'utf8', 'base64') + encryptor.final('base64');
};

Common.TokenDecrypt = (value) => {
    try {
        var value = value.toString();

        var IV_KEY = process.env.SECRET_KEY.substr(0, 16);
        var decryptor = crypto.createDecipheriv(process.env.ENCRYPT_TYPE, process.env.SECRET_KEY, IV_KEY);
        var decrypt_string = decryptor.update(value, 'base64', 'utf8') + decryptor.final('utf8');
        return decrypt_string;
    } catch (error) {
        return 0;
    }
};

Common.S3FileUpload = async (file_array) => {
    const s3 = new AWS.S3({
        accessKeyId: process.env.S3_ACCESS_KEY,
        secretAccessKey: process.env.S3_SECRET_KEY
    });
    const base64_data = new Buffer.from(file_array['base64_data'].replace(file_array['base64_data'].split(",")[0], ""), 'base64');
    const mimeInfo = await FileType.fromBuffer(base64_data);
    // console.log(file_array['base64_data'].replace(file_array['base64_data'].split(",")[0], ""), 'base64')
    console.log(mimeInfo.ext)
    if (mimeInfo) file_array['file_name'] = 'Mst_Services/' + uuidv4() + '.' + mimeInfo.ext;
    else file_array['file_name'] = 'Mst_Services/' + uuidv4() + '.jpg';
    const params = {
        Bucket: process.env.S3_BUCKET_NAME,
        Key: file_array['file_name'], // full location of uploaded file
        Body: base64_data, // base64 of file data
        ContentEncoding: 'base64',
        ACL: 'public-read',
    };

    if (file_array['content_type'] != undefined && file_array['content_type'] != '') {
        params.ContentType = file_array['content_type'];
    }

    var response = {};
    try {
        // const resultData = await s3.upload(params).promise();
        response = await new Promise(resolve => {
            s3.upload(params, (error, data) => {
                if (error) {
                    console.log(error.code);
                    resolve({});
                } else {
                    resolve(data);
                }
            });
        });
    } catch (e) {
        console.log(e);
    }
    return response;
}

Common.S3FileDelete = async (file_location = '') => {
    const s3 = new AWS.S3({
        accessKeyId: process.env.S3_ACCESS_KEY,
        secretAccessKey: process.env.S3_SECRET_KEY
    });

    const params = {
        Bucket: process.env.S3_BUCKET_NAME,
        Key: file_location // full location of uploaded file
    };

    var response = { 'status': '0', 'message': 'Something is wrong', 'data': {} };
    try {
        var res = {};
        response = new Promise(resolve => {
            s3.deleteObject(params, async (error, data) => {
                if (error) {
                    res['status'] = '0';
                    res['error'] = error.code;
                    resolve(res);
                } else {
                    res['status'] = '1';
                    res['message'] = 'File remove successfully.';
                    res['data'] = data;
                    resolve(res);
                }
            });
        });
    } catch (e) {
        response.status = '0';
        response.error = e;
    }
    return response;
}

Common.SendNotification = async (nData, userType = '0') => {
    var fcm = new FCM(process.env.NOTIFICATION_SERVERKEY);
    var response = { 'status': '0', 'message': 'Something is wrong.', 'data': {} };

    var deviceToken = '';
    var nId = '0';
    if (userType == '1' && nData.userId != undefined && nData.userId > 0) {
        deviceToken_query = 'SELECT deviceToken FROM user_register WHERE userId="' + nData.userId + '" LIMIT 1';
        deviceToken = await sqlhelper.select(deviceToken_query, [], (err, res) => {
            if (_.isEmpty(res)) {
                return '';
            } else {
                return json_response(res[0].deviceToken);
            }
        });

        NotificationArray = {
            'nTypeId': nData.nTypeId,
            'userId': nData.userId,
            'nDescription': nData.description,
            'isRedirect': nData.isRedirect,
            'redirectScreen': nData.redirectScreen,
            'entrydate': moment().format('YYYY-MM-DD HH:mm:ss'),
        };

        if (nData.orderId != undefined && nData.orderId > 0) {
            NotificationArray.orderId = nData.orderId;
        }

        nId = await sqlhelper.insert('user_notificiation', NotificationArray, (err, res) => {
            if (err) return console.log(err);
            return res.insertId.toString();
        });
    } else if (userType == '2' && nData.userId != undefined && nData.userId > 0) {
        deviceToken_query = 'SELECT deviceToken FROM bwn_user WHERE bwnUId="' + nData.userId + '" LIMIT 1';
        deviceToken = await sqlhelper.select(deviceToken_query, [], (err, res) => {
            if (_.isEmpty(res)) {
                return '';
            } else {
                return json_response(res[0].deviceToken);
            }
        });

        NotificationArray = {
            'nTypeId': nData.nTypeId,
            'bwnUId': nData.userId,
            'nDescription': nData.description,
            'isRedirect': nData.isRedirect,
            'redirectScreen': nData.redirectScreen,
            'entrydate': moment().format('YYYY-MM-DD HH:mm:ss'),
        };

        nId = await sqlhelper.insert('bwn_notificiation', NotificationArray, (err, res) => {
            if (err) return console.log(err);
            return res.insertId.toString();
        });
    }

    if (deviceToken.length > 0) {
        var message = {
            to: deviceToken,
            data: {
                nId: nId,
                isRead: '0',
                title: nData.title,
                description: nData.description,
                imageurl: nData.image,
                isRedirect: nData.isRedirect,
                redirectValue: nData.redirectScreen,
                read: '0',
                notificationId: nId,
            },
            notification: {
                title: nData.title,
                text: nData.description,
                body: nData.description,
                // image : nData.image,
                image: '',
                badge: '1',
                sound: 'default',
            },
        };

        if (nData.orderId != undefined && nData.orderId > 0) {
            message.data.orderId = nData.orderId;
        }
        // console.log(message);

        response = await new Promise(resolve => {
            fcm.send(message, (err, res) => {
                res1 = {};
                if (err) {
                    res1.status = '0';
                    res1.message = 'notification generate error.';
                    res1.data = err;
                    resolve(res1);
                } else {
                    res1.status = '1';
                    res1.message = 'notification send successfully.';
                    res1.data = res;
                    resolve(res1);
                }
            });
        });
    }
    // console.log(response);
    return response;
}

/* 
example of send mail
---------------------------
MailData = { 'mail_to':'mauryadk212@gmail.com', 'body':'Hello', 'subject':'Test Mail', 'cc_mail':[] };
mData = await Common.SendEmail(MailData);
*/
Common.SendEmailSMTP = async (MailData = {}) => {
    const nodemailer = require('nodemailer');

    const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        secure: true,
        port: 465,
        auth: {
            user: process.env.GMAIL_ACCOUNT,
            pass: process.env.GMAIL_PASSWORD
        },
        tls: {
            rejectUnauthorized: false
        }
    });

    var mailOptions = {
        from: 'Ocxee Support <' + process.env.GMAIL_ACCOUNT + '>',
        to: MailData.mail_to,
        // to: 'vivekp.dnk@gmail.com',
        subject: MailData.subject,
        // text: '',
        html: MailData.body,
    };

    if (MailData.cc_mail != undefined && _.size(MailData.cc_mail) > 0) {
        mailOptions.cc = MailData.cc_mail.split(',');
    }

    var response = {};
    if (MailData.mail_to.length > 0) {
        if (process.env.IsMailSend == '1') {
            console.log("Mail Send")
            response = await new Promise(resolve => {
                transporter.sendMail(mailOptions, function (error, info) {
                    if (error) {
                        resolve(error);
                    } else {
                        resolve(info);
                    }
                });
            });
        }
    }
    // console.log(response);
    return response;
}

// call function ==> await Common.GetSettingValue('key_name');
Common.GetSettingValue = async (settingKey = '') => {
    setting_query = 'SELECT settingTitle, settingKey, settingValue FROM Mst_Setting WHERE settingKey=? AND Active="1" LIMIT 1';
    setting_data = await sqlhelper.select(setting_query, [settingKey], (err, res) => {
        if (err || _.isEmpty(res)) {
            return '';
        } else {
            return json_response(res[0]['settingValue']);
        }
    });

    return setting_data;
};

// call function ==> await Common.GetEmailTemplate('1');
Common.GetEmailTemplate = async (TemplateName = '0') => {
    let template_query = 'SELECT TemplateName, TemplateSubject AS Subject, TemplateBody AS Body, CCEmail FROM Mst_MessageTemplate WHERE TemplateName=? AND Active="1" LIMIT 1';
    let template_data = await sqlhelper.select(template_query, [TemplateName], (err, res) => {
        if (err || _.isEmpty(res)) {
            return {};
        } else {
            return json_response(res[0]);
        }
    });

    return template_data;
};

Common.GetIpToLocation = async (IpAddress = '') => {
    // http://ip-api.com/json/103.238.13.196?fields=status,message,continent,continentCode,country,countryCode,region,regionName,city,district,zip,lat,lon,timezone,offset,currency,isp,org,as,asname,reverse,mobile,proxy,hosting,query
    let url = 'http://www.geoplugin.net/json.gp';
    if (IpAddress.trim() != '') {
        url = 'http://www.geoplugin.net/json.gp?ip=' + IpAddress.trim();
        // url = 'https://ipapi.co/'+IpAddress+'/json';
    }

    let ip_data = await new Promise(resolve => {
        request.get(url, async function (error, res, body) {
            if (error) throw new Error(error);
            let body_data = JSON.parse(body);
            resolve(body_data);
        });
    });

    var response = {
        "IpAddress": ip_data.geoplugin_request,
        "City": (ip_data.geoplugin_city != null ? ip_data.geoplugin_city : ''),
        "State": (ip_data.geoplugin_region != null ? ip_data.geoplugin_region : ''),
        "StateCode": (ip_data.geoplugin_regionCode != null ? ip_data.geoplugin_regionCode : ''),
        "StateName": (ip_data.geoplugin_regionName != null ? ip_data.geoplugin_regionName : ''),
        "CountryCode": (ip_data.geoplugin_countryCode != null ? ip_data.geoplugin_countryCode : ''),
        "CountryName": (ip_data.geoplugin_countryName != null ? ip_data.geoplugin_countryName : ''),
        "Latitude": (ip_data.geoplugin_latitude != null ? ip_data.geoplugin_latitude : ''),
        "Longitude": (ip_data.geoplugin_longitude != null ? ip_data.geoplugin_longitude : ''),
        "CurrencyCode": (ip_data.geoplugin_currencyCode != null ? ip_data.geoplugin_currencyCode : ''),
        "CurrencySymbol": (ip_data.geoplugin_currencySymbol != null ? ip_data.geoplugin_currencySymbol : ''),
    };

    return response;
}

Common.GenerateAccSlug = async (AccName = '', CountryName = '', StateName = '', CityName = '', UniqueID = '', AccId = '') => {
    let AccSlug = '';
    if (AccName.trim() != '') {
        var acc_slug = [];
        if (CountryName != '') {
            acc_slug.push(CountryName.trim().toLowerCase().replace(/[^\w ]+/g, '').replace(/ +/g, '-'));
        } else {
            acc_slug.push('country');
        }

        if (CityName != '') {
            acc_slug.push(CityName.trim().toLowerCase().replace(/[^\w ]+/g, '').replace(/ +/g, '-'));
        } else if (StateName != '') {
            acc_slug.push(StateName.trim().toLowerCase().replace(/[^\w ]+/g, '').replace(/ +/g, '-'));
        } else {
            acc_slug.push('city');
        }

        acc_slug.push(AccName.trim().toLowerCase().replace(/[^\w ]+/g, '').replace(/ +/g, '-'));
        AccSlug = process.env.STUDENT_PANEL_LINK + 'student-accommodation/' + acc_slug.join('/') + '/' + UniqueID;
    }
    return AccSlug;
}

Common.ResFormat = (status = '0', alert_type = '0', message = '', token = '', data = {}) => {
    let encryptData = {
        'status': status,
        'alert': alert_type,
        'message': message,
        'token': token,
        'data': data,
    };
    console.log('version : ' + process.env.Version);
    if (process.env.Version != 'v1.0') {
        let encryptObj = Common.EncryptObject(encryptData);
        let resp = { QYUEIMSHNSGMDM: encryptObj };
        if (process.env.Islive === '0') {
            resp['Decrypt'] = encryptData;
            resp['RequestDecrypt'] = ApiGlobalRequest;
        }
        return resp;
    }
    return encryptData;
}

Common.BtrixCRMRequest = async (ReqData = {}, ServiceID = '0') => {
    // console.log(ReqData)
    let requestUrl = 'https://www.rizecrm.com/anciserv_api.php';

    let ExchangeServiceId = {
        '1': '2-466',       // Insurance
        '2': '3-478',       // Pickup and Drop
        '3': '4-474',       // Forex
        '4': '5-472',       // Travel Assistance
        '5': '6-476',       // SIM Card
        '6': '7-480',       // Money Transfer
        '8': '',            // Accommodation
        '9': '10-468',      // Visa Assistance
        '10': '12-470',     // Education Loan
        '11': '14-2054',    // Storage Service & Essentials
        '12': '15-2056',    // Short Term Courses & Internship
        '13': '17-486',     // Furniture Rentals
        '14': '22-5392',     // Job Assistant
        '15': '23-5394',     // Job Assistant
        '16': '24-5398',     // Financial Service
    };

    // Start Exchange value of InsuranceType (Insurance service)
    let NewInsuranceTypeId = 0;
    if (ReqData['ServiceTypeID'] == '1') {
        NewInsuranceTypeId = 496;
    } else if (ReqData['ServiceTypeID'] == '2') {
        NewInsuranceTypeId = 498;
    }
    // End Exchange value of InsuranceType (Insurance service)

    let ExchangeNoOfPerson = {
        // Exchange NoOfPerson (Accommodation service)
        '1-8': 56,
        '2-8': 58,
        '3-8': 60,
        '4-8': 62,
        '5-8': 64,
        '6-8': 66,
        '7-8': 68,
        '8-8': 70,
        '9-8': 72,
        '10-8': 74,
        '11-8': 2120,
        '12-8': 2122,
        '13-8': 2124,
        '14-8': 2126,
        // Exchange NoOfPerson (Travel assistance service)
        '1-4': 2156,
        '2-4': 2158,
        '3-4': 2160,
        '4-4': 2162,
        '5-4': 2164,
        '6-4': 2166,
        '7-4': 2166,
        '8-4': 2168,
        '9-4': 2168,
        '10-4': 2170,
    };

    let ExchangeMinNoOfRooms = {
        '0': 108,
        '1': 110,
        '2': 112,
        '3': 114,
        '4': 116,
        '5': 118,
        '6': 120,
        '7': 122,
        '8': 124,
        '9': 126,
    };

    let ExchangeMaxNoOfRooms = {
        '1': 368,
        '2': 370,
        '3': 372,
        '4': 374,
        '5': 376,
        '6': 378,
        '7': 380,
        '8': 382,
        '9': 384,
        '10': 386,
        '11': 386,
        '12': 1982,
        '13': 1982,
        '14': 1984,
        '15': 1986,
    };

    let ExchangeDuration = {
        '1': 84,
        '2': 86,
        '3': 88,
        '4': 90,
        // '5': 90,
        // '6': 92,
        // '7': 92,
        // Add on 16-04-21
        '5': 92,
        '6': 94,
        '7': 96,

        '8': 98,
        '9': 100,
        '10': 102,
        '11': 104,
        '12': 106,
        '13': 2068,
        '14': 2068,
        '15': 2068,
        '16': 2070,
        '17': 2072,
        '18': 2074,
        '19': 2074,
        '20': 2074,
        '21': 2074,
        '22': 2074,
        '23': 2074,
        '24': 2076,
        '25': 2076,
        '26': 2078,
        '27': 2078,
        '28': 2078,
        '29': 2078,
        '30': 2078,
        '31': 2078,
        '32': 2078,
        '33': 2078,
        '34': 2078,
        '35': 2078,
        '36': 2080,
        '37': 2080,
        '38': 2080,
        '39': 2080,
        '40': 2080,
        '41': 2080,
        '42': 2080,
        '43': 2080,
        '44': 2080,
        '45': 2080,
        '46': 2080,
        '47': 2080,
        '48': 2082,
        '49': 2082,
        '50': 2082,
        '51': 2082,
        '52': 2082,
        '53': 2082,
        '54': 2082,
        '55': 2082,
        '56': 2082,
        '57': 2082,
        '58': 2082,
        '59': 2082,
        '60': 2084,
    };

    let ExchangeDistance = {
        '0.5 Mile': 356,
        '1 Mile': 358,
        '5 Mile': 360,
        '10 Mile': 362,
        '15 Mile': 364,
        '20 Mile': 366,
    };

    let BtrixReqData = [];
    if (['1', '2', '3', '4', '5', '6', '9', '10', '11', '12', '13', '14', '15'].includes(ServiceID)) {
        let tmp_data = {
            "EnqRefNo": ReqData['InquiryNo'],
            "FirstName": ReqData['FirstName'],
            "LastName": ReqData['LastName'],
            "PhoneNo": ReqData['PhoneNo'],
            "PhoneCode": ReqData['PhoneNo_CountryCode'],
            "Email": ReqData['Email'],
            "ServiceId": ExchangeServiceId[ReqData['ServiceID']].split('-')[0],
            "ServiceName": ExchangeServiceId[ReqData['ServiceID']].split('-')[1],
            "STDCity": ReqData['CurrentCity'],
            "STDState": ReqData['CurrentState'],
            "STDCountry": ReqData['CurrentCountry'],
            "DSTCity": ReqData['DestinationCity'],
            "DSTState": ReqData['DestinationState'],
            "DSTCountry": ReqData['DestinationCountry'],
            "Remark": ReqData['Remark'],
            "Channel Partner": ReqData['PartnerName']
        };

        if (ServiceID == '1') {
            tmp_data['InsuranceTypeName'] = NewInsuranceTypeId;
        } else if (ServiceID == '2') {
            tmp_data['JourneyDate'] = moment(ReqData['JourneyDate'], "YYYY-MM-DD").format('MM/DD/YYYY');
        } else if (ServiceID == '4') {
            tmp_data['TravelDate'] = moment(ReqData['TravelDate'], "YYYY-MM-DD").format('MM/DD/YYYY');
            tmp_data['NumberOfPerson'] = (ExchangeNoOfPerson[ReqData['NoOfPerson'] + '-4'] != undefined ? ExchangeNoOfPerson[ReqData['NoOfPerson'] + '-4'] : 0);
        } else if (ServiceID == '5') {
            tmp_data['DepartureDate'] = moment(ReqData['DepatureDate'], "YYYY-MM-DD").format('MM/DD/YYYY');
        } else if (ServiceID == '10') {
            tmp_data['LoanAmount'] = ReqData['LoanAmount'] + '|' + ReqData['CurrencyCode'];
        }

        BtrixReqData.push(tmp_data);
    } else if (ServiceID == '8') {
        requestUrl = 'https://www.rizecrm.com/accenq_api.php';
        let AccLocation = [];
        try {
            AccLocation = JSON.parse(ReqData['AccLocation']);
        } catch (e) {
            AccLocation = [];
            console.log(e);
        }

        if (AccLocation.length > 0) {
            // let cm_query = 'SELECT CountryID, CountryName, CurrencyCode FROM Mst_Country';
            // let cm_data = await sqlhelper.select(cm_query, [], (err, res) => {
            //     if (err) {
            //         console.log(err);
            //         return [];
            //     } else {
            //         return res;
            //     }
            // });

            for (let i = 0; i < AccLocation.length; i++) {
                let CurrencyCode = '|' + ReqData['CurrencyCode'];
                // let CurrencyCode = '';
                // let cfi = _.findIndex(cm_data, { 'CountryName': AccLocation[i]['Country'] });
                // if (AccLocation[i]['Country']!='' && cfi>=0) {
                //     CurrencyCode = '|'+cm_data[cfi]['CurrencyCode'];
                // }

                BtrixReqData.push({
                    "EnqRefNo": ReqData['InquiryNo'],
                    "Email": ReqData['Email'],
                    "Phone": ReqData['PhoneNo_CountryCode'] + ReqData['PhoneNo'],
                    "STDCountry": ReqData['CurrentCountry'],
                    "STDCity": (ReqData['CurrentCity'] != '' ? ReqData['CurrentCity'] : ReqData['CurrentState']),
                    "FirstName": ReqData['FirstName'] + ' ' + ReqData['LastName'],
                    "PropertyType": ReqData['PropertyType'],
                    "University": ReqData['UniversityName'],
                    "MinPriceRange": ReqData['MinPrice'] + CurrencyCode,
                    "MaxPriceRange": ReqData['MaxPrice'] + CurrencyCode,
                    "MinNoofRooms": (ExchangeMinNoOfRooms[ReqData['MinNoOfRooms']] != undefined ? ExchangeMinNoOfRooms[ReqData['MinNoOfRooms']] : 0),
                    "MaxNoofRooms": (ExchangeMaxNoOfRooms[ReqData['MaxNoOfRooms']] != undefined ? ExchangeMaxNoOfRooms[ReqData['MaxNoOfRooms']] : 0),
                    "Duration": (ExchangeDuration[ReqData['DurationInMonth']] != undefined ? ExchangeDuration[ReqData['DurationInMonth']] : 0),
                    "MoveInDate": moment(ReqData['MoveInDate'], "YYYY-MM-DD").format('MM/DD/YYYY'),
                    "Location": (AccLocation[i]['Location'] != undefined ? AccLocation[i]['Location'] : ''),
                    "Country": (AccLocation[i]['Country'] != undefined ? AccLocation[i]['Country'] : ''),
                    "City": (AccLocation[i]['City'] != undefined ? AccLocation[i]['City'] : ''),
                    "Remark": ReqData['Remark'],
                    "Distance": (AccLocation[i]['Distance'] != '' ? (ExchangeDistance[AccLocation[i]['Distance']] != undefined ? ExchangeDistance[AccLocation[i]['Distance']] : 0) : 0),
                    "CreatedDate": moment().format('MM/DD/YYYY'),
                    "NoOfPerson": (ExchangeNoOfPerson[ReqData['NoOfPerson'] + '-8'] != undefined ? ExchangeNoOfPerson[ReqData['NoOfPerson'] + '-8'] : 0),
                    "Channel Partner": ReqData['PartnerName']
                });
            }
        }
    }
    console.log(BtrixReqData);
    let response;
    if (BtrixReqData.length > 0) {
        // var request = require('request');
        // require('request').defaults({ rejectUnauthorized: false })
        var options = {
            strictSSL: false,
            // secureProtocol: 'TLSv1_method',
            method: 'POST',
            url: requestUrl,
            body: JSON.stringify(BtrixReqData),
            rejectUnauthorized: false
        };
        // console.log("===================");
        // console.log(BtrixReqData);
        if (process.env.IsBtrixCRMRequest == '1') {
            response = await new Promise(resolve => {
                request(options, function (error, body, resp) {
                    if (error) {
                        console.log("Btrix Api is not working :( ");
                        resolve(-1);//throw new Error(error);
                    } else {
                        console.log("Success Btrix response ================> ");
                        console.log(body.body);
                        // console.log("resp ================> ");
                        // console.log(resp);
                        resolve(resp);
                    }
                });
            });
        }
    }
    return response;
}

// Parth Added
Common.GetStudentDeatils = async (StuentID = 0) => {
    let student_query = 'SELECT CONCAT(FirstName," ",LastName) as FullName,Email,CONCAT(PhoneNo_CountryCode," ",PhoneNo) as MobilNumber,FormProgress FROM Student where StudentID=? LIMIT 1';
    let student_data = await sqlhelper.select(student_query, [StuentID], (err, res) => {
        if (err || _.isEmpty(res)) {
            return {};
        } else {
            return json_response(res[0]);
        }
    });
    return student_data;
};

Common.AddGenralStudent = async (StuentData = {}, CpName = "") => {

    let emailid_query = "SELECT StudentID FROM Student WHERE Email=? LIMIT 1";
    let emailid_exits = await sqlhelper.select(emailid_query, [StuentData['Email']], (err, res) => {
        if (err) {
            return 0;
        } else if (res.length > 0) {
            return res[0]['StudentID'];
        } else {
            return 0;
        }
    });

    if (emailid_exits != 0) {
        return emailid_exits;
    }

    let user_data = await sqlhelper.insert('Student', StuentData, (err, res) => {
        if (err) {
            return 0;
        } else {
            res = json_response(res);
            return res.insertId
        }
    });

    if (user_data == 0) {
        return 0;
    }

    console.log(StuentData)

    let user_name = StuentData.FirstName + ' ' + StuentData.LastName;
    if (StuentData["ChannelPartnerID"] != undefined && StuentData["ChannelPartnerID"] != 0 && StuentData["ChannelPartnerID"]) {
        let Session = {
            'UserId': user_data,
            'ExpiredTime': moment().add(24, 'hours').format('YYYYMMDDHHmmss'),
        }
        Session = encodeURIComponent(Common.TokenEncrypt(JSON.stringify(Session)));
        let reset_pass_link = process.env.STUDENT_PANEL_LINK + 'set-password?Session=' + Session;
        let EmailData = await Common.GetEmailTemplate('FrontEnd.EmailByCP');
        if (_.size(EmailData) > 0) {
            let body = EmailData['Body']
                .replace('{First Name}', user_name)
                .replace('{cpname}', CpName)
                .replace('{link}', reset_pass_link);

            let MailData = {
                'mail_to': StuentData['Email'],
                'subject': EmailData['Subject'],
                'body': body,
                'cc_mail': EmailData['CCEmail'],
            };
            await Common.SendEmailSMTP(MailData);
        }
    } else {
        let Session = {
            'UserId': user_data,
            'ExpiredTime': moment().add(24, 'hours').format('YYYYMMDDHHmmss'),
        }
        Session = encodeURIComponent(Common.TokenEncrypt(JSON.stringify(Session)));
        let reset_pass_link = process.env.STUDENT_PANEL_LINK + 'set-password?Session=' + Session;
        let EmailData = await Common.GetEmailTemplate('FrontEnd.SetPassword');
        if (_.size(EmailData) > 0) {
            let body = EmailData['Body']
                .replace('{First Name}', user_name)
                .replace('{link}', reset_pass_link);

            let MailData = {
                'mail_to': StuentData['Email'],
                'subject': EmailData['Subject'],
                'body': body,
                //'cc_mail': EmailData['CCEmail'],
            };
            await Common.SendEmailSMTP(MailData);
        }
    }

    return user_data
};

Common.GetAccDeatils = async (AccommodationID = 0) => {
    let Acc_query = 'SELECT acc.UniqueID,acc.AltAccommodationName as AccommodationName, CONCAT(acc.AddressLine1,IF(acc.AddressLine2!="",CONCAT(",",acc.AddressLine2), "")) as Location, IFNULL(cm.CountryName,"") AS CountryName, IFNULL(sm.StateName,"") AS StateName, IFNULL(ct.CityName,"") AS CityName FROM Accommodation as acc INNER JOIN Mst_Country AS cm ON cm.CountryID=acc.CountryID INNER JOIN Mst_State AS sm ON sm.StateID=acc.StateID INNER JOIN Mst_City AS ct ON ct.CityID=acc.CityID WHERE AccommodationID=? LIMIT 1';
    let Acc_data = await sqlhelper.select(Acc_query, [AccommodationID], (err, res) => {
        if (err || _.isEmpty(res)) {
            return 0;
        } else {
            return json_response(res[0]);
        }
    });

    let AccData = Acc_data;

    if (Acc_data != 0) {
        AccData['AccSlug'] = await Common.GenerateAccSlug(Acc_data['AccommodationName'], Acc_data['CountryName'], Acc_data['StateName'], Acc_data['CityName'], Acc_data['UniqueID']);
        return AccData;
    }
    else {
        AccData['AccSlug'] = process.env.STUDENT_PANEL_LINK;
        return AccData;
    }

};

Common.BtrixCRMRequest1 = async (BtrixReqData = {}) => {

    let requestUrl = 'https://rizecrm.com/ocxee/websiteEnq.php';

    // var request = require('request');
    // require('request').defaults({ rejectUnauthorized: false })
    var options = {
        strictSSL: false,
        // secureProtocol: 'TLSv1_method',
        method: 'POST',
        url: requestUrl,
        body: JSON.stringify(BtrixReqData),
        rejectUnauthorized: false
    };

    // console.log(BtrixReqData);
    let response;
    if (process.env.IsBtrixCRMRequest == '1') {
        response = await new Promise(resolve => {
            request(options, function (error, body, resp) {
                if (error) throw new Error(error);
                console.log("Btrix response ================> ");
                console.log(body.body);
                // console.log("resp ================> ");
                // console.log(resp);
                resolve(resp);
            });
        });
    }
    return response;
}

json_response = (data) => {
    return JSON.parse(JSON.stringify(data));
}

Common.EncryptObject = (Object) => {
    var value = JSON.stringify(Object);
    var IV_KEY = process.env.DATA_SECRET_KEY.substr(0, 16);
    var encryptor = crypto.createCipheriv(process.env.ENCRYPT_TYPE, process.env.DATA_SECRET_KEY, IV_KEY);
    return encryptor.update(value, 'utf8', 'base64') + encryptor.final('base64');
}

Common.DecryptObject = (EncryptObject) => {
    try {
        var value = EncryptObject.toString();
        var IV_KEY = process.env.DATA_SECRET_KEY.substr(0, 16);
        var decryptor = crypto.createDecipheriv(process.env.ENCRYPT_TYPE, process.env.DATA_SECRET_KEY, IV_KEY);
        var decrypt_string = decryptor.update(value, 'base64', 'utf8') + decryptor.final('utf8');
        return JSON.parse(decrypt_string);
    } catch (error) {
        return 0;
    }
}

Common.StripePaymentRetrieve = async (transaction_id) => {

    let response = {};
    if (transaction_id) {
        try {
            response = await new Promise(async resolve => {
                // console.log(transaction_id)
                // console.log(await stripe.paymentIntents.retrieve(transaction_id))
                const intent = await stripe.paymentIntents.retrieve(transaction_id);
                // console.log(intent.charges.data[0]);
                const update_data = {};
                // await console.log( intent.charges.data[0]);
                try {
                    update_data.PaymentDate = moment(intent.charges.data[0].created * 1000).format('YYYY-MM-DD HH:mm:ss');
                } catch (e) {
                }
                if (intent.status == 'succeeded') {
                    update_data.PayStatus = '1';
                    if (intent.charges.data[0].receipt_url)
                        update_data.ReceiptUrl = intent.charges.data[0].receipt_url;
                    if (intent.charges.data[0].currency && intent.charges.data[0].amount)
                        update_data.PayAmount = intent.charges.data[0].currency + ' ' + intent.charges.data[0].amount / 100;
                } else if (intent.status == 'requires_payment_method') {
                    update_data.PayStatus = '3';
                    update_data.Message = 'Fails due to card error';
                } else if (intent.status == 'requires_action') {
                    update_data.PayStatus = '3';
                    update_data.Message = 'Fails due to authentication';
                } else {
                    resolve(0);
                }
                resolve(update_data);
            });
        } catch (error) {
            console.log(error);
        }
    }

    return response;
}

Common.SendPaymentSuccessMail = async (Obj) => {
    response = await new Promise(async resolve => {
        let query = 'select FirstName,MiddleName,LastName,Email from Student where StudentID = ?';
        let data = await sqlhelper.select(query, [Obj.StudentID || 0], (err, res) => {
            if (err || res.length <= 0) {
                return -1;
            } else {
                return json_response(res[0]);
            }
        });
        if (data != -1) {
            let HtmlBody = `<!DOCTYPE html>
            <html lang="en">
            
            <head>
                <title>Email</title>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <link rel="preconnect" href="https://fonts.googleapis.com">
                <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
            </head>
            
            <body style="font-family: 'Open Sans';">
                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="width: 600px;margin:0 auto;background: #fff;">
                    <tbody>
                        <tr>
                            <td style="width: 100%;">
                                <table cellspacing="0" cellpadding="0" border="0" style="width:100%;margin: 0 auto;padding: 15px 30px 0px;background: #fff;">
                                    <tr>
                                        <td>
                                            <table cellspacing="0" cellpadding="0" border="0" style="width: 100%;padding: 0px;">
                                                <tbody>
                                                    <tr>
                                                        <td align="center" valign="top" style="padding-bottom: 0px;text-align: left;">
                                                            <a href="#" style="display: inline-block;">
                                                                <img style="width: 110px" src="https://www.ocxee.com/assets/images/ocxee-logo.svg" alt="">
                                                            </a>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                        <td>
                                            <table cellspacing="0" cellpadding="0" border="0" style="width: 100%; padding: 0px;text-align: right;">
                                                <tbody>
                                                    <tr>
                                                        <td align="center" valign="top" style="padding-bottom: 0px;text-align: right;padding-top: 10px;">
                                                            <h1 style="font-weight: 700;margin: 0 0 5px;padding: 0;color: #07528d;font-size: 14px;
                                                       line-height: 14px;">OCXEE Limited</h1>
                                                            <p style="font-weight: 400;margin: 0 0 8px;padding: 0;color: #111111;font-size: 12px;
                                                       line-height: 20px;color:#454545;"><strong style="font-weight: 700;font-size: 12px;color:#101010;">Reg.Office:</strong> St Magnus House, <br> 3 Lower Thames Street London Bridge, London, EC3R 6HE</p>
                                                            <p style="font-weight: 400;margin: 0 0 5px;padding: 0;color: #111111;font-size: 12px;
                                                       line-height: 16px;color:#454545;"><strong style="font-weight: 700;font-size: 12px;color:#101010;">Website:</strong><a style="color: #111111;text-decoration: none;" href="https://www.ocxee.com/" target="_black"> www.ocxee.com</a></p>
                                                            <p style="font-weight: 400;margin: 0 0 5px;padding: 0;color: #111111;font-size:12px;
                                                       line-height: 16px;color:#454545;"><strong style="font-weight: 700;font-size: 12px;color:#101010;">Email:</strong><a style="color: #111111;text-decoration: none;" href="mailto:info@gmail.com"> info@gmail.com</a></p>
                                                            <p style="font-weight: 400;margin: 0 0 5px;padding: 0;color: #111111;font-size: 12px;
                                                       line-height: 16px;color:#454545;"><strong style="font-weight: 700;font-size: 12px;color:#101010;">Phone:</strong><a style="color: #111111;text-decoration: none;" href="tel:+44 7450 488 811"> +44 7450 488 811</a></p>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td style="padding:20px 0px;">
                                <p style="border: 1px solid #44444417; margin: 0px;">
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <table cellspacing="0" cellpadding="0" border="0" style="width:100%;margin: 0 auto;padding: 15px 30px 0px;background: #fff;">
                                    <tbody>
                                        <tr>
                                            <td align="center" style="border: 0;margin: 0;padding: 0;font-family: 'Open Sans', sans-serif;font-size: 24px;line-height: 32px;">
                                                Receipt from OCXEE LTD
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <table cellspacing="0" cellpadding="0" border="0" style="width:100%;margin: 0 auto;padding: 15px 30px 0px;background: #fff;">
                                    <tbody>
                                        <tr>
                                            <td colspan="3" height="12" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; mso-line-height-rule: exactly;">
                                                <div>&nbsp;</div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <table cellspacing="0" cellpadding="0" border="0" style="width:100%;margin: 0 auto;padding: 30px;background: #fff;">
                                    <tbody>
                                        <tr>
                                            <td valign="top" style="border: 0;margin: 0;padding: 0;">
                                                <table cellspacing="0" cellpadding="0" border="0" style="width:100%;margin: 0 auto;text-align: left;">
                                                    <tbody>
                                                        <tr>
                                                            <td style="border: 0;margin: 0;padding: 0;font-family: 'Open Sans', sans-serif;vertical-align: middle;color: #8898aa;font-size: 12px;line-height: 16px;font-weight: 700;text-transform: uppercase;">
                                                                Amount paid
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="border: 0;margin: 0;padding: 0;font-family: 'Open Sans', sans-serif;vertical-align: middle;color: #525f7f;font-size: 15px;line-height: 24px;">
                                                            {PayAmount}
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                            <td valign="top" style="border: 0;margin: 0;padding: 0;">
                                                <table cellspacing="0" cellpadding="0" border="0" style="width:100%;margin: 0 auto;text-align: right;">
                                                    <tbody>
                                                        <tr>
                                                            <td style="border: 0;margin: 0;padding: 0;font-family: 'Open Sans', sans-serif;vertical-align: middle;color: #8898aa;font-size: 12px;line-height: 16px;font-weight: 700;text-transform: uppercase;">
                                                                Date paid
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="border: 0;margin: 0;padding: 0;font-family: 'Open Sans', sans-serif;vertical-align: middle;color: #525f7f;font-size: 15px;line-height: 24px;">
            
                                                                {PaymentDate}
            
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <table cellspacing="0" cellpadding="0" border="0" style="width:100%;margin: 0 auto;padding: 15px 30px 0px;background: #fff;">
                                    <tbody>
                                        <tr>
                                            <td style="border: 0; margin: 0; padding: 0; color: #8898aa; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Ubuntu, sans-serif; font-size: 12px; line-height: 16px; text-transform: uppercase;">
                                                <span style="border: 0; margin: 0; padding: 0; font-weight: 700;">
                                                    Summary
                                                </span>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <table cellspacing="0" cellpadding="0" border="0" style="width:100%;margin: 0 auto;padding: 15px 30px 60px;background: #fff;">
                                    <tbody>
                                        <tr>
                                            <td colspan="3" height="4" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; mso-line-height-rule: exactly;">
                                                <div>&nbsp;</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="border: 0; margin: 0; padding: 0;">
                                                <table bgcolor="f6f9fc" border="0" cellpadding="0" cellspacing="0" style="border-radius: 5px;" width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td style="border: 0; margin: 0; padding: 0;">
                                                                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td colspan="3" height="12" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; mso-line-height-rule: exactly;">
                                                                                <div>&nbsp;</div>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; mso-line-height-rule: exactly;" width="16">
                                                                                <div>&nbsp;</div>
                                                                            </td>
                                                                            <td style="border: 0; margin: 0; padding: 0; color: #525F7f; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Ubuntu, sans-serif; font-size: 16px; line-height: 24px;">
                                                                                <table style="padding-left: 5px; padding-right:5px;" width="100%">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td>
            
            
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td style="border: 0;margin: 0;padding: 0;font-family: 'Open Sans', sans-serif;vertical-align: middle;color: #525f7f;font-size: 15px;line-height: 24px; width: 100%; ">
                                                                                                {BookingNo} 
                                                                                            </td>
                                                                                            <td width="8" style="border: 0;margin: 0;padding: 0;color: #ffffff;font-size: 1px;line-height: 1px;mso-line-height-rule: exactly;">&nbsp;</td>
                                                                                            <td align="right" valign="top" style="border: 0;margin: 0;padding: 0;font-family: 'Open Sans', sans-serif;vertical-align: middle;color: #525f7f;font-size: 15px;line-height: 24px;">
                                                                                                {PayAmount}
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td colspan="3" height="6" style="border: 0;margin: 0;padding: 0;color: #ffffff;font-size: 1px;line-height: 1px;mso-line-height-rule: exactly;">&nbsp;</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td colspan="3" height="6" style="border: 0;margin: 0;padding: 0;color: #ffffff;font-size: 1px;line-height: 1px;mso-line-height-rule: exactly;">&nbsp;</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td bgcolor="e6ebf1" colspan="3" height="1" style="border: 0;margin: 0;padding: 0;color: #ffffff;font-size: 1px;line-height: 1px;mso-line-height-rule: exactly;">&nbsp;</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td colspan="3" height="8" style="border: 0;margin: 0;padding: 0;color: #ffffff;font-size: 1px;line-height: 1px;mso-line-height-rule: exactly;">&nbsp;</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td style="border: 0;margin: 0;padding: 0;font-family: 'Open Sans', sans-serif;vertical-align: middle;color: #525f7f;font-size: 15px;line-height: 24px; width: 100%; ">
                                                                                                <strong>Amount charged</strong>
                                                                                            </td>
                                                                                            <td width="8" style="border: 0;margin: 0;padding: 0;color: #ffffff;font-size: 1px;line-height: 1px;mso-line-height-rule: exactly;">&nbsp;</td>
                                                                                            <td align="right" valign="top" style="border: 0;margin: 0;padding: 0;font-family: 'Open Sans', sans-serif;vertical-align: middle;color: #525f7f;font-size: 15px;line-height: 24px;">
                                                                                                <strong>{PayAmount}</strong>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td colspan="3" height="6" style="border: 0;margin: 0;padding: 0;color: #ffffff;font-size: 1px;line-height: 1px;mso-line-height-rule: exactly;">&nbsp;</td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </td>
                                                                            <td style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; mso-line-height-rule: exactly;" width="16">
                                                                                <div>&nbsp;</div>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td colspan="3" height="12" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; mso-line-height-rule: exactly;">
                                                                                <div>&nbsp;</div>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>
            
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </body>
            
            </html>`

            try {
                HtmlBody = HtmlBody.split('{PayAmount}').join(Obj.PayAmount);
                HtmlBody = HtmlBody.replace('{BookingNo}', Obj.InvoiceDes)
                    .replace('{PaymentDate}', moment(Obj.PaymentDate).format('YYYY-MM-DD HH:mm:ss'))
                let MailData = {
                    mail_to: data.Email,
                    subject: "Successfull Payment",
                    body: HtmlBody
                }
                await Common.SendEmailSMTP(MailData);
                resolve('1');
            } catch (error) {
                console.log(error);
                resolve('0');
            }
        } else {
            resolve('0');
        }
    });
    return response;
}

Common.Ac_Wallet_Transaction_Entry = async (user_data) => {
    try {
        if (parseInt(user_data.LedgerID) > 0 && user_data.OrderID > 0) {
            let LedgerEntry = {
                'OrderID': user_data.OrderID,
                'OrderTypeID': '1',
                'EntryDate': moment().format('YYYY-MM-DD'),
                'EntryDateTime': moment().format('YYYY-MM-DD HH:mm:ss'),
                'narretion': user_data.narretion
            }
            LedgerEntry['LedgerID'] = user_data.LedgerID;
            LedgerEntry['RefLedgerID'] = '1';
            LedgerEntry['Debitamount'] = '0';
            LedgerEntry['CreditAmount'] = user_data.Amount;
            LedgerEntry['Balance'] = 0;
            await sqlhelper.insert('Ac_Wallet_Transaction', LedgerEntry, (err, res) => {
                if (err) {
                    console.log(err);
                } else {
                    console.log("Wallet First Trasection success " + res.insertId);
                    return res.insertId;
                }
            });
            // Reverse Entry
            LedgerEntry['LedgerID'] = '1';
            LedgerEntry['RefLedgerID'] = user_data.LedgerID;
            LedgerEntry['Debitamount'] = user_data.Amount;
            LedgerEntry['CreditAmount'] = '0';
            LedgerEntry['Balance'] = 0;
            await sqlhelper.insert('Ac_Wallet_Transaction', LedgerEntry, (err, res) => {
                if (err) {
                    console.log(err);
                } else {
                    console.log("Wallet Revese Trasection success " + res.insertId);
                    return res.insertId;
                }
            });
            // let OcxeeFinalBalance = await Common.BalanceCalculation('1');
            // console.log("Ocxee Final Balance "+ OcxeeFinalBalance);
            try {
                var ActivityArray = {
                    StudentID: '0',
                    ChannelPartnerID: user_data.LedgerID,
                    Message: "Commssion Credit for " + user_data.narretion,
                    Process: 'CommissionGet'
                }
                await Commom.SaveNotificationLog(ActivityArray, request);
            } catch (error) {
                console.log("Notification not inert -----");
            }
            return 1;
        } else {
            return 0;
        }
    } catch (error) {
        console.log(error);
        return 0;
    }
};

Common.GetLedgerID = async (ID, type = '1') => {
    /*  ChannelPartner = '1'
    *  Student = '2' */
    let TableName = 'ChannelPartner';
    let where = 'AND ChannelPartnerID=?';
    let query = `SELECT LedgerID FROM ` + TableName + ` WHERE Active="1" ` + where + ` LIMIT 1`;
    let data = await sqlhelper.select(query, [ID], (err, res) => {
        if (err || _.isEmpty(res)) {
            return {};
        } else {
            return json_response(res[0].LedgerID);
        }
    });
    return data;
};

Common.BalanceCalculation = async (ledgerID) => {
    var v_counter = 0;
    var lastBalance = 0;
    var CountLeftEntries = 0;
    if (ledgerID) {
        let lastBalance_query = 'SELECT Balance FROM Ac_Wallet_Transaction WHERE LedgerID=? order by FasID desc LIMIT 1';
        lastEntryBalance = await sqlhelper.select(lastBalance_query, [ledgerID], (err, res) => {
            if (err) {
                return 0;
            } else if (_.isEmpty(res)) {
                return 0;
            } else {
                return res[0]['Balance'];
            }
        });

        if (lastEntryBalance > 0) {
            return lastEntryBalance;
        }

        fs_query = 'SELECT round((IfNUll(CreditAmount,0)-IFnull(Debitamount,0)),2) as amount,FasId FROM Ac_Wallet_Transaction WHERE LedgerID=? AND Balance="" ';
        CountLeftEntries = await sqlhelper.select(fs_query, [ledgerID], (err, res) => {
            if (err) {
                console.log(err);
                return 0;
            } else if (_.isEmpty(res)) {
                return 0;
            } else {
                return res;
            }
        });

        lastBalance_query = 'SELECT Balance FROM Ac_Wallet_Transaction WHERE LedgerID=? AND Balance!="" order by FasId desc limit 1';
        lastBalance = await sqlhelper.select(lastBalance_query, [ledgerID], (err, res) => {
            if (err) {
                console.log(err);
                return 0;
            } else if (_.isEmpty(res)) {
                return 0;
            } else {
                return res[0]['Balance'];
            }
        });

        let counter = _.size(CountLeftEntries);
        let i = 0;
        if (counter > 0) {
            // CountLeftEntries.forEach(async function (data) {
            //     lastBalance = parseFloat(lastBalance) + parseFloat(data.amount);
            //     await sqlhelper.update('Ac_Wallet_Transaction', {'Balance':Math.round(lastBalance, 2).toFixed(2)},
            //             {'FasId' : data.FasId}, (err, res) => {
            //         });
            //     i++;
            //     console.log(lastBalance);
            // });
            for (let index = 0; index < CountLeftEntries.length; index++) {
                const data = CountLeftEntries[index];
                lastBalance = parseFloat(lastBalance) + parseFloat(data.amount);
                await sqlhelper.update('Ac_Wallet_Transaction', { 'Balance': Math.round(lastBalance, 2).toFixed(2) },
                    { 'FasId': data.FasId }, (err, res) => {
                    });
                i++;
                console.log(lastBalance);
            }
        }
        // while (v_counter < CountLeftEntries) {
        //     query = 'SELECT round((CreditAmount-Debitamount),2) AS amount, FasId FROM Ac_Wallet_Transaction WHERE LedgerID=? and Balance="" order by FasId asc LIMIT 1';
        //     amountsData  = await SqlHelper.select(query,[ledgerID], (err, res) => {
        //         if(err) console.log(err);
        //         return json_response(res)[0];
        //     });
        //     lastBalance = Math.round(lastBalance, 2) + Math.round(amountsData['amount'], 2);
        //     console.log("be lastBalance ---> "+ lastBalance);
        //     await SqlHelper.update('Ac_Wallet_Transaction', {'Balance':Math.round(lastBalance, 2).toFixed(2)},
        //         {'FasId' : amountsData['FasId']}, (err, res) => {
        //     });
        //     v_counter++;
        // }
        console.log('Final lastbalance');
        console.log(lastBalance);
        return lastBalance;
    }
    return '0';
}

Common.SaveNotificationLog = async (Data, request) => {
    Data['EntryBy'] = request.UserID || '0';
    Data['EntryDate'] = moment().format('YYYY-MM-DD HH:mm:ss');
    Data['EntryIP'] = request.IpAddress || '';
    //console.log(Data)
    return await sqlhelper.insert('Mst_Notification', Data, (err, res) => {
        if (err) {
            return 0;
        } else {
            return res.insertId;
        }
    });
}

Common.GetNotificationMessage = (Key) => {
    let Message = {
        'StudentRegister': '{{StudentName}} new student successfully register, please check details.',
        'StudentVarified': '{{StudentName}} new student successfully varified, please check details..',
        'WithdrawalStatus': 'Withdrawal Status is {{Status}}'
    }
    return Message[Key];
}

Common.CreateSubDomain = async (subDomainName, Action) => {
    console.log("Please wait Subdomain is ",Action);
    var AWS = require('aws-sdk')
    var route53 = new AWS.Route53({
        accessKeyId: process.env.ROUTE53_ACCESS_KEY,
        secretAccessKey: process.env.ROUTE53_SECRET_KEY, region: "eu-west-2"
    });
    var params = {
        ChangeBatch: {
            Changes: [{
                Action: Action,
                ResourceRecordSet: {
                    AliasTarget: {
                        DNSName: "ocxeednk-1909592145.eu-west-2.elb.amazonaws.com",
                        EvaluateTargetHealth: false,
                        HostedZoneId: "ZHURV8PSTC4K8"
                    },
                    Name: subDomainName + '.ocxee.com',
                    Type: "A"
                }
            }],
            Comment: "Testing subdomain creation"
        },
        HostedZoneId: "Z00589833EMG1D1WTZDH5"// Depends on the type of resource that you want to route traffic to
    };
    let Data = { 'Apistatus': '0' };
    try {
        Data = await route53.changeResourceRecordSets(params).promise();
        Data['ChangeInfo']['Apistatus'] = '1';
    } catch (error) {
        Data = error;
        Data['Apistatus'] = '0';
    }
    return Data;
}

Common.ReferralStudentCalculation = async (ID) => {
    /*  ChannelPartner = '1'
    *  Student = '2' */
    let TableName = 'Student';
    let where = 'AND ChannelPartnerID=?';
    let query = `SELECT Count(StudentID) as total_student FROM ` + TableName + ` WHERE Active="1" ` + where + ` LIMIT 1`;
    let data = await sqlhelper.select(query, [ID], (err, res) => {
        if (err || _.isEmpty(res)) {
            return {};
        } else {
            return json_response(res[0].total_student);
        }
    });
    return data;
};
Common.GetCommissionCategory = async (student) => {
    /*  ChannelPartner = '1'
    *  Student = '2' */
    let query = 'SELECT CP_Category_Id,Commission_Per_Student,Cash_Incentive,Min_Student,Commission_Per_services FROM CP_Category WHERE Is_Active="1" AND Min_Student<=' + student + ' AND (CASE WHEN Max_Student>0 THEN Max_Student>=' + student + '  ELSE 1=1 END )   LIMIT 1';
    let data = await sqlhelper.select(query, [], (err, res) => {
        if (err || _.isEmpty(res)) {
            return {};
        } else {
            return json_response(res[0]);
        }
    });
    return data;
};
Common.getTotalInquiryOrder = async (studentID, UserID) => {
    /*  ChannelPartner = '1'
    *  Student = '2' */
    let query = 'SELECT Count(OrderID) as totalInquiryOrder FROM User_Order WHERE ReferID=' + studentID + ' AND OrderTypeID=3 AND Status in (1,2) AND UserID=' + UserID + '  LIMIT 1';
    let data = await sqlhelper.select(query, [], (err, res) => {
        if (err || _.isEmpty(res)) {
            return {};
        } else {
            return json_response(res[0].totalInquiryOrder);
        }
    });
    return data;
};
Common.GetAccCommissionAmount = async (Data = '') => {
    // setting_query = 'SELECT * FROM Accommodation_commission WHERE "' + week + '" BETWEEN FromWeek AND ToWeek AND Active="1" LIMIT 1';
    setting_query = `SELECT * FROM Accommodation_City_Commission as act 
    left join Mst_Country as mc on act.CountryID = mc.CountryID
    left join Mst_City as mcity on act.CityID = mcity.CityID 
    WHERE mc.CountryName = ? AND mcity.CityName = ? AND act.Active = "1" LIMIT 1`;
    console.log(setting_query);
    console.log(Data.Country.trim());
    console.log(Data.City.trim());
    setting_data = await sqlhelper.select(setting_query, [Data.Country.trim(), Data.City.trim()], (err, res) => {
        if (err) {
            console.log(err);
            return 0;
        } else if (_.isEmpty(res)) {
            console.log(res);
            return 0;
        } else {
            console.log(`${res[0]['CpMin']} - ${res[0]['CpMax']}`);
            return json_response(res[0]['CpMin']);
        }
    });

    return setting_data;
};
module.exports = Common;