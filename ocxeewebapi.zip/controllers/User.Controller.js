require('dotenv').config();
const moment = require('moment');
const async = require('async');
const _ = require('lodash');
const User = require("../models/User.Model");
const Common = require("../libraries/User.Common");
const request = require('request');
const image_location = process.env.S3_LOCATION;
const stripe = require('stripe')(process.env.StripeKey);
const md5 = require('md5');
const textService = require("./TexiController")
const { Route53Client, ActivateKeySigningKeyCommand } = require("@aws-sdk/client-route-53");
const sqlhelper = require("../helpers/sqlhelper");
var fs = require('fs');

exports.UserLogin = (req, res) => {
    User.UserLogin(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.Toaster, data.message, data.token, data.data));
        }
    });
};

exports.UserRegistration = (req, res) => {
    User.UserRegistration(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.NoAlert, data.message, data.token, data));
        }
    });
};

exports.UserForgetPassword = (req, res) => {
    User.UserForgetPassword(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.Toaster, data.message, req.body.Token, {}));
        }
    });
};

exports.UserResetPassword = (req, res) => {
    let Session = req.body.Session;
    // Session = 'Y8lL70JiaTPuqPyiHxXbu9Mh2iOCubqL1SZ3EBSujZGHOnWSCi0CEvPrnGFhUqiYNJO9dIOu2a0p4gKbSXUUUA%3D%3D';
    Session = Common.TokenDecrypt(decodeURIComponent(Session));
    // console.log(JSON.parse(Session));
    if (Session == 0) {
        return res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
    }

    if (typeof Session === 'string') {
        try {
            Session = JSON.parse(Session);
        } catch (e) {
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        }

        req.body.UserId = Session.UserId;
        req.body.ExpiredTime = Session.ExpiredTime;
    }

    let CurrentTime = moment().format('YYYYMMDDHHmmss');
    if (CurrentTime > req.body.ExpiredTime) {
        return res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'This link is expired.', '', {}));
    }

    User.UserResetPassword(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.Toaster, data.message, req.body.Token, {}));
        }
    });
};

exports.UserChangePassword = (req, res) => {
    User.UserChangePassword(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.Toaster, data.message, req.body.Token, {}));
        }
    });
};

exports.UserProfileUpdate = (req, res) => {
    User.UserProfileUpdate(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.Toaster, data.message, req.body.Token, data.data));
        }
    });
};

exports.GetAccommodationList = (req, res) => {
    async.waterfall([
        function (done) {
            User.GetAccommodationList(req.body, (error, acc_data) => {
                if (error != null && error.sqlMessage != undefined) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    done(null, acc_data);
                }
            });
        },
        function (data, done) {
            User.SeachActivityLogEntry(req.body, (error, view_data) => {
                if (error) console.log(error);
            });

            res.status(200).send(Common.ResFormat(data.status, process.env.NoAlert, data.message, req.body.Token, data.data));
        },
    ], function (err, result) { });
};

exports.GetAccommodationDetails = (req, res) => {
    var response = {};
    async.waterfall([
        function (done) {
            User.GetAccommodationData(req.body, (error, acc_data) => {
                if (error != null && error.sqlMessage != undefined) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else if (_.size(acc_data) <= 0) {
                    res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Data not found.', '', {}));
                } else {
                    response = acc_data;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            User.GetGalleryData(response.AccommodationID, (error, gallery_data) => {
                if (error) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    response['gallery_list'] = gallery_data;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            User.GetFeatureData(response.ProviderID, response.AccommodationID, (error, feature_data) => {
                if (error) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    response['feature_list'] = feature_data;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            User.GetRuleData(response.AccommodationID, response.ProviderID, (error, rule_data) => {
                if (error) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    response['rule_list'] = rule_data;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            User.GetOfferData(response.AccommodationID, response.ProviderID, (error, offer_data) => {
                if (error) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    response['offer_list'] = offer_data;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            User.GetContactData(response.AccommodationID, response.ProviderID, (error, contact_data) => {
                if (error) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    response['contact_list'] = contact_data;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            User.GetUtilityData(response.AccommodationID, (error, utility_data) => {
                if (error) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    response['utility_list'] = utility_data;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            User.GetFAQData(response.AccommodationID, response.ProviderID, (error, faq_data) => {
                if (error) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    response['faq_list'] = faq_data;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            User.GetRoomData(response.AccommodationID, response.ProviderID, (error, room_data) => {
                if (error) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    response['room_list'] = room_data;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            User.GetExtraData(response.AccommodationID, response.ProviderID, (error, extra_data) => {
                if (error) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    response['extra_list'] = extra_data;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            User.GetPaymentData(response.AccommodationID, response.ProviderID, (error, extra_data) => {
                if (error) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    response['payment_list'] = extra_data;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            User.GetReviewData(response.AccommodationID, (error, review_data) => {
                if (error) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    response['review_data'] = review_data;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            User.GetAccommodationBookedDate(response.AccommodationID, (error, BookDate) => {
                if (error) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    response['BookedDate'] = BookDate;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            let request_data = {
                'UserId': req.body.UserId,
                'AccommodationID': response.AccommodationID,
                'Latitude': response.Latitude,
                'Longitude': response.Longitude,
            }
            User.GetPropertiesAroundData(request_data, (error, PA_data) => {
                if (error) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    response['properties_around_list'] = PA_data;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            let request_data = {
                'UserId': req.body.UserId,
                'AccommodationID': response.AccommodationID,
            }
            User.AccommodationViewEntry(request_data, (error, view_data) => {
                if (error) console.log(error);
            });

            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, response));
        },
    ], function (err, result) { });
};
exports.countaccview = (req, res) => {
    console.log(req.body)
    let response = {}
    let request_data = {
        'UserId': req.body.UserId,
        'AccommodationID': req.body.AccId,
    }
    User.AccommodationViewEntry2(request_data, (error, view_data) => {
        if (error) console.log(error);
        // else console.log(view_data)
    });
    res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'Acc view counted.', req.body.Token, response));
}
exports.CalculateRoomRent = (req, res) => {
    User.CalculateRoomRent(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else if (data.status == '0') {
            res.status(200).send(Common.ResFormat(data.status, process.env.Toaster, data.message, '', data.data));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.NoAlert, data.message, req.body.Token, data.data));
        }
    });
};

exports.GetServiceDetails = (req, res) => {
    var response = {};
    async.waterfall([
        function (done) {
            User.GetServiceData(req.body, (error, service_data) => {
                if (error != null && error.sqlMessage != undefined) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else if (_.size(service_data) <= 0) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Data not found.', '', {}));
                } else {
                    response = service_data;
                    response['IsSearch'] = '0';
                    if (['1', '2', '8'].includes(response['ServiceID'])) {
                        response['IsSearch'] = '1';
                    }
                    done(null, response);
                }
            });
        },
        function (response, done) {
            User.GetServiceProviderData(req.body, (error, provider_data) => {
                if (error) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    response['provider_data'] = provider_data;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            User.GetServiceSectionData(req.body, (error, section_data) => {
                if (error) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    response['section_data'] = section_data;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            User.GetTestimonialData(req.body, (error, testimonial_data) => {
                if (error) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    response['testimonial_data'] = testimonial_data;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            User.ServiveLogEntry(req.body, (err, res) => { });
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, response));
        },
    ], function (err, result) { });
};

exports.GetServiceAutoCompleteList = (req, res) => {
    User.GetServiceAutoCompleteList(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'Fetch data successfully.', req.body.Token, data));
        }
    });
};

exports.SubmitServiceEnquiry = (req, res) => {
    User.SubmitServiceEnquiry(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            // console.log((req.body.ChannelPartnerID != '' && req.body.ChannelPartnerID != undefined && req.body.ChannelPartnerID != 0))
            res.status(200).send(Common.ResFormat(data.status, (req.body.ChannelPartnerID != '' && req.body.ChannelPartnerID != undefined && req.body.ChannelPartnerID != 0) ? process.env.NoAlert : process.env.Toaster, data.message, req.body.Token, data.data));
        }
    });
};

exports.SubmitPartnerRequestEnquiry = (req, res) => {
    User.SubmitPartnerRequestEnquiry(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.Toaster, data.message, req.body.Token, data.data));
        }
    });
};

exports.AddToWishlist = (req, res) => {
    User.AddToWishlist(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.Toaster, data.message, req.body.Token, data.data));
        }
    });
};

exports.GetWishlist = (req, res) => {
    User.GetWishlist(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.NoAlert, data.message, req.body.Token, data.data));
        }
    });
};

exports.BookingRequest = (req, res) => {
    User.BookingRequest(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.NoAlert, data.message, req.body.Token, data.data));
        }
    });
};

exports.GetBookingRequestList = (req, res) => {
    User.GetBookingRequestList(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.NoAlert, data.message, req.body.Token, data.data));
        }
    });
};

exports.GetMyEnquiryList = (req, res) => {
    User.GetMyEnquiryList(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.NoAlert, data.message, req.body.Token, data.data));
        }
    });
};

exports.SubmitReview = (req, res) => {
    User.SubmitReview(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.Toaster, data.message, req.body.Token, data.data));
        }
    });
};

exports.SubmitTestimonial = (req, res) => {
    User.SubmitTestimonial(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.Toaster, data.message, req.body.Token, data.data));
        }
    });
};

exports.HomeScreen = (req, res) => {
    res.send({
        "text": "working on it"
    });
};

exports.GetMasterData = (req, res) => {
    var response = {};
    async.waterfall([
        function (done) {
            User.GetMasterData(req.body, (error, master_data) => {
                if (error != null && error.sqlMessage != undefined) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    response = master_data;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            let DeviceType = req.body.Source;
            if (DeviceType != undefined && parseInt(DeviceType) != null && parseInt(DeviceType) != NaN && parseInt(DeviceType) > 1) {
                User.CheckUpdateAppVersion(req.body, (error, version_info) => {
                    if (error != null && error.sqlMessage != undefined) {
                        res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                    } else {
                        response.version_info = version_info;
                        done(null, response);
                    }
                });
            } else {
                done(null, response);
            }
        },
        function (response, done) {
            response['sort_by'] = [{
                'Id': 'PriceLowHigh',
                'Name': 'Price -- Low to High',
                'ImageUrl': '',
            },
            {
                'Id': 'PriceHighLow',
                'Name': 'Price -- High to Low',
                'ImageUrl': '',
            },
            {
                'Id': 'Distance',
                'Name': 'Sort by Distance',
                'ImageUrl': '',
            },
            ];
            response['accom_filter_data'] = {
                'MaxMile': '30',
                'MaxBed': '10',
            };
            response['banner_image'] = [
                'https://ocxeeadmin.s3.eu-west-2.amazonaws.com/BannerImage/1.jpg',
                'https://ocxeeadmin.s3.eu-west-2.amazonaws.com/BannerImage/2.jpg',
                'https://ocxeeadmin.s3.eu-west-2.amazonaws.com/BannerImage/3.jpg',
                'https://ocxeeadmin.s3.eu-west-2.amazonaws.com/BannerImage/4.jpg',
            ]

            response['menu_list'] = [{
                "MenuName": "Home",
                "ImageUrl": image_location + "PhoneMenuIcon/home.png",
                "IsLogin": "0",
                "RedirectScreen": "1",
                "RedirectUrl": "",
                "SubMenuList": []
            },
            {
                "MenuName": "Profile",
                "ImageUrl": image_location + "PhoneMenuIcon/profile.png",
                "IsLogin": "1",
                "RedirectScreen": "2",
                "RedirectUrl": "",
                "SubMenuList": [{
                    "MenuName": "My Profile",
                    "ImageUrl": image_location + "PhoneMenuIcon/my-profile.png",
                    "IsLogin": "1",
                    "RedirectScreen": "2",
                    "RedirectUrl": "",
                },
                {
                    "MenuName": "My Accommodation",
                    "ImageUrl": image_location + "PhoneMenuIcon/accoumodation-enquiry.png",
                    "IsLogin": "1",
                    "RedirectScreen": "9",
                    "RedirectUrl": "",
                },
                {
                    "MenuName": "Change Password",
                    "ImageUrl": image_location + "PhoneMenuIcon/change-pass.png",
                    "IsLogin": "1",
                    "RedirectScreen": "5",
                    "RedirectUrl": "",
                },
                {
                    "MenuName": "My Enquiry",
                    "ImageUrl": image_location + "PhoneMenuIcon/enquiry.png",
                    "IsLogin": "1",
                    "RedirectScreen": "4",
                    "RedirectUrl": "",
                },
                {
                    "MenuName": "My Consultant",
                    "ImageUrl": image_location + "PhoneMenuIcon/profile.png",
                    "IsLogin": "1",
                    "RedirectScreen": "8",
                    "RedirectUrl": "",
                },
                {
                    "MenuName": "My Favourites",
                    "ImageUrl": image_location + "PhoneMenuIcon/favorite.png",
                    "IsLogin": "1",
                    "RedirectScreen": "6",
                    "RedirectUrl": "",
                }
                ]
            },
            {
                "MenuName": "Accommodation Enquiry",
                "ImageUrl": image_location + "PhoneMenuIcon/accoumodation-enquiry.png",
                "IsLogin": "0",
                "RedirectScreen": "12",
                "RedirectUrl": "",
                "SubMenuList": []
            },
            {
                "MenuName": "Settings",
                "ImageUrl": image_location + "PhoneMenuIcon/setting.png",
                "IsLogin": "0",
                "RedirectScreen": "10",
                "RedirectUrl": "",
                "SubMenuList": [{
                    "MenuName": "T & C",
                    "ImageUrl": image_location + "PhoneMenuIcon/tnc.png",
                    "IsLogin": "0",
                    "RedirectScreen": "13",
                    "RedirectUrl": "",
                }]
            },
            {
                "MenuName": "About Us",
                "ImageUrl": image_location + "PhoneMenuIcon/about-us.png",
                "IsLogin": "0",
                "RedirectScreen": "14",
                "RedirectUrl": "",
                "SubMenuList": []
            },
            {
                "MenuName": "Contact Us",
                "ImageUrl": image_location + "PhoneMenuIcon/contact-us.png",
                "IsLogin": "0",
                "RedirectScreen": "7",
                "RedirectUrl": "",
                "SubMenuList": []
            },
            {
                "MenuName": "Rate",
                "ImageUrl": image_location + "PhoneMenuIcon/rate.png",
                "IsLogin": "1",
                "RedirectScreen": "16",
                "RedirectUrl": "",
                "SubMenuList": []
            },
            {
                "MenuName": "Share",
                "ImageUrl": image_location + "PhoneMenuIcon/share.png",
                "IsLogin": "0",
                "RedirectScreen": "15",
                "RedirectUrl": "",
                "SubMenuList": []
            },
            {
                "MenuName": "Logout",
                "ImageUrl": image_location + "PhoneMenuIcon/logout.png",
                "IsLogin": "1",
                "RedirectScreen": "100",
                "RedirectUrl": "",
                "SubMenuList": []
            }
            ];

            response['booking_status_list'] = [{
                'Id': '1',
                'Name': 'Requested',
                'ImageUrl': '',
            },
            {
                'Id': '2',
                'Name': 'Processing',
                'ImageUrl': '',
            },
            {
                'Id': '3',
                'Name': 'Completed',
                'ImageUrl': '',
            },
            ];

            response['inquiry_status_list'] = [{
                'Id': '1',
                'Name': 'New',
                'ImageUrl': '',
            },
            {
                'Id': '2',
                'Name': 'Pending',
                'ImageUrl': '',
            },
            {
                'Id': '3',
                'Name': 'Completed',
                'ImageUrl': '',
            },
            {
                'Id': '4',
                'Name': 'Drafted',
                'ImageUrl': '',
            },
            {
                'Id': '5',
                'Name': 'FollowUps',
                'ImageUrl': '',
            },
            {
                'Id': '6',
                'Name': 'Won',
                'ImageUrl': '',
            },
            {
                'Id': '7',
                'Name': 'Lost',
                'ImageUrl': '',
            },
            ];
            response['ContactNo'] = '447450488811';
            response['GoogleApiKey'] = process.env.GoogleApiKey;
            // response['TermsAndConditions'] = 'https://ocxee.com/TermsAndConditions';
            // response['PrivacyPolicy'] = 'https://ocxee.com/PrivacyPolicy';
            // response['AboutUs'] = 'https://ocxee.com/about';
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, response));
        },
    ], function (err, result) { });
};

exports.GetStateList = (req, res) => {
    User.GetStateList(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data));
        }
    });
};

exports.GetCityList = (req, res) => {
    User.GetCityList(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data));
        }
    });
};

exports.GetCurrentLocationByIp = (req, res) => {
    User.GetCurrentLocationByIp(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data));
        }
    });
};

exports.GetStaticPage = (req, res) => {
    User.GetStaticPage(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data));
        }
    });
};

exports.ContactUs = (req, res) => {
    User.ContactUs(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.Toaster, data.message, req.body.Token, {}));
        }
    });
};

exports.SubscribeUs = (req, res) => {
    User.SubscribeUs(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.Toaster, data.message, req.body.Token, {}));
        }
    });
};

exports.SubmitArrangeCallInquiry = (req, res) => {
    User.SubmitArrangeCallInquiry(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.Toaster, data.message, req.body.Token, {}));
        }
    });
};

exports.GetPopularPropertiesList = (req, res) => {
    User.GetPopularPropertiesList(req.body, (error, pp_data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            let data = {
                'PopularPropertiesList': pp_data,
            }
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data));
        }
    });
};

exports.GetPopularCityList = (req, res) => {
    User.GetPopularCityList(req.body, (error, pc_data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            let data = {
                'PopularCityList': pc_data,
            }
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data));
        }
    });
};

exports.GetHomeSliderList = (req, res) => {
    let request = req.body;
    let where = "";
    let where_array = [];

    if (request.SliderType != undefined && request.SliderType > 0) {
        where += ' AND SliderType=? ';
        where_array.push(request.SliderType);
    }
    let query = `SELECT MapId,IconeMaping,Alt,Title,SliderType,Description,SliderImage,DisplayOrder,AltName 
    from Mst_HomeMap_Slider where Active = 1 ` + where + ` `;

    User.GetDataList(request, query, where_array, (error, pc_data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            let data = {
                'GetHomeSliderList': pc_data,
            }
            // console.log(pc_data)
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data));
        }
    });
};

exports.EmailSubscribe = (req, res) => {
    User.EmailSubscribe(req.body, (error, sb_data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(sb_data.status, process.env.NoAlert, sb_data.Message, req.body.Token, []));
        }
    });
};

exports.EmailUnSubscribe = (req, res) => {
    User.EmailUnSubscribe(req.body, (error, sb_data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(sb_data.status, process.env.NoAlert, sb_data.Message, req.body.Token, []));
        }
    });
};

exports.AddJoiningForm = (req, res) => {
    User.AddJoiningForm(req.body, (error, sb_data) => {
        console.log(error);
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(sb_data.status, process.env.NoAlert, sb_data.Message, req.body.Token, []));
        }
    });
};

exports.UpdatePayment = (req, res) => {
    let query = `SELECT TransactionID,StudentID,PayAmount,BookingID,PaymentDate,InvoiceDes from Accommodation_BookingRequest where BookingNo= '` + req.body.RefID.trim() + `' limit 1`;
    User.GetDataList(req, query, [], async (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            if (!_.isEmpty(data)) {
                var transaction_id = data[0].TransactionID;
                let update_data = await Common.StripePaymentRetrieve(transaction_id);
                var where = {};
                request.TableName = "Accommodation_BookingRequest";
                where['TransactionID'] = transaction_id;
                User.UpdateData(update_data, where, request, async (error, sb_data) => {
                    if (error != null && error.sqlMessage != undefined) {
                        res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                    } else {
                        var res_data = {
                            transaction_id: transaction_id
                        }
                        if (sb_data.isUpadate > 0) await Common.SendPaymentSuccessMail(data[0]);
                        res.status(200).send(Common.ResFormat(sb_data.status, process.env.NoAlert, 'Payment Status updated successfully.', req.body.Token, res_data));
                    }
                });
            } else {
                let query = `SELECT TransactionID,StudentID,PayAmount,InquiryNo as BookingNo,PaymentDate,InvoiceDes from Student_Inquiry where InquiryNo= '` + req.body.RefID.trim() + `' limit 1`;
                User.GetDataList(req, query, [], async (error, data) => {
                    if (error != null && error.sqlMessage != undefined) {
                        res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                    } else {
                        if (!_.isEmpty(data)) {
                            var transaction_id = data[0].TransactionID;
                            let update_data = await Common.StripePaymentRetrieve(transaction_id);
                            // console.log(update_data);
                            var where = {};

                            request.TableName = "Student_Inquiry";
                            where['TransactionID'] = transaction_id;

                            User.UpdateData(update_data, where, request, async (error, sb_data) => {
                                if (error != null && error.sqlMessage != undefined) {
                                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                                } else {
                                    var res_data = {
                                        transaction_id: transaction_id
                                    }
                                    if (sb_data.isUpadate > 0) await Common.SendPaymentSuccessMail(data[0]);
                                    res.status(200).send(Common.ResFormat(sb_data.status, process.env.NoAlert, 'Payment Status updated successfully.', req.body.Token, res_data));
                                }
                            });
                        } else {
                            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                        }
                    }
                });
            }
        }
    });
    // User.UpdatePayment(req.body, (error, sb_data) => {
    //     if (error != null && error.sqlMessage != undefined) {
    //         res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
    //     } else {
    //         res.status(200).send(Common.ResFormat(sb_data.status, process.env.NoAlert, sb_data.Message, req.body.Token, []));
    //     }
    // });
};
exports.UpdatePaymentForTexiBooking = (req, res) => {
    console.log(req.body)
    let query = `SELECT TransactionID,StudentID,PayAmount,BookingID,BookingNo,message as InvoiceDes from Trn_TaxiBooking where ID= '` + req.body.RefID.trim() + `' limit 1`;
    User.GetDataList(req, query, [], async (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            if (!_.isEmpty(data)) {
                var transaction_id = data[0].TransactionID;
                // console.log(transaction_id)
                let update_data = await Common.StripePaymentRetrieve(transaction_id);
                console.log(update_data)
                update_data["UpdateDate"] = moment().format('YYYY-MM-DD HH:mm:ss'),
                    update_data["UpdateBy"] = req.body.UserId
                update_data["UpdateIP"] = req.body.IpAddress
                var where = {};
                request.TableName = "Trn_TaxiBooking";
                where['TransactionID'] = transaction_id;
                User.UpdateData(update_data, where, request, async (error, sb_data) => {
                    if (error != null && error.sqlMessage != undefined) {
                        res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                    } else {
                        var res_data = {
                            transaction_id: transaction_id
                        }
                        if (sb_data.isUpadate > 0) await Common.SendPaymentSuccessMail(data[0]);
                        res.status(200).send(Common.ResFormat(sb_data.status, process.env.NoAlert, 'Payment Status updated successfully.', req.body.Token, res_data));
                    }
                });
            }
        }
    });
}
exports.UpdatePayment1 = (req, res) => {
    User.UpdatePayment1(req.body, (error, sb_data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(sb_data.status, process.env.NoAlert, sb_data.message, req.body.Token, []));
        }
    });
};

exports.GetPaymentDetails = (req, res) => {
    User.GetPaymentDetails(req.body, (error, sb_data) => {
        if (error) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(sb_data.status, process.env.NoAlert, sb_data.message, req.body.Token, sb_data.data));
        }
    });
};

exports.SearchPaymentDetails = (req, res) => {
    User.SearchPaymentDetails(req.body, (error, sb_data) => {
        if (error) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(sb_data.status, process.env.NoAlert, sb_data.message, req.body.Token, sb_data.data));
        }
    });
};


exports.UserVerification = (req, res) => {
    let Session = req.body.Session;
    Session = Common.TokenDecrypt(decodeURIComponent(Session));
    if (Session == 0) {
        return res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
    }

    if (typeof Session === 'string') {
        try {
            Session = JSON.parse(Session);
        } catch (e) {
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        }
        if (typeof Session.UserId === 'undefined') {
            req.body.ChannelPartnerID = Session.ChannelPartnerID;
        } else {
            req.body.UserId = Session.UserId;
        }
        req.body.ExpiredTime = Session.ExpiredTime;
    }

    let CurrentTime = moment().format('YYYYMMDDHHmmss');
    if (CurrentTime > req.body.ExpiredTime) {
        return res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'This link is expired.', '', {}));
    }

    User.UserVerification(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            if (typeof Session.UserId === 'undefined' && typeof Session.ChannelPartnerID !== 'undefined') {
                res.status(200).send(Common.ResFormat(data.status, process.env.NoAlert, data.message, data.token, data.data));
            } else {

                res.status(200).send(Common.ResFormat(data.status, process.env.NoAlert, data.message, data.token, data.data));
            }
            // res.status(200).send(Common.ResFormat(data.status, process.env.Toaster, data.message, req.body.Token, {}));
        }
    });
};
exports.CPVerification = (req, res) => {
    User.CPVerification(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.Toaster, data.message, data.token, data.data));
            // res.status(200).send(Common.ResFormat(data.status, process.env.Toaster, data.message, req.body.Token, {}));
        }
    });
};


exports.SendUserOffer = (req, res) => {
    User.SendUserOffer(req.body, (error, sb_data) => {
        if (error) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(sb_data.status, process.env.NoAlert, sb_data.message, req.body.Token, []));
        }
    });
};

exports.AddFeedback = (req, res) => {
    var request = req.body;
    var UpdateData = {
        Message: request.Message,
        Rating: request.Rating
    }
    var where = {};
    if (request.ServiceType == '2') {
        request.TableName = "Accommodation_BookingRequest";
        where['BookingID'] = request.InquiryID;
    } else {
        request.TableName = "Student_Inquiry";
        where['InquiryID'] = request.InquiryID;
    }
    User.UpdateData(UpdateData, where, request, (error, sb_data) => {
        if (error) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(sb_data.status, process.env.NoAlert, sb_data.message, req.body.Token, sb_data.data));
        }
    });
};

exports.BitrixApiRequest = (req, res) => {
    User.BitrixApiRequest(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.Toaster, data.message, req.body.Token, data.data));
        }
    });
};

exports.GetBlogList = (req, res) => {
    User.GetBlogList(req.body, (error, sb_data) => {
        if (error) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(sb_data.status, process.env.NoAlert, sb_data.message, req.body.Token, sb_data.data));
        }
    });
};

exports.GetBlogCategory = (req, res) => {
    User.GetBlogCategory(req.body, (error, sb_data) => {
        if (error) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(sb_data.status, process.env.NoAlert, sb_data.message, req.body.Token, sb_data.data));
        }
    });
};

exports.GetBlogCategoryCount = (req, res) => {
    User.GetBlogCategoryCount(req.body, (error, sb_data) => {
        if (error) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(sb_data.status, process.env.NoAlert, sb_data.message, req.body.Token, sb_data.data));
        }
    });
};

exports.GetRecentBlog = (req, res) => {
    User.GetRecentBlog(req.body, (error, sb_data) => {
        if (error) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(sb_data.status, process.env.NoAlert, sb_data.message, req.body.Token, sb_data.data));
        }
    });
};

exports.GetBlogStaticData = (req, res) => {
    User.GetBlogStaticData(req.body, (error, sb_data) => {
        if (error) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(sb_data.status, process.env.NoAlert, sb_data.message, req.body.Token, sb_data.data));
        }
    });
};

exports.GetBlogDetail = (req, res) => {
    User.GetBlogDetail(req.body, (error, sb_data) => {
        if (error) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(sb_data.status, process.env.NoAlert, sb_data.message, req.body.Token, sb_data.data));
        }
    });
};

exports.AddToBlogLike = (req, res) => {
    User.AddToBlogLike(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.NoAlert, data.message, req.body.Token, data.data));
        }
    });
};

exports.AddBlogToComment = (req, res) => {
    User.AddBlogToComment(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.Toaster, data.message, req.body.Token, data.data));
        }
    });
};

exports.GetRecommList = (req, res) => {
    User.GetRecommList(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.NoAlert, data.message, req.body.Token, data.data));
        }
    });
};

exports.SetUserPassword = (req, res) => {
    console.log(req.body)
    let Session = req.body.Session;
    Session = Common.TokenDecrypt(decodeURIComponent(Session));
    if (Session == 0) {
        return res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
    }

    if (typeof Session === 'string') {
        try {
            Session = JSON.parse(Session);
        } catch (e) {
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        }

        req.body.UserId = Session.UserId;
        req.body.ExpiredTime = Session.ExpiredTime;
    }

    let CurrentTime = moment().format('YYYYMMDDHHmmss');
    if (CurrentTime > req.body.ExpiredTime) {
        return res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'This link is expired.', '', {}));
    }

    User.SetUserPassword(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.NoAlert, data.message, data.token, data.data));
            // res.status(200).send(Common.ResFormat(data.status, process.env.Toaster, data.message, req.body.Token, {}));
        }
    });
};

exports.GetSEOConetent = (req, res) => {
    User.GetSEOConetent(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.NoAlert, data.message, req.body.Token, data.data));
        }
    });
};

exports.GetAccommodationPageData = (req, res) => {
    var response = {};
    async.waterfall([
        function (done) {
            User.GetServiceData(req.body, (error, service_data) => {
                if (error != null && error.sqlMessage != undefined) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else if (_.size(service_data) <= 0) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Data not found.', '', {}));
                } else {
                    response = service_data;
                    response['IsSearch'] = '0';
                    if (['1', '2', '8'].includes(response['ServiceID'])) {
                        response['IsSearch'] = '1';
                    }
                    done(null, response);
                }
            });
        },
        // function(response, done) {
        //     User.GetServiceSectionData(req.body, (error, section_data) => {
        //         if (error) {
        //             res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        //         } else {
        //             response['SectionData'] = section_data;
        //             done(null, response);
        //         }
        //     });
        // },
        function (response, done) {
            User.GetPopularCityList(req.body, (error, section_data) => {
                if (error) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    response['PopularCityList'] = section_data;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            User.GetPopularPropertiesList(req.body, (error, section_data) => {
                if (error) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    response['PopularPropertiesList'] = section_data;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            User.GetRecentServiceWiseBlog(req.body, (error, section_data) => {
                if (error) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    response['BlogList'] = section_data;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            User.GetRecentServiceWiseNews(req.body, (error, section_data) => {
                if (error) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    response['NewsList'] = section_data;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            User.GetTestimonialData(req.body, (error, testimonial_data) => {
                if (error) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    response['TestimonialData'] = testimonial_data;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            // User.ServiveLogEntry(req.body, (err, res) => {});           
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, response));
        },
    ], function (err, result) { });
};

exports.GetUniversityKeword = (req, res) => {
    let request = req.body;
    let query = `SELECT UniversityName as name from Mst_University where UniversityName like '%` + request.keryword.trim() + `%' limit 50`;
    // console.log(query);
    User.GetDataList(req, query, [], (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data));
        }
    });
};

exports.UserBlogComment = (req, res) => {
    let request = req.body;
    innerquery = '(select ms.BlogID from Mst_Blogs as ms where ms.PageSlug = "' + request.PageSlug + '" limit 1)';
    let query = `SELECT CommentID,Name,Message,URL,EntryDate from Trn_Blog_Comments where BlogID=` + innerquery + ` AND StudentID='` + request.UserId + `'`;
    User.GetDataList(req, query, [], (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data));
        }
    });
};

// new accommodattion list page Api:
exports.GetAccList = async (req, res) => {
    const Limit = parseInt(req.body.Limit);
    let errorResponse = {
        'status': '',
        'message': '',
    }
    if (req.body.PageNo == '1') {
        async.waterfall([
            //Get Accommodation List By Provider
            function (callback) {
                User.GroupedAccommodation(req.body, (error, acc_data) => {
                    if (error != null && error.sqlMessage != undefined) {
                        res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Accommodation Data resourse is not available.', '', {}));
                    } else {
                        if (acc_data.data.ProviderList.length > 0) {
                            callback(null, acc_data.data);
                        } else {
                            errorResponse['status'] = '0';
                            errorResponse['message'] = 'Data is not found';
                            callback(true, errorResponse);
                        }
                    }
                });
            },
            //Get Provider Priority List
            function (acc_data, callback) {
                let GroupedProvider = acc_data.ProviderList;
                let AccList = acc_data.AccList;
                let room_status = acc_data.room_status;
                // console.log(room_status);
                User.GetProviderPriorityList(GroupedProvider, Limit, req.body, (error, acc_provider_list) => {
                    if (error != null && error.sqlMessage != undefined) {
                        res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Provider Sequence resourse is not available.', '', {}));
                    } else {
                        let Data = {};
                        Data['AccList'] = AccList;
                        Data['room_status'] = room_status;
                        if (acc_provider_list.data.orderedList.length > 0) {
                            // console.log('Step 2 ------');
                            // console.log(acc_provider_list.data.orderedList);
                            callback(null, acc_provider_list.data.orderedList, Data);
                        } else {
                            callback(null, [], Data);
                        }
                    }
                });
            },
            // Create Pagination Array By Provider Priority and Min length
            function (OrderList, Data, callback) {
                let AccList = Data['AccList'];
                let totalAcc = AccList.length;
                let LIMIT = parseInt(req.body.Limit);
                let totalPage = Math.ceil(totalAcc / LIMIT);
                // console.log("-----total page-------");
                // console.log(totalPage);
                let PageWiseAccMin = [];
                let Is_Ordering = false;

                if (req.body.SortBy == 'PriceLowHigh') {
                    Is_Ordering = true;
                } else if (req.body.SortBy == 'PriceHighLow') {
                    Is_Ordering = true;
                } else if (req.body.SortBy == 'Distance') {
                    Is_Ordering = true;
                }

                let PageData = {
                    'TotalPage': (totalPage),
                    'TotalRecord': totalAcc,
                }
                // console.log(PageData);
                if (OrderList.length > 0 && !Is_Ordering) {
                    for (let pageIndex = 0; pageIndex < totalPage; pageIndex++) {
                        let totalAcc = 0;
                        let singlePage = [];
                        let PerPageLimit = LIMIT
                        if (pageIndex == (totalPage - 1)) {
                            PerPageLimit = _.sumBy(OrderList, function (o) {
                                return o.Accommodation.length;
                            });
                        }
                        do {
                            for (let proIndex = 0; proIndex < OrderList.length; proIndex++) {
                                if (totalAcc < PerPageLimit) {
                                    let NoOfProperety = OrderList[proIndex]['NoOfProperety'];
                                    let AccLenth = (OrderList[proIndex].Accommodation.length);
                                    if (AccLenth > 0) {
                                        let endLoop = (NoOfProperety - AccLenth);
                                        if (endLoop <= 0) {
                                            endLoop = (NoOfProperety - 1);
                                        }

                                        for (let MinIndex = 0; MinIndex <= endLoop; MinIndex++) {
                                            if (OrderList[proIndex].Accommodation.length > 0) { // it's write because of underfined insert for async functionality
                                                if (totalAcc < PerPageLimit) {
                                                    const selectedAcc = OrderList[proIndex].Accommodation.pop();
                                                    singlePage.push(selectedAcc);
                                                    totalAcc = totalAcc + 1;
                                                } else {
                                                    break;
                                                }
                                            } else {
                                                break;
                                            }
                                        }
                                    } else {
                                        continue;
                                    }
                                } else {
                                    break;
                                }
                            }
                        } while (totalAcc < PerPageLimit);
                        PageWiseAccMin.push(singlePage);
                    }
                } else {
                    PageWiseAccMin = _.chunk(AccList, LIMIT);
                }
                // console.log("--Page Array ---");
                // console.log(PageWiseAccMin);

                // console.log('--check length--');
                // console.log(totalAcc);
                // console.log(_.sumBy(PageWiseAccMin, function(o) { return o.length; }));
                callback(null, PageWiseAccMin, PageData, Data['room_status']);
            },
            //Gengrate Page Token
            function (PageList, PageData, room_status, callback) {
                // console.log('--Page List--');
                // console.log(PageData);
                User.GenratePageToken(req.body, PageList, room_status, (error, token_data) => {
                    if (error) {
                        console.log(error);
                        res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'token is not genrated', '', {}));
                    } else {
                        // console.log(token_data);
                        PageData['PageToken'] = md5(token_data);
                        PageData['SearchID'] = token_data;
                        // console.log(PageData);
                        callback(null, PageList, PageData, room_status);
                    }

                });
            },
            //finally get Accommodation List By Page Array
            function (PageList, PageData, room_status, callback) {
                // console.log(PageList);
                let PageNo = parseInt(req.body.PageNo) - 1;
                let PageIDs = (PageList[PageNo]).toString();
                console.log("ljsagdy")
                User.GroupedAccommodationList(PageIDs, req.body, PageData, room_status, async (error, acc_data) => {
                    if (error != null && error.sqlMessage != undefined) {
                        res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Data List is not created.', '', {}));
                    } else {
                        callback(null, acc_data);
                    }
                });
                // callback(null, 'resultList');
            },
        ], function (err, result) {
            if (err) {
                User.SeachActivityLogEntry(req.body, (error, view_data) => {
                    if (error) console.log(error);
                });
                res.status(200).send(Common.ResFormat(result.status, process.env.NoAlert, result.message, '', {}));
            } else {
                res.status(200).send(Common.ResFormat(result.status, process.env.NoAlert, result.message, req.body.Token, result.data));
            }
        });
    } else {
        if (req.body.PageToken != '') {
            async.waterfall([
                //Get Page Data By Page Token
                function (callback) {
                    User.GetPageDataByToken(req.body.PageToken, async (error, PageData) => {
                        if (error != null && error.sqlMessage != undefined) {
                            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Accommodation Data resourse is not available.', '', {}));
                        } else {
                            if (PageData.PageArray.length > 0) {
                                let totalPage = PageData.PageArray.length;
                                let sum = 0;
                                for (let index = 0; index < totalPage; index++) {
                                    const elementLength = PageData.PageArray[index].length;
                                    sum = sum + elementLength;
                                }
                                let totalAcc = sum;
                                let PageDatils = {
                                    'TotalPage': (totalPage),
                                    'TotalRecord': totalAcc,
                                    'PageToken': req.body.PageToken,
                                    'SearchID': PageData.LogID,
                                }
                                callback(null, PageData.PageArray, PageDatils);
                            } else {
                                errorResponse['status'] = '0';
                                errorResponse['message'] = 'Page token is not found';
                                callback(true, errorResponse);
                            }
                        }
                    });
                },
                //finally get Accommodation List By Page Array
                function (PageData, PageDatils, callback) {
                    let PageNo = parseInt(req.body.PageNo) - 1;
                    let PageIDs = (PageData[PageNo]).toString();
                    User.GroupedAccommodationList(PageIDs, req.body, PageDatils, [], async (error, acc_data) => {
                        if (error != null && error.sqlMessage != undefined) {
                            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Data List is not created.', '', {}));
                        } else {
                            callback(null, acc_data);
                        }
                    });
                    // callback(null, 'resultList');
                },
            ], function (err, result) {
                if (err) {
                    res.status(200).send(Common.ResFormat(result.status, process.env.Toaster, result.message, '', {}));
                } else {
                    res.status(200).send(Common.ResFormat(result.status, process.env.NoAlert, result.message, req.body.Token, result.data));
                }
            });
        } else {
            res.status(500).send(Common.ResFormat('0', process.env.Toaster, 'Page token is required', req.body.Token, {}));
        }
    }
};

exports.GetParameterValue = (req, res) => {
    let request = req.body;
    let query = `SELECT ParameterValueID as id,ParentParameterValue as ParentName,ParameterValue as name from Mst_ParameterValue where ParameterTypeID in (` + request.ID + `) limit 1`;
    User.GetDataList(req, query, [], (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data));
        }
    });
};

exports.GetParameterID = (req, res) => {
    let request = req.body;
    let query = `SELECT ParameterValueID as id,ParentParameterValue as ParentName from Mst_ParameterValue where ParameterValue = '` + request.Value + `' limit 1`;
    User.GetDataList(req, query, [], (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data[0]));
        }
    });
};


exports.GetSEOConetentDetails = (req, res) => {
    var response = {};
    async.waterfall([
        function (done) {
            User.GetAccommodationData(req.body, (error, acc_data) => {
                if (error != null && error.sqlMessage != undefined) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else if (_.size(acc_data) <= 0) {
                    res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Data not found.', '', {}));
                } else {
                    // console.log(acc_data);
                    response = acc_data;
                    done(null, response);
                }
            });
        },
        function (response, done) {
            User.GetGalleryData(response.AccommodationID, (error, gallery_data) => {
                if (error) {
                    res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
                } else {
                    response['gallery_list'] = [gallery_data[0]]; //array add ----||
                    done(null, response);
                }
            });
        },
        function (response, done) {
            // User.ServiveLogEntry(req.body, (err, res) => {});           
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, response));
        },
    ], function (err, result) { });
};

exports.GetServiceSeoContent = (req, res) => {
    let request = req.body;
    let query = `SELECT CAST(sm.ServiceID AS CHAR) AS ServiceID, sm.Name AS ServiceName, sm.MediaImage AS ImageUrl, sm.PageTitle, sm.SeoTitle, sm.SeoDescription, sm.SeoKeyword,sm.PageSlug FROM Mst_Services AS sm WHERE sm.Active="1" AND sm.ServiceID=? LIMIT 1`;
    User.GetDataList(req, query, [request.ServiceID], (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data[0]));
        }
    });
};

exports.GetServiceList = (req, res) => {
    let query = `SELECT CAST(sm.ServiceID AS CHAR) AS ServiceID, sm.Name,sm.DisplayOrder,sm.MediaImage AS ImageUrl,sm.PageSlug,sm.Active as Status,sm.Alt,sm.PageTitle FROM Mst_Services AS sm order by DisplayOrder asc`;
    User.GetDataList(req, query, [], (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            let data2 = {};
            data2['service_list'] = data;
            let CustomServiceList = [{
                "ServiceID": "0",
                "DisplayOrder": "6",
                "PageTitle": "Travel Assistance- Find the best travel plan with OCXEE worldwide",
                "Name": "Travel Assistance",
                "ImageUrl": "https://ocxeeadmin.s3.eu-west-2.amazonaws.com/Mst_Services/735f4b3d-adc5-45ed-9a5e-5b2e1e026ae3.png",
                "PageSlug": "https://oxcee-student-travel.mybookingplatform.com/en",
                "Status": 1
            }];
            data2['CustomServiceList'] = CustomServiceList;
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data2));
        }
    });
};

exports.SubmitGeneralEnquiry = (req, res) => {
    User.SubmitGeneralEnquiry(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.Toaster, data.message, req.body.Token, data.data));
        }
    });
};

exports.Adslist = (req, res) => {
    let request = req.body;
    let query = `SELECT Photo,Link,ModuleType,AdType,OrderNo FROM Ad_Master AS am where ModuleType=? AND Active='1'`; //order by OrderNo asc
    User.GetDataList(req, query, [request.Type], (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            let data2 = [];
            if (data.length > 0) {
                let index = randomNumber(0, data.length);
                data2.push(data[index]);
            }
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, { adslist: data2 }));
        }
    });
};
exports.CreateCheckoutSession = async (req, res) => {
    var Ref_Id = req.body.Ref_Id;
    // var Service_Name=req.body.Service_Name;
    var Currency = req.body.Currency;
    var Amount = req.body.Amount;
    var Ref_Id_Enc = req.body.Ref_Id_Enc;
    var token = req.body.Token;
    // var Payment_From=req.body.Payment_From;
    let query = "";
    // if(Payment_From=='1'){
    console.log(req.body)
    query = `SELECT PayStatus from Accommodation_BookingRequest where BookingNo= '` + Ref_Id.trim() + `' limit 1`;
    // }else{
    //  query = `SELECT PayStatus from Student_Inquiry where InquiryNo= '` + Ref_Id.trim() + `' limit 1`;
    // }
    // console.log(query);
    User.GetDataList(req, query, [], async (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong;; please check your internet connection or try again later.', '', {}));
        } else {
            if (!_.isEmpty(data)) {
                if (data[0].PayStatus == '1') {
                    res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Payment already done for this Reference Number.', '', {}));
                } else {
                    if (Amount > 0) {
                        var amount = parseFloat(Amount) * 100;
                        const session = await stripe.checkout.sessions.create({
                            payment_method_types: [
                                'card',
                            ],
                            line_items: [{
                                price_data: {
                                    currency: Currency,
                                    product_data: {
                                        name: Ref_Id,
                                    },
                                    unit_amount_decimal: amount.toFixed(2),
                                },
                                quantity: 1,
                            },],
                            mode: 'payment',
                            success_url: process.env.STUDENT_PANEL_LINK + `Payment?RefID=` + Ref_Id_Enc,
                            cancel_url: process.env.STUDENT_PANEL_LINK + `Cancel-Payment?RefID=` + Ref_Id,
                        });
                        // console.log(session);
                        var UpdateData = {
                            TransactionID: session.payment_intent,
                            PayAmount: Amount
                        }
                        var where = {};

                        request.TableName = "Accommodation_BookingRequest";
                        where['BookingNo'] = Ref_Id;


                        User.UpdateData(UpdateData, where, request, (error, sb_data) => { });
                        var res_data = {
                            id: session.id,
                            url: session.url,
                            transaction_id: session.payment_intent
                        }
                        res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'success', token, res_data));
                    } else {
                        res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later...', '', {}));
                    }
                }

            } else {
                query = `SELECT PayStatus from Student_Inquiry where InquiryNo= '` + Ref_Id.trim() + `' limit 1`;
                User.GetDataList(req, query, [], async (error, data) => {
                    if (error != null && error.sqlMessage != undefined) {
                        res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again.', '', {}));
                    } else {
                        if (!_.isEmpty(data)) {
                            if (data[0].PayStatus == '1') {
                                res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Payment already done for this Reference Number.', '', {}));
                            } else {
                                if (Amount > 0) {
                                    var amount = parseFloat(Amount) * 100;
                                    const session = await stripe.checkout.sessions.create({
                                        payment_method_types: [
                                            'card',
                                        ],
                                        line_items: [{
                                            price_data: {
                                                currency: Currency,
                                                product_data: {
                                                    name: Ref_Id,
                                                },
                                                unit_amount_decimal: amount.toFixed(2),
                                            },
                                            quantity: 1,
                                        },],
                                        mode: 'payment',
                                        success_url: process.env.STUDENT_PANEL_LINK + `Payment?RefID=` + Ref_Id_Enc,
                                        cancel_url: process.env.STUDENT_PANEL_LINK + `Cancel-Payment?RefID=` + Ref_Id,
                                    });
                                    var UpdateData = {
                                        TransactionID: session.payment_intent,
                                        PayAmount: Amount
                                    }
                                    var where = {};
                                    console.log(session);
                                    request.TableName = "Student_Inquiry";
                                    where['InquiryNo'] = Ref_Id;


                                    User.UpdateData(UpdateData, where, request, (error, sb_data) => { });
                                    var res_data = {
                                        id: session.id,
                                        url: session.url,
                                        transaction_id: session.payment_intent
                                    }

                                    res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'success', token, res_data));
                                } else {
                                    res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry something went wrong; please check your internet connection or try again later.', '', {}));
                                }
                            }
                        } else {
                            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong;  check your internet connection or try again later.', '', {}));
                        }
                    }
                });

            }
        }
    });

};
exports.CreateCheckoutSessionForTexi = async (req, res) => {
    var Ref_Id = req.body.Ref_Id;
    // var Service_Name=req.body.Service_Name;
    var Currency = req.body.Currency;
    var Amount = req.body.Amount;
    var Ref_Id_Enc = req.body.Ref_Id_Enc;
    var token = req.body.Token;
    // var Payment_From=req.body.Payment_From;
    let query = "";
    // if(Payment_From=='1'){
    console.log(req.body)
    query = `SELECT PayStatus from Trn_TaxiBooking where ID= '` + Ref_Id.trim() + `' limit 1`;
    User.GetDataList(req, query, [], async (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong;; please check your internet connection or try again later.', '', {}));
        } else {
            if (!_.isEmpty(data)) {
                if (data[0].PayStatus == '1') {
                    res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Payment already done for this Booking Number.', '', {}));
                } else {
                    console.log(req.body.Amount)
                    if (Amount > 0) {
                        var amount = parseFloat(Amount) * 100;
                        const session = await stripe.checkout.sessions.create({
                            payment_method_types: [
                                'card',
                            ],
                            line_items: [{
                                price_data: {
                                    currency: Currency,
                                    product_data: {
                                        name: req.body.Message,
                                    },
                                    unit_amount_decimal: amount.toFixed(2),
                                },
                                quantity: 1,
                            },],
                            mode: 'payment',
                            success_url: process.env.STUDENT_PANEL_LINK + `Payment?isTexi=1&RefID=` + Ref_Id_Enc,
                            cancel_url: process.env.STUDENT_PANEL_LINK + `Cancel-Payment?isTexi=1&RefID=` + Ref_Id_Enc,
                        });
                        console.log(Amount.toUpperCase());
                        var UpdateData = {
                            TransactionID: session.payment_intent,
                            PayAmount: Amount.toUpperCase()
                        }
                        var where = {};

                        request.TableName = "Trn_TaxiBooking";
                        where['ID'] = Ref_Id;


                        User.UpdateData(UpdateData, where, request, (error, sb_data) => { });
                        var res_data = {
                            id: session.id,
                            url: session.url,
                            transaction_id: session.payment_intent
                        }
                        res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'success', token, res_data));
                    } else {
                        res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later...', '', {}));
                    }
                }
            }
        }
    })

}
function randomNumber(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}

exports.GetPaymentReferenceNo = (req, res) => {
    let request = req.body;
    let unionquery = '';

    if (request.ServiceID == '8') {
        unionquery = `UNION SELECT BookingNo as ReferenceNo,
        IF(Abr.AccRoomCategoryID = 0, 
        ( SELECT CurrencyCode FROM Mst_Country mc WHERE mc.CountryID = acc.CurrencyID ), 
        ( SELECT CurrencyCode FROM Mst_Country mc WHERE mc.CountryID = acr.CurrencyID )) as CurrencyCode ,
        Abr.TotalAmount as TotalAmount
        FROM Accommodation_BookingRequest as Abr 
        INNER Join Accommodation acc on acc.AccommodationID = Abr.AccommodationID 
        left join Accommodation_RoomCategory acr on acr.AccRoomCategoryID = Abr.AccRoomCategoryID 
         where PayStatus!="1" AND StudentID=`+ request.UserId;
    }
    let query = `SELECT InquiryNo as ReferenceNo,SInquiry.CurrencyCode as CurrencyCode,'' as TotalAmount
    FROM Student_Inquiry as SInquiry where ServiceID=? AND StudentID=? AND PayStatus!='1' `+ unionquery; //order by OrderNo asc

    User.GetDataList(req, query, [request.ServiceID, request.UserId], (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            console.log(error);
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data));
        }
    });
};

// exports.AccAdslist = (req, res) => {
//     let request = req.body;
//     let query = `SELECT adm.Ad as ImageUrl,adm.AdLink,adm.AdType as AdvertFlag FROM Accommodation_Ads AS adm 
//     left join Mst_Country as mc on mc.CountryID=adm.CountryID
//     left join Mst_City as mcc on mcc.CityID=adm.CityID
//     where mc.CountryName=? AND mcc.CityName=? order by adm.OrderNo asc`; //order by OrderNo asc
//     User.GetDataList(req, query, [request.CountryName,request.CityName], (error, data) => {
//         if (error != null && error.sqlMessage != undefined) {
//             res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
//         } else {
//             res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data));
//         }
//     });
// };

// exports.AccAdslist = (req, res) => {
//     let request = req.body;
//     User.AccAdslist(request, (error, data) => {
//         if (error != null && error.sqlMessage != undefined) {
//             res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
//         } else {
//             res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data['Data']));
//         }
//     });
// };

exports.GetCountryList = (req, res) => {
    let request = req.body;
    let query = 'SELECT CAST(CountryID AS CHAR) AS Id, CountryName AS Name, CONCAT("' + image_location + 'Country-Flag/", CountryCode, "-32.png") AS ImageUrl, CountryCode, CurrencyCode, PhoneCode, CurrencySymbol, CAST(Active AS CHAR) AS Active FROM Mst_Country ORDER BY CountryID ASC';
    User.GetDataList(req, query, [request.CountryName, request.CityName], (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data));
        }
    });
};

exports.GetCountryList = (req, res) => {
    let request = req.body;
    let query = 'SELECT CAST(CountryID AS CHAR) AS Id, CountryName AS Name, CONCAT("' + image_location + 'Country-Flag/", CountryCode, "-32.png") AS ImageUrl, CountryCode, CurrencyCode, PhoneCode, CurrencySymbol, CAST(Active AS CHAR) AS Active FROM Mst_Country ORDER BY CountryID ASC';
    User.GetDataList(req, query, [request.CountryName, request.CityName], (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data));
        }
    });
};

exports.AddAdsImpression = async (req, res) => {
    let request = req.body;
    let LogID = request.SearchID || 0;
    let tmpinsert = {
        'OfferID': request.AccAdsID,
        'ImpType': '2',
        'LogID': LogID,
        'EntryDate': moment().format('YYYY-MM-DD HH:mm:ss'),
        'EntryIP': request.IpAddress
    }
    request.TableName = 'Acc_Ads_Impression';
    User.InsertData(tmpinsert, request, (err, data) => {
        if (err != null && err.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'Success', req.body.Token, []));
        }
    });
};

exports.addFormUrl = async (req, res) => {
    User.addFormUrl(req, (err, data) => {
        if (err != null && err.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, data.message, req.body.Token, data));
        }
    });
};

exports.AddStudentDetails = async (req, res) => {
    let Details = {};
    let request = req.body;

    let update_data = {
        "BookingID": request.BookingID,
        "StudentID": request.UserId,
        "ProviderID": request.ProviderID,
        "AccommodationID": request.AccommodationID,
        "FirstName": request.FirstName,
        "MiddleName": request.MiddleName,
        "LastName": request.LastName,
        "Nationality": request.Nationality,
        "DateofBirth": request.DateofBirth,
        "Gender": request.Gender,
        "EmailAddress": request.EmailAddress,
        "PhoneNumber": request.PhoneNumber,
        "OtherPreferences": request.OtherPreferences,
        "CurrentUniversity": request.CurrentUniversity,
        "DestinationUniversity": request.DestinationUniversity,
        "YearofStudy": request.YearofStudy,
        "Course": request.Course,
        "GI_FirstName": request.GI_FirstName,
        "GI_LastName": request.GI_LastName,
        "GI_Relationship": request.GI_Relationship,
        "GI_DateofBirth": request.GI_DateofBirth,
        "GI_EmailAddress": request.GI_EmailAddress,
        "GI_PhoneNumber": request.GI_PhoneNumber,
        "GI_Address": request.GI_Address,
        "GI_City": request.GI_City,
        "GI_State": request.GI_State,
        "GI_Postalcode": request.GI_Postalcode,
        "GI_Country": request.GI_Country,
        "Address": request.Address,
        "City": request.City,
        "State": request.State,
        "Postalcode": request.Postalcode,
        "Country": request.Country,
        "FormProcess": "2"
    }

    Details['update_data'] = update_data;
    Details['table_name'] = 'Student_Details2';
    if (request.Student_DetailID > 0) {
        Details['where_data'] = {
            'Student_DetailID': request.Student_DetailID,
        };
    }
    User.AddStudentDetails(request, Details, (err, data) => {
        if (err != null && err.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.NoAlert, data.message, req.body.Token, []));
        }
    });
};

exports.GetStudentList = (req, res) => {
    let request = req.body;
    let where = `AND StudentID = '` + request.UserId + `'`;
    if (request.BookingID && request.BookingID != "") {
        where += `AND BookingID = '` + request.BookingID + `'`;
    }
    query = `SELECT Student_DetailID,BookingID,StudentID,ProviderID,AccommodationID,FirstName,MiddleName,LastName,Nationality,DateofBirth,Gender,EmailAddress,PhoneNumber,OtherPreferences,CurrentUniversity,DestinationUniversity,YearofStudy,Course,GI_FirstName,GI_LastName,GI_Relationship,GI_DateofBirth,GI_EmailAddress,GI_PhoneNumber,GI_Address,GI_City,GI_State,GI_Postalcode,GI_Country,Address,City,State,Postalcode,Country,Active,
    (select Status from Accommodation_BookingRequest as abr where abr.BookingID=std.BookingID limit 1) as FormProcess,EntryDate,EntryIP FROM Student_Details2 as std where 1 `+ where + ` limit 1`;
    User.GetDataList(req, query, [], (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data));
        }
    });
};

exports.GetStudentInfo = (req, res) => {
    let request = req.body;
    let query = `SELECT CAST(sm.StudentID AS CHAR) AS UserId, sm.FirstName, sm.MiddleName, sm.LastName, sm.Email as EmailAddress, sm.PhoneNo as PhoneNumber,  IF(sm.DateOfBirth!="0000-00-00", DATE_FORMAT(sm.DateOfBirth, "%Y-%m-%d"), "") AS DateofBirth, sm.Gender, IFNULL(cn.CountryName, "") AS CountryName, IFNULL(st.StateName, "") AS StateName,
    Nationality,CurrentUniversity,DestinationUniversity,YearofStudy,Course,GI_FirstName,GI_LastName,GI_Relationship,GI_DateofBirth,GI_EmailAddress,GI_Postalcode,GI_PhoneNumber,GI_Address,GI_City,GI_State,Mail_Address as Address,Mail_City as City,Mail_State as State,Mail_Postalcode as Postalcode,Mail_Country as Country,GI_Country
    FROM Student AS sm 
    LEFT JOIN Mst_Country AS cn ON cn.CountryID=sm.CountryID 
        LEFT JOIN Mst_State AS st ON st.StateID=sm.StateID 
        LEFT JOIN Mst_City AS ct ON ct.CityID=sm.CityID 
        WHERE sm.StudentID=? LIMIT 1`;
    User.GetDataList(req, query, [request.StudentID], (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            console.log(error);
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            if (data.length > 0) data[0]['SuccessMessage'] = "Dear " + data[0].FirstName + " " + data[0].LastName + ", You have completed the Signup process on Ocxee.\nPlease, check your email and verify it to activate your account.";
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data));
        }
    });
};

exports.AddPartner = async (req, res) => {
    User.AddPartner(req.body, (err, data) => {
        if (err != null && err.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, data.message, req.body.Token, data));
        }
    });
};

exports.addFormUrl = async (req, res) => {
    User.addFormUrl(req, (err, data) => {
        if (err != null && err.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, data.message, req.body.Token, []));
        }
    });
};

exports.GetavAilableTaxiData = async (req, res) => {

    let response;
    // console.log(req.body)
    req.body.pname=req.body.pname.replace(/_/g,"")
    if (req.body.pname.trim() == "BookTaxi" && req.body.pname.trim() != undefined) {
        response = await textService.BookTaxiTaxiList(req)
        // console.log(response)
    }
    res.status(200).send(Common.ResFormat('1', process.env.NoAlert, "data.message", req.body.Token, response));
};

exports.GetTexiBooking = async (req, res) => {
    let response;
    let IsPaymentDone;
    let query = `SELECT * from Trn_TaxiBooking where ID= ` + parseInt(req.body.ID.trim()) + ` AND PayStatus!='' limit 1`;
    let paystatus
    await User.GetDataList(req, query, [], async (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            if (!_.isEmpty(data)) {
                // console.log(data[0].ID)
                paystatus = data[0]
                // res.status(200).send(Common.ResFormat('1', process.env.NoAlert, "data.message", req.body.Token, data));
            }
        }
    });
    // console.log(paystatus.PayStatus)
    let UpdateBookingNo;
    if (paystatus.PayStatus == 1) {
        req.body.pname=req.body.pname.replace(/_/g,"")
        if (req.body.pname.trim() == "BookTaxi" && req.body.pname.trim() != undefined) {
            response = await textService.BookTaxiTaxiBooking(req)
        }
        if (response.status == "OK" && (response.booking_number != undefined && response.booking_number != '')) {
            req.body.BookingNo = response.booking_number
            req.body.status = response.status
            req.body.message = response.special
            req.body.BookingDateTime = response.BookingDateTime
            UpdateBookingNo = await this.AddTexiRequest(req)
            // console.log(UpdateBookingNo)
        }
        res.status(200).send(Common.ResFormat('1', process.env.NoAlert, "data.message", req.body.Token, response));
    } else {
        res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Your payment is not paid out.', '', {}));
    }
}

exports.GetBookingStatus = async (req, res) => {
    let response;
    req.body.pname=req.body.pname.replace(/_/g,"")
    if (req.body.pname.trim() == "BookTaxi" && req.body.pname.trim() != undefined) {
        response = await textService.BookTaxiBookingStatus(req)
    }
    res.status(200).send(Common.ResFormat('1', process.env.NoAlert, "data.message", req.body.Token, response));
}

exports.GetBookingCanclation = async (req, res) => {
    let response;
    req.body.pname=req.body.pname.replace(/_/g,"")
    if (req.body.pname.trim() == "BookTaxi" && req.body.pname.trim() != undefined) {
        response = await textService.BookTaxiCancleBooking(req)
        console.log(response)
    }
    res.status(200).send(Common.ResFormat('1', process.env.NoAlert, "data.message", req.body.Token, response));
}

exports.GetStudentTaxiRequest = function async(req, res) {
    let query = `SELECT * from Trn_TaxiBooking where ID= '` + req.body.ID.trim() + ` AND PayStatus=1' limit 1`;
    User.GetDataList(req, query, [], async (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            if (!_.isEmpty(data)) {
                // console.log(data[0].ID)
                return data[0].PayStatus
                // res.status(200).send(Common.ResFormat('1', process.env.NoAlert, "data.message", req.body.Token, data));
            }
        }
    });
}

exports.GetChannelPartner = async (req, res) => {
    let Cp = req.body.CpName
    // let query = `SELECT * from ChannelPartner where  SubDomainName='${Cp}' limit 1`;
    let query = `SELECT * from ChannelPartner where replace(CompanyName," ",'')=replace('` + Cp.trim() + `'," ",'') OR SubDomainName='${Cp}' limit 1`;
    User.GetDataList(req, query, [], (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            // return data
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, "data.message", req.body.Token, data));
        }
    });
}
exports.AddTexiRequest = async function (req, res) {
    let Details = {};
    let request = req.body;
    let update_data = {}
    console.log(req.body.BookingNo)
    if (parseInt(req.body.ID) > 0) {
        update_data = {
            "BookingNo": request.BookingNo,
            "booking_status": 1,
            "message": request.message,
            "UpdateDate": moment().format('YYYY-MM-DD HH:mm:ss'),
            "BookingDateTime": request.BookingDateTime,
            'UpdateIP': request.IpAddress,
            "UpdateBy": request.UserId
        }
        console.log(update_data)
        Details['where_data'] = {
            'ID': parseInt(request.ID),
        };

    } else {
        update_data = {
            "BookingID": request.BookingID,
            "StudentID": request.UserId,
            "SProviderID": request.SProviderID,
            "vehicelId": request.vehicle,
            "date": request.start_time_date,
            "time": request.start_time_time,
            "passengers": request.passengers,
            "luggage": request.luggage,
            "Start_point": request.Start_point,
            "End_point": request.End_point,
            "Price": request.Price,
            "booking_status": 0,
            "EntryBy": request.UserId,
            "currency_code": request.currency_code,
            "can_time": request.can_time
        }
    }

    Details['update_data'] = update_data;
    Details['table_name'] = 'Trn_TaxiBooking';

    await User.AddTexiRequest(request, Details, (err, data) => {
        if (err != null && err.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            if (data.IsUpdate == 1) {
                console.log(data)
                return data
            } else {
                res.status(200).send(Common.ResFormat('1', process.env.NoAlert, "data.message", req.body.Token, data));
            }
        }
    });
};

exports.UserActiveAndSetPassword = (req, res) => {

    User.UserActiveAndSetPassword(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            return data;
            res.status(200).send(Common.ResFormat(data.status, process.env.Toaster, data.message, req.body.Token, {}));
        }
    });
};

exports.CpartnerInfo = (req, res) => {
    let request = req.body;
    let query = `select * from ChannelPartner WHERE ChannelPartnerID=? LIMIT 1`;
    User.GetDataList(req, query, [request.ChannelPartnerID], (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            console.log(error);
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            console.log(data[0].FirstName)
            if (data.length > 0) data[0]['SuccessMessage'] = "Dear " + data[0].FirstName + " " + data[0].LastName + ", You have completed the Signup process on Ocxee.\nPlease, check your email and verify it to activate your account.";
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data));
        }
    });
};
exports.AddCPLandingPageVisit = (req, res) => {
    User.AddCPLandingPageVisit(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.NoAlert, data.message, req.body.Token, {}));
        }
    });
};


exports.GetTexiDetail = (req, res) => {

    User.GetTexiDetail(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            console.log(error);
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            // console.log(data.data)
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data.data));
        }
    });
};

exports.GetStudentDetail = (req, res) => {
    // let request = req.body;
    let Session = req.body.Session;
    Session = Common.TokenDecrypt(decodeURIComponent(Session));
    if (Session == 0) {
        return res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
    }

    if (typeof Session === 'string') {
        try {
            Session = JSON.parse(Session);
        } catch (e) {
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        }

        req.body.StudentID = Session.UserId;
        req.body.ExpiredTime = Session.ExpiredTime;
    }
    console.log(req.body)
    let query = `SELECT * from Student WHERE StudentID=? LIMIT 1`;
    User.GetDataList(req, query, [req.body.StudentID], (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            console.log(error);
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            if (data.length > 0) data[0]['SuccessMessage'] = "Dear " + data[0].FirstName + " " + data[0].LastName + ", You have completed the Signup process on Ocxee.\nPlease, check your email and verify it to activate your account.";
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data));
        }
    });
};



exports.CreateSubDomain = async (req, res) => {
    let Data = {
        'Apistatus': '0',
        'message': 'This domain already exists on the platform; try a different one.'
    };
    let emailid_query = "SELECT SubDomainName FROM ChannelPartner WHERE SubDomainName=? LIMIT 1";
    let emailid_exits = await sqlhelper.select(emailid_query, [req.body.SubDomainName], (err, res) => {
        if (err) {
            return 0;
        } else if (res.length > 0) {
            return 0;
        } else {
            return 1;
        }
    });
    emailid_exits = 1
    if (emailid_exits === 0) {
        console.log("emailid_exits");
    } else {
        Data = await Common.CreateSubDomain(req.body.SubDomainName, req.body.event ? req.body.event : 'CREATE');
    }
    res.status(200).send(Common.ResFormat(Data.Apistatus, process.env.NoAlert, Data.message, req.body.Token, Data));
};

exports.CheckSubdomain = async (req, res) => {
    let Data = {
        'Apistatus': '0',
        'message': 'This domain already exists on the platform; try a different one.'
    };
    let emailid_query = "SELECT SubDomainName FROM ChannelPartner WHERE SubDomainName=? LIMIT 1";
    let emailid_exits = await sqlhelper.select(emailid_query, [req.body.SubDomainName], (err, res) => {
        if (err) {
            return 0;
        } else if (res.length > 0) {
            return 0;
        } else {
            Data['Apistatus'] = '1';
            Data['message'] = 'Domain name is available';
            return 1;
        }
    });
    res.status(200).send(Common.ResFormat(Data.Apistatus, process.env.NoAlert, Data.message, req.body.Token, Data));
};
exports.UploadStudentCv = async (req, res) => {
    User.UploadStudentCv(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            console.log(error);
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat(data.status, process.env.NoAlert, data.message, req.body.Token, data));
        }
    });
};
exports.getSettingData = async (req, res) => {
    let setting_query = "SELECT settingValue, UpdateDate FROM Mst_Setting WHERE settingKey=? AND Active='1' LIMIT 1";
    let setting_data = await sqlhelper.select(setting_query, [req.body.settingKey], (err, res) => {
        if (err || _.isEmpty(res)) {
            return '';
        } else {
            return res[0];
        }
    });
    // let Key = await Common.GetSettingValue(req.body.settingKey)
    let data = {
        key: setting_data["settingValue"],
        date: setting_data["UpdateDate"]
    }
    console.log(data)
    res.status(200).send(Common.ResFormat("1", process.env.NoAlert, "", "", data));
    // res.status(200).send(data);
};

exports.FoodPartnerPageData = (req, res) => {
    User.FoodPartnerPageData(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            console.log(error);
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            // console.log(data.data)
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data.data));
        }
    });
};



exports.MyOffer = (req, res) => {

    User.MyOffer(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            console.log(error);
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            console.log(data)
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data.data));
        }
    });
};

exports.Offerget = (req, res) => {
    User.Offerget(req.body, (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            console.log(error);
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            // console.log(data.data)
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, 'The Data Fetching process is completed successfully.', req.body.Token, data.data));
        }
    });
};

exports.OfferKeyword = (req, res) => {
    let request = req.body;
    let where = "";
    where += `AND (query.Title Like "%${request.kyeword}%")`;

    let query = `select query.* from (select mcity.CityName as Title,Offer_Id as ID,pfo.Active from Food_Provider_Offer as pfo 
    left join Mst_Country as mc on mc.CountryID = pfo.CountryID
    left join Mst_City as mcity on mcity.CityID = pfo.CityID
    union
    select mc.CountryName as Title,Offer_Id as ID,pfo.Active from Food_Provider_Offer as pfo 
    left join Mst_Country as mc on mc.CountryID = pfo.CountryID
    left join Mst_City as mcity on mcity.CityID = pfo.CityID
    union
    select OfferDescription as Title,Offer_Id as ID,pfo.Active from Food_Provider_Offer as pfo 
    left join Mst_Country as mc on mc.CountryID = pfo.CountryID
    left join Mst_City as mcity on mcity.CityID = pfo.CityID
    union
    select OfferTitle as Title,Offer_Id as ID,pfo.Active from Food_Provider_Offer as pfo 
    left join Mst_Country as mc on mc.CountryID = pfo.CountryID
    left join Mst_City as mcity on mcity.CityID = pfo.CityID
    ) as query
    where query.Active='1' ${where} Group by query.Title`;
    console.log(where)
    // union
   
    // union
    // select CountryName as Title,Offer_Id as ID,pfo.Active from Food_Provider_Offer as pfo 
    // left join Mst_Country as mc on mc.CountryID = pfo.CountryID
    // left join Mst_City as mcity on mcity.CityID = pfo.CityID
    // union
    // select OfferDescription as Title,Offer_Id as ID,pfo.Active from Food_Provider_Offer as pfo 
    // left join Mst_Country as mc on mc.CountryID = pfo.CountryID
    // left join Mst_City as mcity on mcity.CityID = pfo.CityID
    // console.log(query);
    User.GetDataList(req, query, [], (error, data) => {
        if (error != null && error.sqlMessage != undefined) {
            console.log(error);
            res.status(200).send(Common.ResFormat('0', process.env.NoAlert, 'Sorry, something went wrong; please check your internet connection or try again later.', '', {}));
        } else {
            res.status(200).send(Common.ResFormat('1', process.env.NoAlert, '', req.body.Token, data));
        }
    });
};