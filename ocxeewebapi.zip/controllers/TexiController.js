require('dotenv').config();
const moment = require('moment');
const async = require('async');
const _ = require('lodash');
const User = require("../models/User.Model");
const Common = require("../libraries/User.Common");
const request = require('request');
const image_location = process.env.S3_LOCATION;
const stripe = require('stripe')(process.env.StripeKey);
const md5 = require('md5');

//Minicabit
// exports.MinicabitTexiList = async function (req) {
//     var querystring = require('querystring');
//     var request = require('request');

//     let response;
//     let Url = 'https://www.wissiu.com/index.php?option=com_taxibooking&controller=onepageapi&task=vehicles_query&tmpl=component&format=json';
//     response = await new Promise(resolve => {
//         request({
//             headers: {
//                 'Content-Type': 'application/json',
//                 'Partner': 'c38bb2e56ad349e68a8ad544ca6eaf75'
//             },
//             uri: Url,
//             body: JSON.stringify(req.body),
//             method: 'POST'
//         }, async function (err, res, body) {
//             resolve(res.body);
//         });
//     });
//     response = JSON.parse(response);
//     //  console.log(response)
//     return response
// };
// exports.MinicabitTexiBooking = async function (req) {

//     var querystring = require('querystring');
//     var request = require('request');
//     // console.log(req.body)
//     // let response;
//     // let Url = 'http://www.wissiu.com/index.php?option=com_taxibooking&controller=onepageapi&task=book_now&tmpl=component&format=json';
//     // response = await new Promise(resolve => {
//     //     request({
//     //         headers: {
//     //             'Content-Type': 'application/json',
//     //             'Partner': 'c38bb2e56ad349e68a8ad544ca6eaf75'
//     //         },
//     //         uri: Url,
//     //         body: JSON.stringify(req.body),
//     //         method: 'POST'
//     //     }, async function (err, res, body) {
//     //         resolve(res.body);
//     //     });
//     // });
//    let response={
//         booking_number:"00004280ZZZ",
//         message:"Hello",
//         special:"OK"
//     }
//     // response = JSON.parse(response);

//     this.MinicabitCancleBooking({booking_number:response.booking_number})

//     return response
//     // res.status(200).send(Common.ResFormat('1', process.env.NoAlert, "data.message", req.body.Token, response));

// };
// exports.MinicabitBookingStatus = async function (req) {

//     var querystring = require('querystring');
//     var request = require('request');

//     let response;
//     let Url = 'http://www.wissiu.com/index.php?option=com_taxibooking&controller=onepageapi&task=query_status&tmpl=component&format=json';
//     response = await new Promise(resolve => {
//         request({
//             headers: {
//                 'Content-Type': 'application/json',
//                 'Partner': 'c38bb2e56ad349e68a8ad544ca6eaf75'
//             },
//             uri: Url,
//             body: JSON.stringify(req.body),
//             method: 'POST'
//         }, async function (err, res, body) {
//             resolve(res.body);
//         });
//     });
//     response = JSON.parse(response);
//     return response
//     // res.status(200).send(Common.ResFormat('1', process.env.NoAlert, "data.message", req.body.Token, response));

// };
// exports.MinicabitCancleBooking = async function (req) {

//     var querystring = require('querystring');
//     var request = require('request');
//     let response;
//     let Url = 'http://www.wissiu.com/index.php?option=com_taxibooking&controller=onepageapi&task=cancel_order&tmpl=component&format=json';
//     response = await new Promise(resolve => {
//         request({
//             headers: {
//                 'Content-Type': 'application/json',
//                 'Partner': 'c38bb2e56ad349e68a8ad544ca6eaf75'
//             },
//             uri: Url,
//             body: JSON.stringify(req),
//             method: 'POST'
//         }, async function (err, res, body) {
//             resolve(res.body);
//         });
//     });
//     response = JSON.parse(response);
//     console.log(response)
//     return response;
//     // res.status(200).send(Common.ResFormat('1', process.env.NoAlert, "data.message", req.body.Token, response));

// };


// //GoCatch
// exports.GoCatchTexiList = async function (req) {
//     var querystring = require('querystring');
//     var request = require('request');

//     let response;
//     let Url = 'https://www.wissiu.com/index.php?option=com_taxibooking&controller=onepageapi&task=vehicles_query&tmpl=component&format=json';
//     response = await new Promise(resolve => {
//         request({
//             headers: {
//                 'Content-Type': 'application/json',
//                 'Partner': 'c38bb2e56ad349e68a8ad544ca6eaf75'
//             },
//             uri: Url,
//             body: JSON.stringify(req.body),
//             method: 'POST'
//         }, async function (err, res, body) {
//             resolve(res.body);
//         });
//     });
//     response = JSON.parse(response);
//     // console.log(response)
//     return response
// };
// exports.GoCatchTexiBooking = async function (req) {

//     var querystring = require('querystring');
//     var request = require('request');

//     let response;
//     let Url = 'http://www.wissiu.com/index.php?option=com_taxibooking&controller=onepageapi&task=book_now&tmpl=component&format=json';
//     response = await new Promise(resolve => {
//         request({
//             headers: {
//                 'Content-Type': 'application/json',
//                 'Partner': 'c38bb2e56ad349e68a8ad544ca6eaf75'
//             },
//             uri: Url,
//             body: JSON.stringify(req.body),
//             method: 'POST'
//         }, async function (err, res, body) {
//             resolve(res.body);
//         });
//     });
//     response = JSON.parse(response);
//     return response;
//     //res.status(200).send(Common.ResFormat('1', process.env.NoAlert, "data.message", req.body.Token, response));

// };
// exports.GoCatchBookingStatus = async function (req) {

//     var querystring = require('querystring');
//     var request = require('request');

//     let response;
//     let Url = 'http://www.wissiu.com/index.php?option=com_taxibooking&controller=onepageapi&task=query_status&tmpl=component&format=json';
//     response = await new Promise(resolve => {
//         request({
//             headers: {
//                 'Content-Type': 'application/json',
//                 'Partner': 'c38bb2e56ad349e68a8ad544ca6eaf75'
//             },
//             uri: Url,
//             body: JSON.stringify(req.body),
//             method: 'POST'
//         }, async function (err, res, body) {
//             resolve(res.body);
//         });
//     });
//     response = JSON.parse(response);
//     return response;
//     //res.status(200).send(Common.ResFormat('1', process.env.NoAlert, "data.message", req.body.Token, response));

// };
// exports.GoCatchCancleBooking = async function (req) {

//     var querystring = require('querystring');
//     var request = require('request');

//     let response;
//     let Url = 'http://www.wissiu.com/index.php?option=com_taxibooking&controller=onepageapi&task=cancel_order&tmpl=component&format=json';
//     response = await new Promise(resolve => {
//         request({
//             headers: {
//                 'Content-Type': 'application/json',
//                 'Partner': 'c38bb2e56ad349e68a8ad544ca6eaf75'
//             },
//             uri: Url,
//             body: JSON.stringify(req.body),
//             method: 'POST'
//         }, async function (err, res, body) {
//             resolve(res.body);
//         });
//     });
//     response = JSON.parse(response);
//     return response;
//     //res.status(200).send(Common.ResFormat('1', process.env.NoAlert, "data.message", req.body.Token, response));

// };


exports.BookTaxiTaxiList = async function (req) {
    var querystring = require('querystring');
    var request = require('request');

    let response;
    let Url = 'https://www.wissiu.com/index.php?option=com_taxibooking&controller=onepageapi&task=vehicles_query&tmpl=component&format=json';
    response = await new Promise(resolve => {
        request({
            headers: {
                'Content-Type': 'application/json',
                'Partner': 'c38bb2e56ad349e68a8ad544ca6eaf75'
            },
            uri: Url,
            body: JSON.stringify(req.body),
            method: 'POST'
        }, async function (err, res, body) {
            resolve(res.body);
        });
    });
    response = JSON.parse(response);
    //  console.log(response)
    return response
};
exports.BookTaxiTaxiBooking = async function (req) {

    var querystring = require('querystring');
    var request = require('request');
    // console.log(req.body)
    let response;
    let Url = 'http://www.wissiu.com/index.php?option=com_taxibooking&controller=onepageapi&task=book_now&tmpl=component&format=json';
    response = await new Promise(resolve => {
        request({
            headers: {
                'Content-Type': 'application/json',
                'Partner': 'c38bb2e56ad349e68a8ad544ca6eaf75'
            },
            uri: Url,
            body: JSON.stringify(req.body),
            method: 'POST'
        }, async function (err, res, body) {
            resolve(res.body);
        });
    });
    // let response = {
    //     booking_number: "00004280ZZZ",
    //     message: "Your texi booking payment",
    //     special: "OK"
    // }
    response = JSON.parse(response);
    response["BookingDateTime"]=moment().format('YYYY-MM-DD HH:mm:ss')
    this.BookTaxiCancleBooking({ booking_number: response.booking_number })

    return response
    // res.status(200).send(Common.ResFormat('1', process.env.NoAlert, "data.message", req.body.Token, response));

};
exports.BookTaxiBookingStatus = async function (req) {

    var querystring = require('querystring');
    var request = require('request');

    let response;
    let Url = 'http://www.wissiu.com/index.php?option=com_taxibooking&controller=onepageapi&task=query_status&tmpl=component&format=json';
    response = await new Promise(resolve => {
        request({
            headers: {
                'Content-Type': 'application/json',
                'Partner': 'c38bb2e56ad349e68a8ad544ca6eaf75'
            },
            uri: Url,
            body: JSON.stringify(req.body),
            method: 'POST'
        }, async function (err, res, body) {
            resolve(res.body);
        });
    });
    response = JSON.parse(response);
    let resp
    if (response["status"] == "OK") {
        resp = {
            status: 1,
            message: "Your Order Status "+response["order_status"]
        }
    }
    else
    {
        resp = {
            status: 0,
            message: ""
        }
    }
    return resp
    // res.status(200).send(Common.ResFormat('1', process.env.NoAlert, "data.message", req.body.Token, response));

};
exports.BookTaxiCancleBooking = async function (req) {
    console.log()
    var querystring = require('querystring');
    var request = require('request');
    let response;
    let Url = 'http://www.wissiu.com/index.php?option=com_taxibooking&controller=onepageapi&task=cancel_order&tmpl=component&format=json';
    response = await new Promise(resolve => {
        request({
            headers: {
                'Content-Type': 'application/json',
                'Partner': 'c38bb2e56ad349e68a8ad544ca6eaf75'
            },
            uri: Url,
            body: JSON.stringify(req.body),
            method: 'POST'
        }, async function (err, res, body) {
            resolve(res.body);
        });
    });
    response = JSON.parse(response);
    let resp
    if (response["status"] == "200") {
        resp = {
            status: 1,
            message: response["status_message"]
        }
    }
    else
    {
        resp = {
            status: 0,
            message: ""
        }
    }
    console.log(resp)
    return resp;
    // res.status(200).send(Common.ResFormat('1', process.env.NoAlert, "data.message", req.body.Token, response));

};