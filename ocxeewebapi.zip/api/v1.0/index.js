var express = require('express');
var router = express.Router();
const validator = require("./validator");
const User = require("../../controllers/User.Controller");

router.post('/', function(req, res, next) {
    res.status(200).send('Hello v1.0 POST API');
});

router.post('/UserLogin', validator.ApiAuthentication, validator.UserLogin, User.UserLogin);
router.post('/UserRegistration', validator.ApiAuthentication, validator.UserRegistration, User.UserRegistration);
router.post('/UserForgetPassword', validator.ApiAuthentication, validator.UserForgetPassword, User.UserForgetPassword);
router.post('/UserResetPassword', validator.ApiAuthentication, validator.UserResetPassword, User.UserResetPassword);
router.post('/UserProfileUpdate', validator.ApiAuthentication, validator.UserProfileUpdate, User.UserProfileUpdate);
router.post('/UserChangePassword', validator.ApiAuthentication, validator.UserChangePassword, User.UserChangePassword);

router.post('/GetAccommodationList', validator.ApiAuthentication, validator.GetAccommodationList, User.GetAccommodationList);
router.post('/GetAccommodationDetails', validator.ApiAuthentication, validator.GetAccommodationDetails, User.GetAccommodationDetails);
router.post('/CalculateRoomRent', validator.ApiAuthentication, validator.CalculateRoomRent, User.CalculateRoomRent);
router.post('/GetServiceDetails', validator.ApiAuthentication, validator.GetServiceDetails, User.GetServiceDetails);
router.post('/GetServiceAutoCompleteList', validator.ApiAuthentication, validator.GetServiceAutoCompleteList, User.GetServiceAutoCompleteList);
router.post('/SubmitServiceEnquiry', validator.ApiAuthentication, validator.SubmitServiceEnquiry, User.SubmitServiceEnquiry);
router.post('/SubmitPartnerRequestEnquiry', validator.ApiAuthentication, validator.SubmitPartnerRequestEnquiry, User.SubmitPartnerRequestEnquiry);

router.post('/AddToWishlist', validator.ApiAuthentication, validator.AddToWishlist, User.AddToWishlist);
router.post('/GetWishlist', validator.ApiAuthentication, validator.GetWishlist, User.GetWishlist);

router.post('/BookingRequest', validator.ApiAuthentication, validator.BookingRequest, User.BookingRequest);
router.post('/GetBookingRequestList', validator.ApiAuthentication, validator.GetBookingRequestList, User.GetBookingRequestList);
router.post('/GetMyEnquiryList', validator.ApiAuthentication, validator.GetMyEnquiryList, User.GetMyEnquiryList);
router.post('/SubmitReview', validator.ApiAuthentication, validator.SubmitReview, User.SubmitReview);
router.post('/SubmitTestimonial', validator.ApiAuthentication, validator.SubmitTestimonial, User.SubmitTestimonial);

router.post('/HomeScreen', validator.ApiAuthentication, User.HomeScreen);
router.post('/GetMasterData', validator.ApiAuthentication, User.GetMasterData);
router.post('/GetStateList', validator.ApiAuthentication, validator.GetStateList, User.GetStateList);
router.post('/GetCityList', validator.ApiAuthentication, validator.GetCityList, User.GetCityList);
router.post('/GetCurrentLocationByIp', validator.ApiAuthentication, User.GetCurrentLocationByIp);
router.post('/GetStaticPage', validator.ApiAuthentication, validator.GetStaticPage, User.GetStaticPage);
router.post('/ContactUs', validator.ApiAuthentication, validator.ContactUs, User.ContactUs);
router.post('/SubscribeUs', validator.ApiAuthentication, validator.SubscribeUs, User.SubscribeUs);
router.post('/SubmitArrangeCallInquiry', validator.ApiAuthentication, validator.SubmitArrangeCallInquiry, User.SubmitArrangeCallInquiry);

//vivek Apis
router.post('/GetPopularPropertiesList', validator.ApiAuthentication, User.GetPopularPropertiesList);
router.post('/GetPopularCityList', validator.ApiAuthentication, User.GetPopularCityList);
router.post('/GetHomeSliderList', validator.ApiAuthentication, User.GetHomeSliderList);

router.post('/EmailSubscribe', validator.ApiAuthentication, validator.EmailSubscribe, User.EmailSubscribe);
router.post('/EmailUnSubscribe', validator.ApiAuthentication, validator.EmailUnSubscribe, User.EmailUnSubscribe);
router.post('/AddJoiningForm', validator.ApiAuthentication, validator.AddJoiningForm, User.AddJoiningForm);

//Parth APIs
router.post('/UpdatePayment', validator.ApiAuthentication, validator.UpdatePayment, User.UpdatePayment);
router.post('/GetPaymentDetails', validator.ApiAuthentication, validator.GetPaymentDetails, User.GetPaymentDetails);
router.post('/UpdatePayment1', validator.ApiAuthentication, validator.UpdatePayment1, User.UpdatePayment1);
router.post('/SearchPaymentDetails', validator.ApiAuthentication, validator.GetPaymentDetails, User.SearchPaymentDetails);
router.post('/UserVerification', validator.ApiAuthentication, validator.UserVerification, User.UserVerification);
router.post('/SendUserOffer', validator.ApiAuthentication, validator.SendUserOffer, User.SendUserOffer);
router.post('/AddFeedback', validator.ApiAuthentication, validator.AddFeedback, User.AddFeedback);

//Blog added by Parth Devani 28-04-2021
router.post('/GetBlogList', validator.ApiAuthentication, validator.GetBlogList, User.GetBlogList);
router.post('/GetBlogCategory', validator.ApiAuthentication, User.GetBlogCategory);
router.post('/GetBlogCategoryCount', validator.ApiAuthentication, User.GetBlogCategoryCount);
router.post('/GetRecentBlog', validator.ApiAuthentication, User.GetRecentBlog);
router.post('/GetBlogDetail', validator.ApiAuthentication, validator.GetBlogDetail, User.GetBlogDetail);
router.post('/GetBlogStaticData', validator.ApiAuthentication, User.GetBlogStaticData);
router.post('/AddBlogToLike', validator.ApiAuthentication,validator.AddBlogToLike, User.AddToBlogLike);
router.post('/AddBlogToComment', validator.ApiAuthentication,validator.AddBlogToComment, User.AddBlogToComment);

//my account recommendation by Parth Devani 21-05-2021
router.post('/GetRecommList', validator.ApiAuthentication, User.GetRecommList);

//Set Password by link and verify email 26-05-2021
router.post('/SetUserPassword', validator.ApiAuthentication, validator.SetUserPassword, User.SetUserPassword);

//Seo Dynamic content 31-05-2021
router.post('/GetSEOConetent', validator.ApiAuthentication, validator.GetSEOConetent, User.GetSEOConetent);
router.post('/GetSEOConetentDetails', validator.ApiAuthentication,  User.GetSEOConetentDetails);
router.post('/GetServiceSeoContent', validator.ApiAuthentication, User.GetServiceSeoContent);
// Tmp Extra Service
router.post('/BitrixApiRequest', validator.BitrixApiRequest, User.BitrixApiRequest);

//New Accommodation Page
router.post('/GetAccommodationPageData', validator.ApiAuthentication, validator.GetAccommodationPageData, User.GetAccommodationPageData);
router.post('/GetUniversityKeword', validator.GetUniversityKeword, User.GetUniversityKeword);
router.post('/UserBlogComment',validator.UserBlogComment, User.UserBlogComment);

//Accommodation List by Provider Sorting
router.post('/GetAccList', validator.ApiAuthentication, validator.GetAccList, User.GetAccList);

// router.post('/GetAccList', validator.ApiAuthentication, validator.GetAccommodationList, User.GetAccList);
router.post('/GetParameterValue',validator.ApiAuthentication, validator.GetParameterValue, User.GetParameterValue);
router.post('/GetParameterID',validator.ApiAuthentication, validator.GetParameterID, User.GetParameterID);
router.post('/GetServiceList',validator.ApiAuthentication, User.GetServiceList);
router.post('/SubmitGeneralEnquiry',validator.ApiAuthentication, validator.SubmitGeneralEnquiry, User.SubmitGeneralEnquiry);
router.post('/Adslist',validator.ApiAuthentication,validator.Adslist, User.Adslist);


//stripe payment checkout
router.post('/CreateCheckoutSession',validator.ApiAuthentication,validator.CreateCheckoutSession, User.CreateCheckoutSession);


module.exports = router;