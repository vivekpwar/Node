var express = require('express');
var router = express.Router();
 
router.use('/v1.0', require('./v1.0'));
router.use('/v1.1', require('./v1.1'));
router.use('/v1.2', require('./v1.2'));

module.exports = router;