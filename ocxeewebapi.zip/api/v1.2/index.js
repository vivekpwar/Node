var express = require('express');
var router = express.Router();
const validator = require("./validator");
const User = require("../../controllers/User.Controller");

router.post('/', function(req, res, next) {
    res.status(200).send('Hello v1.2 POST API');
});


router.post('/UserLogin',validator.decryptedRequest, validator.ApiAuthentication, validator.UserLogin, User.UserLogin);
router.post('/UserRegistration',validator.decryptedRequest, validator.ApiAuthentication, validator.UserRegistration, User.UserRegistration);
router.post('/UserForgetPassword',validator.decryptedRequest, validator.ApiAuthentication, validator.UserForgetPassword, User.UserForgetPassword);
router.post('/UserResetPassword',validator.decryptedRequest, validator.ApiAuthentication, validator.UserResetPassword, User.UserResetPassword);
router.post('/UserProfileUpdate',validator.decryptedRequest, validator.ApiAuthentication, validator.UserProfileUpdate, User.UserProfileUpdate);
router.post('/UserChangePassword',validator.decryptedRequest, validator.ApiAuthentication, validator.UserChangePassword, User.UserChangePassword);

router.post('/GetAccommodationList',validator.decryptedRequest, validator.ApiAuthentication, validator.GetAccommodationList, User.GetAccommodationList);
router.post('/GetAccommodationDetails',validator.decryptedRequest, validator.ApiAuthentication, validator.GetAccommodationDetails, User.GetAccommodationDetails);
router.post('/CalculateRoomRent',validator.decryptedRequest, validator.ApiAuthentication, validator.CalculateRoomRent, User.CalculateRoomRent);
router.post('/GetServiceDetails',validator.decryptedRequest, validator.ApiAuthentication, validator.GetServiceDetails, User.GetServiceDetails);
router.post('/GetServiceAutoCompleteList',validator.decryptedRequest, validator.ApiAuthentication, validator.GetServiceAutoCompleteList, User.GetServiceAutoCompleteList);
router.post('/SubmitServiceEnquiry',validator.decryptedRequest, validator.ApiAuthentication, validator.SubmitServiceEnquiry, User.SubmitServiceEnquiry);
router.post('/SubmitPartnerRequestEnquiry',validator.decryptedRequest, validator.ApiAuthentication, validator.SubmitPartnerRequestEnquiry, User.SubmitPartnerRequestEnquiry);

router.post('/AddToWishlist',validator.decryptedRequest, validator.ApiAuthentication, validator.AddToWishlist, User.AddToWishlist);
router.post('/GetWishlist',validator.decryptedRequest, validator.ApiAuthentication, validator.GetWishlist, User.GetWishlist);

router.post('/BookingRequest',validator.decryptedRequest, validator.ApiAuthentication, validator.BookingRequest, User.BookingRequest);
router.post('/GetBookingRequestList',validator.decryptedRequest, validator.ApiAuthentication, validator.GetBookingRequestList, User.GetBookingRequestList);
router.post('/GetMyEnquiryList',validator.decryptedRequest, validator.ApiAuthentication, validator.GetMyEnquiryList, User.GetMyEnquiryList);
router.post('/SubmitReview',validator.decryptedRequest, validator.ApiAuthentication, validator.SubmitReview, User.SubmitReview);
router.post('/SubmitTestimonial',validator.decryptedRequest, validator.ApiAuthentication, validator.SubmitTestimonial, User.SubmitTestimonial);

router.post('/HomeScreen',validator.decryptedRequest, validator.ApiAuthentication, User.HomeScreen);
router.post('/GetMasterData',validator.decryptedRequest, validator.ApiAuthentication, User.GetMasterData);
router.post('/GetStateList',validator.decryptedRequest, validator.ApiAuthentication, validator.GetStateList, User.GetStateList);
router.post('/GetCityList',validator.decryptedRequest, validator.ApiAuthentication, validator.GetCityList, User.GetCityList);
router.post('/GetCurrentLocationByIp',validator.decryptedRequest, validator.ApiAuthentication, User.GetCurrentLocationByIp);
router.post('/GetStaticPage',validator.decryptedRequest, validator.ApiAuthentication, validator.GetStaticPage, User.GetStaticPage);
router.post('/ContactUs',validator.decryptedRequest, validator.ApiAuthentication, validator.ContactUs, User.ContactUs);
router.post('/SubscribeUs',validator.decryptedRequest, validator.ApiAuthentication, validator.SubscribeUs, User.SubscribeUs);
router.post('/SubmitArrangeCallInquiry',validator.decryptedRequest, validator.ApiAuthentication, validator.SubmitArrangeCallInquiry, User.SubmitArrangeCallInquiry);

//vivek Apis
router.post('/GetPopularPropertiesList',validator.decryptedRequest, validator.ApiAuthentication, User.GetPopularPropertiesList);
router.post('/GetPopularCityList',validator.decryptedRequest, validator.ApiAuthentication, User.GetPopularCityList);
router.post('/GetHomeSliderList',validator.decryptedRequest, validator.ApiAuthentication, User.GetHomeSliderList);

router.post('/EmailSubscribe',validator.decryptedRequest, validator.ApiAuthentication, validator.EmailSubscribe, User.EmailSubscribe);
router.post('/EmailUnSubscribe',validator.decryptedRequest, validator.ApiAuthentication, validator.EmailUnSubscribe, User.EmailUnSubscribe);
router.post('/AddJoiningForm',validator.decryptedRequest, validator.ApiAuthentication, validator.AddJoiningForm, User.AddJoiningForm);

//Parth APIs
router.post('/UpdatePayment',validator.decryptedRequest, validator.ApiAuthentication, validator.UpdatePayment, User.UpdatePayment);
router.post('/GetPaymentDetails',validator.decryptedRequest, validator.ApiAuthentication, validator.GetPaymentDetails, User.GetPaymentDetails);
router.post('/UpdatePayment1',validator.decryptedRequest, validator.ApiAuthentication, validator.UpdatePayment1, User.UpdatePayment1);
router.post('/SearchPaymentDetails',validator.decryptedRequest, validator.ApiAuthentication, validator.GetPaymentDetails, User.SearchPaymentDetails);
router.post('/UserVerification',validator.decryptedRequest, validator.ApiAuthentication, validator.UserVerification, User.UserVerification);
router.post('/CPVerification',validator.decryptedRequest, validator.ApiAuthentication, validator.CPVerification, User.CPVerification);
router.post('/SendUserOffer',validator.decryptedRequest, validator.ApiAuthentication, validator.SendUserOffer, User.SendUserOffer);
router.post('/AddFeedback',validator.decryptedRequest, validator.ApiAuthentication, validator.AddFeedback, User.AddFeedback);

//Blog added by Parth Devani 28-04-2021
router.post('/GetBlogList',validator.decryptedRequest, validator.ApiAuthentication, validator.GetBlogList, User.GetBlogList);
router.post('/GetBlogCategory',validator.decryptedRequest, validator.ApiAuthentication, User.GetBlogCategory);
router.post('/GetBlogCategoryCount',validator.decryptedRequest, validator.ApiAuthentication, User.GetBlogCategoryCount);
router.post('/GetRecentBlog',validator.decryptedRequest, validator.ApiAuthentication, User.GetRecentBlog);
router.post('/GetBlogDetail',validator.decryptedRequest, validator.ApiAuthentication, validator.GetBlogDetail, User.GetBlogDetail);
router.post('/GetBlogStaticData',validator.decryptedRequest, validator.ApiAuthentication, User.GetBlogStaticData);
router.post('/AddBlogToLike',validator.decryptedRequest, validator.ApiAuthentication,validator.AddBlogToLike, User.AddToBlogLike);
router.post('/AddBlogToComment',validator.decryptedRequest, validator.ApiAuthentication,validator.AddBlogToComment, User.AddBlogToComment);

//my account recommendation by Parth Devani 21-05-2021
router.post('/GetRecommList',validator.decryptedRequest, validator.ApiAuthentication, User.GetRecommList);

//Set Password by link and verify email 26-05-2021
router.post('/SetUserPassword',validator.decryptedRequest, validator.ApiAuthentication, validator.SetUserPassword, User.SetUserPassword);

//Seo Dynamic content 31-05-2021
router.post('/GetSEOConetent',validator.decryptedRequest, validator.ApiAuthentication, validator.GetSEOConetent, User.GetSEOConetent);

router.post('/GetSEOConetentDetails',validator.decryptedRequest, validator.ApiAuthentication, User.GetSEOConetentDetails);
router.post('/GetServiceSeoContent',validator.decryptedRequest, validator.ApiAuthentication, User.GetServiceSeoContent);
// Tmp Extra Service
router.post('/BitrixApiRequest',validator.decryptedRequest, validator.BitrixApiRequest, User.BitrixApiRequest);

//New Accommodation Page
router.post('/GetAccommodationPageData',validator.decryptedRequest, validator.ApiAuthentication, validator.GetAccommodationPageData, User.GetAccommodationPageData);
router.post('/GetUniversityKeword',validator.decryptedRequest, validator.GetUniversityKeword, User.GetUniversityKeword);
router.post('/GetParameterValue',validator.decryptedRequest, validator.GetParameterValue, User.GetParameterValue);
router.post('/GetParameterID',validator.decryptedRequest,validator.ApiAuthentication, validator.GetParameterID, User.GetParameterID);
router.post('/UserBlogComment',validator.decryptedRequest,validator.ApiAuthentication, validator.UserBlogComment, User.UserBlogComment);

// sequence accommodation by Provider Order-20-07-2021 by Parth Devani
router.post('/GetAccList', validator.decryptedRequest, validator.ApiAuthentication, validator.GetAccList, User.GetAccList);
//
router.post('/GetServiceList', validator.decryptedRequest, validator.ApiAuthentication, User.GetServiceList);
router.post('/SubmitGeneralEnquiry',validator.decryptedRequest, validator.ApiAuthentication, validator.SubmitGeneralEnquiry, User.SubmitGeneralEnquiry);
router.post('/Adslist',validator.decryptedRequest, validator.ApiAuthentication, validator.Adslist, User.Adslist);

router.post('/CreateCheckoutSession',validator.decryptedRequest,validator.ApiAuthentication,validator.CreateCheckoutSession, User.CreateCheckoutSession);

router.post('/GetPaymentReferenceNo',validator.decryptedRequest, validator.ApiAuthentication, validator.GetPaymentReferenceNo, User.GetPaymentReferenceNo);

// router.post('/AccAdslist',validator.decryptedRequest, validator.ApiAuthentication, validator.AccAdslist, User.AccAdslist);
router.post('/GetCountryList',validator.decryptedRequest, validator.ApiAuthentication, User.GetCountryList);
router.post('/AddAdsImpression',validator.decryptedRequest, validator.ApiAuthentication, validator.AddAdsImpression,User.AddAdsImpression);


router.post('/AddFormUrl',validator.decryptedRequest, validator.ApiAuthentication, validator.AddFormUrl,User.addFormUrl);
router.post('/AddStudentDetails',validator.decryptedRequest, validator.ApiAuthentication, validator.AddStudentDetails,User.AddStudentDetails);
router.post('/GetStudentList',validator.decryptedRequest, validator.ApiAuthentication, User.GetStudentList);
router.post('/GetStudentInfo',validator.decryptedRequest, validator.ApiAuthentication, User.GetStudentInfo);
router.post('/AddPartner',validator.decryptedRequest, validator.ApiAuthentication, validator.AddPartner,User.AddPartner);


router.post('/GetChannelPartner',validator.decryptedRequest, validator.GetChannelPartner, User.GetChannelPartner);

//For Postman

// router.post('/GetavAilableTaxiData', validator.ApiAuthentication, validator.GetavAilableTaxiData,User.GetavAilableTaxiData);
// router.post('/GetTexiBooking', validator.ApiAuthentication, validator.BookingTexi,User.GetTexiBooking);
// router.post('/GetBookingStatus', validator.ApiAuthentication, validator.BookingStatus,User.GetBookingStatus);
// router.post('/GetBookingCanclation', validator.ApiAuthentication, validator.CancleBooking,User.GetBookingCanclation);

//For front
router.post('/GetavAilableTaxiData',validator.decryptedRequest, validator.ApiAuthentication, validator.GetavAilableTaxiData,User.GetavAilableTaxiData);
router.post('/GetTexiBooking',validator.decryptedRequest, validator.ApiAuthentication, validator.BookingTexi,User.GetTexiBooking);
router.post('/GetBookingStatus',validator.decryptedRequest, validator.ApiAuthentication, validator.BookingStatus,User.GetBookingStatus);
router.post('/GetBookingCanclation',validator.decryptedRequest, validator.ApiAuthentication, validator.CancleBooking,User.GetBookingCanclation);

router.post('/AddTexiRequest',validator.decryptedRequest, validator.ApiAuthentication, User.AddTexiRequest );
router.post('/CreateCheckoutSessionForTexi',validator.decryptedRequest,validator.ApiAuthentication,validator.CreateCheckoutSession, User.CreateCheckoutSessionForTexi);
router.post('/UpdatePaymentForTexiBooking',validator.decryptedRequest, validator.ApiAuthentication, validator.UpdatePayment, User.UpdatePaymentForTexiBooking);
router.post('/GetStudentTaxiRequest',validator.decryptedRequest, validator.ApiAuthentication, validator.GetStudentTaxiRequest, User.GetStudentTaxiRequest);
router.post('/UserActiveAndSetPassword',validator.decryptedRequest, validator.UserActiveAndSetPassword, User.UserActiveAndSetPassword);
router.post('/CpartnerInfo',validator.decryptedRequest, validator.ApiAuthentication, User.CpartnerInfo);
router.post('/CPVerification',validator.decryptedRequest, validator.ApiAuthentication, validator.CPVerification, User.CPVerification);
router.post('/AddCPLandingPageVisit',validator.decryptedRequest, validator.ApiAuthentication, validator.AddCPLandingPageVisit, User.AddCPLandingPageVisit);
router.post('/GetTexiDetail',validator.decryptedRequest, validator.ApiAuthentication, validator.GetTexiDetail, User.GetTexiDetail);
router.post('/GetStudentDetail',validator.decryptedRequest, User.GetStudentDetail);
router.post('/CreateSubDomain',validator.CreateSubDomain, User.CreateSubDomain);
router.post('/Countaccview',validator.decryptedRequest, User.countaccview);
router.post('/CheckSubdomain',validator.decryptedRequest,validator.CheckSubdomain, User.CheckSubdomain);
router.post('/UploadStudentCv',validator.decryptedRequest,validator.UploadStudentCv, User.UploadStudentCv);
router.post('/getSettingData',validator.decryptedRequest,User.getSettingData);
router.post('/FoodPartnerPageData',validator.decryptedRequest,validator.FoodPartnerPageData, User.FoodPartnerPageData);
// router.post('/Getofferdetails',validator.decryptedRequest,validator.ApiAuthentication,validator.GetOfferdetails, User.GetOfferdetails);
router.post('/Offerget',validator.decryptedRequest,validator.ApiAuthentication,validator.Offerget, User.Offerget);
router.post('/MyOffer',validator.decryptedRequest,validator.ApiAuthentication,validator.MyOffer, User.MyOffer);
router.post('/OfferKeyword',validator.decryptedRequest,validator.OfferKeyword, User.OfferKeyword);

module.exports = router;