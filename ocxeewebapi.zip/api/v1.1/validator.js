require('dotenv').config();
const { check, validationResult } = require('express-validator');
var Common = require("../../libraries/User.Common");

const InvalidParameter = function (errors) {
    var returnStr = "";
    errors.forEach(element => {
        // returnStr = returnStr == "" ? element.param + ": " + element.msg : returnStr + ", " + element.param + ": " + element.msg;
        returnStr = returnStr == "" ? element.msg : returnStr + ", " + element.msg;
    });
    return returnStr;
}

exports.decryptedRequest = [
    async (req, res, next) => {
        req.body = Common.DecryptObject(req.body.fshdjfdh);
        return next();
    },
]

exports.ApiAuthentication = [
    check('Token', 'token is required').trim().notEmpty(), 
    check('UserId', 'userid is required').trim().notEmpty(), 
    check('AppVersion', 'app version is required').trim().notEmpty(), 
    check('DeviceId', 'deviceid is required').trim().notEmpty(), 
    check('DeviceToken', 'device token is required').trim().notEmpty(), 
    check('Source', 'source is required').trim().notEmpty(), 
    async (req, res, next) => {
        // req.body.IpAddress = req.ip.split(':').pop();
        let IpAddress = req.headers['x-forwarded-for'] || req.connection.remoteAddress || req.socket.remoteAddress || req.connection.socket.remoteAddress;
        req.body.IpAddress = IpAddress;
        
        req.body.BaseUrl = req.protocol+'://'+req.headers.host+req.baseUrl+'/';
        req.body.ServiceName = req.url.replace('/', '');
        // console.log(req.body);
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, 'Require parameter missing..', '', {}));
        }

        const TokenData = await Common.TokenVerification(req.body);
        // console.log(TokenData);
        if (TokenData.status=='1') {
            return next();
        }
        return res.status(200).send(Common.ResFormat('2', process.env.PopupAlert, 'Authentication Fail.', '', {}));
    },
]

exports.UserLogin = [
    check('UserName', 'username is required').trim().notEmpty(), 
    check('UserPassword', 'password is required').trim().notEmpty(), 
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.UserRegistration = [
    check('FirstName', 'FirstName is required').trim().notEmpty(), 
    check('LastName', 'LastName is required').trim().notEmpty(), 
    check('Email', 'Email is required').trim().notEmpty(), 
    check('Email', 'please enter valid email address').isEmail(), 
    check('Password', 'Password is required').trim().notEmpty(), 
    check('PhoneNo', 'PhoneNo is required').trim().notEmpty(), 
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.UserForgetPassword = [
    check('UserName', 'username is required').trim().notEmpty(), 
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.UserResetPassword = [
    check('Session', 'Session is required').trim().notEmpty(), 
    check('Password', 'Password is required').trim().notEmpty(), 
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.UserProfileUpdate = [
    check('FirstName', 'FirstName is required').trim().notEmpty(), 
    check('LastName', 'LastName is required').trim().notEmpty(), 
    check('Email', 'Email is required').trim().notEmpty(), 
    check('Email', 'please enter valid email address').isEmail(), 
    check('PhoneNo', 'PhoneNo is required').trim().notEmpty(), 
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.UserChangePassword = [
    check('OldPassword', 'OldPassword is required').trim().notEmpty(), 
    check('NewPassword', 'NewPassword is required').trim().notEmpty(), 
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.GetAccommodationList = [
    check('Limit', 'Limit is required').trim().notEmpty(), 
    check('PageNo', 'PageNo is required').trim().notEmpty(), 
    check('Latitude', 'Latitude is required').trim().notEmpty(), 
    check('Longitude', 'Longitude is required').trim().notEmpty(), 
    check('DistanceRadius', 'DistanceRadius is required').trim().notEmpty(), 
    check('IsSearch', 'IsSearch is required').trim().notEmpty(), 
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.GetAccommodationDetails = [
    check('AccommodationID', 'AccommodationID is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.CalculateRoomRent = [
    check('AccommodationID', 'AccommodationID is required').trim().notEmpty(),
    check('AccRoomCategoryID', 'AccRoomCategoryID is required').trim().notEmpty(),
    check('AccRoomCategoryRentID', 'AccRoomCategoryRentID is required').trim().notEmpty(),
    check('StartDate', 'StartDate is required').trim().notEmpty(),
    check('EndDate', 'EndDate is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.GetServiceDetails = [
    check('ServiceID', 'ServiceID is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.GetServiceAutoCompleteList = [
    check('ServiceID', 'ServiceID is required').trim().notEmpty(),
    check('Search', 'Search is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.SubmitServiceEnquiry = [
    check('ServiceID', 'ServiceID is required').trim().notEmpty(),
    check('FirstName', 'FirstName is required').trim().notEmpty(),
    check('LastName', 'LastName is required').trim().notEmpty(),
    check('Email', 'Email is required').trim().notEmpty(),
    check('PhoneNo', 'PhoneNo is required').trim().notEmpty(),
    check('Remark', 'Remark is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.SubmitPartnerRequestEnquiry = [
    check('OrganizationName', 'OrganizationName is required').trim().notEmpty(),
    check('OrganizationType', 'OrganizationType is required').trim().notEmpty(),
    check('Name', 'Name is required').trim().notEmpty(),
    check('Designation', 'Designation is required').trim().notEmpty(),
    check('Email', 'Email is required').trim().notEmpty(),
    check('PhoneNo', 'PhoneNo is required').trim().notEmpty(),
    check('ServeCountries', 'ServeCountries is required').trim().notEmpty(),
    check('Description', 'Description is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.AddToWishlist = [
    check('AccommodationID', 'AccommodationID is required').trim().notEmpty(), 
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.GetWishlist = [
    check('Limit', 'Limit is required').trim().notEmpty(), 
    check('PageNo', 'PageNo is required').trim().notEmpty(), 
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.BookingRequest = [
    check('AccommodationID', 'AccommodationID is required').trim().notEmpty(),
    check('AccRoomCategoryID', 'AccRoomCategoryID is required').trim().notEmpty(),
    check('AccRoomCategoryRentID', 'AccRoomCategoryRentID is required').trim().notEmpty(),
    check('StartDate', 'StartDate is required').trim().notEmpty(),
    check('EndDate', 'EndDate is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.GetBookingRequestList = [
    check('Limit', 'Limit is required').trim().notEmpty(), 
    check('PageNo', 'PageNo is required').trim().notEmpty(), 
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.GetMyEnquiryList = [
    check('Limit', 'Limit is required').trim().notEmpty(), 
    check('PageNo', 'PageNo is required').trim().notEmpty(), 
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.SubmitReview = [
    check('BookingID', 'BookingID is required').trim().notEmpty(), 
    check('AccommodationID', 'AccommodationID is required').trim().notEmpty(), 
    check('FacilitiesRating', 'FacilitiesRating is required').trim().notEmpty(), 
    check('LocationRating', 'LocationRating is required').trim().notEmpty(), 
    check('TransportationRating', 'TransportationRating is required').trim().notEmpty(), 
    check('SafetyRating', 'SafetyRating is required').trim().notEmpty(), 
    check('StaffRating', 'StaffRating is required').trim().notEmpty(), 
    check('ValueRating', 'ValueRating is required').trim().notEmpty(), 
    check('Review', 'Review is required').trim().notEmpty(), 
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.SubmitTestimonial = [
    check('Name', 'Name is required').trim().notEmpty(), 
    check('Gender', 'Gender is required').trim().notEmpty(), 
    check('Designation', 'Designation is required').trim().notEmpty(), 
    check('CountryID', 'CountryID is required').trim().notEmpty(), 
    check('ServiceID', 'ServiceID is required').trim().notEmpty(), 
    check('Description', 'Description is required').trim().notEmpty(), 
    check('Rating', 'Rating is required').trim().notEmpty(), 
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.GetStateList = [
    check('CountryID', 'CountryID is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.GetCityList = [
    check('CountryID', 'CountryID is required').trim().notEmpty(),
    check('StateID', 'StateID is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.GetStaticPage = [
    check('PageName', 'PageName is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.ContactUs = [
    check('FirstName', 'FirstName is required').trim().notEmpty(),
    check('LastName', 'LastName is required').trim().notEmpty(),
    check('Email', 'Email is required').trim().notEmpty(),
    check('Email', 'please enter valid email address').isEmail(), 
    check('PhoneNo', 'PhoneNo is required').trim().notEmpty(),
    check('Subject', 'Subject is required').trim().notEmpty(),
    check('Message', 'Message is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.SubscribeUs = [
    check('Email', 'Email is required').trim().notEmpty(),
    check('Email', 'please enter valid email address').isEmail(), 
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.SubmitArrangeCallInquiry = [
    check('AccommodationID', 'AccommodationID is required').trim().notEmpty(),
    check('CallDate', 'CallDate is required').trim().notEmpty(), 
    check('CallTime', 'CallTime is required').trim().notEmpty(), 
    check('Message', 'Message is required').trim().notEmpty(), 
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.EmailSubscribe = [
    check('Email', 'Email is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.EmailUnSubscribe = [
    check('Email', 'Email is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.AddJoiningForm = [
    check('FirstName', 'Firstname is required').trim().notEmpty(),
    check('LastName', 'Lastname is required').trim().notEmpty(),
    check('Email', 'Email is required').trim().notEmpty(),
    check('Phone', 'Phone is required').trim().notEmpty(),
    // check('Message', 'Message is required').trim().notEmpty(),
    // check('CV', 'CV is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.UpdatePayment = [
   // check('InquiryID', 'Invoice ID is required').trim().notEmpty(),
    // check('ServiceType', 'Service Type is required').trim().notEmpty(),
    // check('PayStatus', 'Status is required').trim().notEmpty(),
    check('RefID', 'Referrence ID is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.UpdatePayment1 = [
    check('RefID', 'Service Type is required').trim().notEmpty(),
    check('PayStatus', 'Status is required').trim().notEmpty(),
    check('TransactionID', 'Transaction ID is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.GetPaymentDetails = [
    check('RefID', 'Reference ID is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.UserVerification = [
    check('Session', 'Session is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.SendUserOffer = [
    check('ServiceID', 'ServiceID is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.AddFeedback = [
    check('Name', 'Name is required').trim().notEmpty(),
    check('ServiceName', 'ServiceName is required').trim().notEmpty(),
    check('ReferenceNo', 'ReferenceNo is required').trim().notEmpty(),
    check('Message', 'Message is required').trim().notEmpty(),
    check('Rating', 'Rating is required').trim().notEmpty(),
    check('ServiceType', 'ServiceType is required').trim().notEmpty(),
    check('InquiryID', 'InquiryID is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.BitrixApiRequest = [
    check('FromInquiryID', 'FromInquiryID is required').trim().notEmpty(),
    check('ToInquiryID', 'ToInquiryID is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.GetBlogList = [
    check('PageNo', 'Page No is required').trim().notEmpty(),
    check('Limit', 'Limit is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.GetBlogDetail = [
    // check('PageName', 'Page Name is required').trim().notEmpty(),
    check('PageSlug', 'Page Slug is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.AddBlogToLike = [
    check('BlogID', 'Blog ID is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.AddBlogToComment = [
    check('BlogID', 'Blog ID is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.SetUserPassword = [
    check('Session', 'Session is required').trim().notEmpty(),
    check('Password', 'Password is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.GetSEOConetent = [
    check('CountryName', 'CountryName is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.GetAccommodationPageData = [
    check('ServiceID', 'ServiceID is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.GetUniversityKeword = [
    // check('keryword', 'keryword is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.UserBlogComment = [
    check('UserId', 'UserID is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.GetParameterValue = [
    check('ID', 'ID is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.GetParameterID = [
    check('Value', 'Value is required').trim().notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.GetAccList = [
    check('Limit', 'Limit is required').trim().notEmpty(), 
    check('PageNo', 'PageNo is required').trim().notEmpty(), 
    check('Latitude', 'Latitude is required').trim().notEmpty(), 
    check('Longitude', 'Longitude is required').trim().notEmpty(), 
    check('DistanceRadius', 'DistanceRadius is required').trim().notEmpty(), 
    check('IsSearch', 'IsSearch is required').trim().notEmpty(), 
    // check('PageToken', 'PageToken is required').trim().notEmpty(), 
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.SubmitGeneralEnquiry = [
    check('FirstName', 'FirstName is required').trim().notEmpty(), 
    check('LastName', 'LastName is required').trim().notEmpty(), 
    check('Email', 'Email is required').trim().notEmpty(), 
    check('MobileNo', 'MobileNo is required').trim().notEmpty(), 
    check('PageUrl', 'PageUrl is required').trim().notEmpty(), 
    check('CountryID', 'CountryID is required').trim().notEmpty(), 
    // check('PageToken', 'PageToken is required').trim().notEmpty(), 
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.Adslist = [
    check('Type', 'Type is required').trim().notEmpty(), 
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.CreateCheckoutSession = [
    check('Amount', 'Amount is required').trim().notEmpty(), 
    check('Currency', 'Currency is required').trim().notEmpty(), 
    check('Ref_Id', 'Refference Number  is required').trim().notEmpty(), 
    check('Ref_Id_Enc', 'Refference Number is required').trim().notEmpty(), 
    // check('Payment_From', 'Service is required').trim().notEmpty(), 
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.GetPaymentReferenceNo = [
    check('ServiceID', 'ServiceID is required').trim().notEmpty(), 
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]

exports.AccAdslist = [
    check('CountryID', 'CountryID is required').trim().notEmpty(), 
    check('CityID', 'CityID is required').trim().notEmpty(), 
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            var error_string = InvalidParameter(errors.array());
            return res.status(200).send(Common.ResFormat('0', process.env.Toaster, error_string, '', {}));
        }
        next();
    },
]